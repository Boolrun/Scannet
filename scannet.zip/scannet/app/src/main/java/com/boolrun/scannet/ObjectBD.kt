package com.boolrun.scannet

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log


class ObjectBD(context: Context, name: String?,
                      factory: SQLiteDatabase.CursorFactory?, version: Int) :
        SQLiteOpenHelper(context, DATABASE_NAME,
            factory, DATABASE_VERSION) {

        override fun onCreate(db: SQLiteDatabase) {
            val CREATE_POSITION_TABLE = ("CREATE TABLE " +
                    TABLE_POSITION + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY," +
                    COLUMN_LATITUDE + " TEXT," +
                    COLUMN_LONGITUDE + " TEXT," +
                    COLUMN_DATESCAN + " TEXT," +
                    COLUMN_METHODE + " TEXT," +
                    COLUMN_PRECISION + " TEXT" +
                    ")")
            db.execSQL(CREATE_POSITION_TABLE)

            val CREATE_WIFI_ROUTER_TABLE = ("CREATE TABLE " +
                    TABLE_WIFI_ROUTER + "("
                    + COLUMN_ID_WIFI + " INTEGER PRIMARY KEY," +
                    COLUMN_SSID + " TEXT," +
                    COLUMN_BSSID + " TEXT," +
                    COLUMN_FREQUENCE + " TEXT," +
                    COLUMN_LEVEL + " TEXT," +
                    COLUMN_SECURITE + " TEXT," +
                    COLUMN_DISTANCE + " TEXT," +
                    COLUMN_CANAL + " TEXT," +
                    COLUMN_DATE_SCAN_WIFI + " TEXT," +
                    COLUMN_ID_POSITION + " INTEGER" +
                    ")")
            db.execSQL(CREATE_WIFI_ROUTER_TABLE)

        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int,
                               newVersion: Int) {

        }

        companion object {

            private val DATABASE_VERSION = 3
            private val DATABASE_NAME = "positionDBLite.db"
            val TABLE_POSITION = "position_data"
            val COLUMN_ID = "_id"
            val COLUMN_LATITUDE = "latitude"
            val COLUMN_LONGITUDE = "longitude"
            val COLUMN_DATESCAN = "datescan"
            val COLUMN_METHODE = "methode"
            val COLUMN_PRECISION = "precision"


            val TABLE_WIFI_ROUTER = "wifi_router"
            val COLUMN_ID_WIFI = "_id"
            val COLUMN_SSID = "ssid"
            val COLUMN_BSSID = "bssid"
            val COLUMN_FREQUENCE = "frequence"
            val COLUMN_LEVEL = "level"
            val COLUMN_SECURITE = "securite"
            val COLUMN_CANAL = "canal"
            val COLUMN_DISTANCE = "distance"
            val COLUMN_DATE_SCAN_WIFI = "date_scan_wifi"
            val COLUMN_ID_POSITION = "id_position"

        }

        fun addPosition(pos: ObjectPosition) {

            val values = ContentValues()
            values.put(COLUMN_LATITUDE, pos.strLatitude)
            values.put(COLUMN_LONGITUDE, pos.strLongitude)
            values.put(COLUMN_DATESCAN, pos.dateScan)
            values.put(COLUMN_METHODE, pos.strMethode)
            values.put(COLUMN_PRECISION, pos.strPrecision)

            val db = this.writableDatabase

            db.insert(TABLE_POSITION, null, values)
            db.close()

        }

    fun addWifiRouter(router: ObjectWifi) {

        val values = ContentValues()
        values.put(COLUMN_SSID , router.strSSID)
        values.put(COLUMN_BSSID , router.strBSSID)
        values.put(COLUMN_FREQUENCE , router.strFrequence)
        values.put(COLUMN_LEVEL , router.strLevel)
        values.put(COLUMN_SECURITE , router.strSecurite)
        values.put(COLUMN_CANAL , router.strCanal)
        values.put(COLUMN_DISTANCE  , router.strDistance)
        values.put(COLUMN_DATE_SCAN_WIFI , router.dateScanWifi)
        values.put(COLUMN_ID_POSITION , router.idPosition)

        val db = this.writableDatabase

        db.insert(TABLE_WIFI_ROUTER, null, values)
        db.close()

    }

    fun findAllWifiRouter(): Cursor {

        val query =  "SELECT DISTINCT $COLUMN_SSID,$COLUMN_BSSID,$COLUMN_FREQUENCE,$COLUMN_SECURITE,$COLUMN_CANAL FROM $TABLE_WIFI_ROUTER ORDER BY $COLUMN_SSID,$COLUMN_BSSID"

        val db = this.writableDatabase
        val cursor = db.rawQuery(query, null)

        return cursor

    }

    fun findWifiRouter(idposition:Int,bssid:String): ObjectWifi? {
        val query =
            "SELECT * FROM $TABLE_WIFI_ROUTER  WHERE $COLUMN_ID_POSITION =$idposition AND $COLUMN_BSSID='$bssid' ORDER BY $COLUMN_ID_WIFI DESC"

        val db = this.writableDatabase

        val cursor = db.rawQuery(query, null)

        var wifiRouter:ObjectWifi? = null

        if (cursor.moveToFirst()) {
            cursor.moveToFirst()

            val id = Integer.parseInt(cursor.getString(0))
            val ssid = cursor.getString(1)
            val strbssid = cursor.getString(2)
            var frequence = cursor.getString(3)
            var level = cursor.getString(4)
            var securite = cursor.getString(5)
            var canal = cursor.getString(6)
            var distance = cursor.getString(7)
            var datescan = cursor.getString(8)


            wifiRouter = ObjectWifi(ssid,strbssid,frequence,level,securite,canal,distance,datescan,idposition)

            cursor.close()
        }
        db.close()
        return wifiRouter

    }

    fun findPosition(latitude:String,longitude:String): ObjectPosition? {
        val query =
            "SELECT * FROM $TABLE_POSITION  WHERE $COLUMN_LATITUDE =$latitude AND $COLUMN_LONGITUDE=$longitude ORDER BY $COLUMN_ID DESC"

        val db = this.writableDatabase

        val cursor = db.rawQuery(query, null)

        var position:ObjectPosition? = null

        if (cursor.moveToFirst()) {
            cursor.moveToFirst()

            val id = Integer.parseInt(cursor.getString(0))
            val latitude = cursor.getString(1)
            val longitude = cursor.getString(2)
            var datescan = cursor.getString(3)
            var methode = cursor.getString(4)
            var precision = cursor.getString(5)

            if (datescan.isNullOrEmpty()) {
                datescan=""
            }
            position = ObjectPosition(id, latitude,longitude,datescan,methode,precision)

            cursor.close()
        }

        db.close()
        return position
    }

    fun deleteallPosition() {
        val query =
            "DELETE FROM $TABLE_POSITION  WHERE $COLUMN_ID >0"

        val db = this.writableDatabase

        db.execSQL(query)


        db.close()

    }

    fun deletePositionById(idposition: Int) {
        val query =
            "DELETE FROM $TABLE_POSITION  WHERE $COLUMN_ID =$idposition"
        val db = this.writableDatabase
        db.execSQL(query)
        db.close()
    }

    fun deleteWifiByPositionId(idposition: Int) {
        val query =
            "DELETE FROM $TABLE_WIFI_ROUTER  WHERE $COLUMN_ID_POSITION =$idposition"

        val db = this.writableDatabase

        db.execSQL(query)

        db.close()

    }

    fun deleteallWifi() {
        val query =
            "DELETE FROM $TABLE_WIFI_ROUTER  WHERE $COLUMN_ID >0"

        val db = this.writableDatabase

        db.execSQL(query)

        db.close()

    }

    fun getWifiByPosition(latitude: String?,longitude: String?,objActivity: Activity?): String? {

        var query ="SELECT $COLUMN_ID FROM $TABLE_POSITION WHERE $COLUMN_LATITUDE='$latitude' AND $COLUMN_LONGITUDE='$longitude' ORDER BY $COLUMN_ID DESC"

        val db = this.writableDatabase

        var resulat:String=""


        val cursor = db.rawQuery(query, null)
        var id:Int=0
        if (cursor.moveToFirst()) {

            cursor.moveToFirst()
            id = Integer.parseInt(cursor.getString(0))
        }

        var ssid:String
        var strbssid:String
        var frequence:String
        var level:String
        var securite:String
        var canal:String
        var distance:String
        var datescan:String

        query ="SELECT * FROM $TABLE_WIFI_ROUTER WHERE $COLUMN_ID_POSITION=$id ORDER BY $COLUMN_SSID"

        val cursor2 = db.rawQuery(query, null)

        if (cursor2.count>0) {
            for(y in 0..cursor2.count-1 ){
                cursor2.moveToPosition(y)

                 ssid=cursor2.getString(1)
                 strbssid= cursor2.getString(2)
                 frequence = cursor2.getString(3)
                 level=cursor2.getString(4)
                 securite=cursor2.getString(5)
                 canal=cursor2.getString(6)
                 distance= cursor2.getString(7)
                 datescan = cursor2.getString(8)


                resulat=resulat+"SSID: " +ssid +  "\n"

                resulat=resulat+"BSSID: "+strbssid + "  "+objActivity!!.getString(R.string.wifi_frequence)+": "+ frequence +" Ghz\n"

                resulat=resulat+objActivity!!.getString(R.string.wifi_niveau)+": "+level+ "  "+ objActivity!!.getString(R.string.wifi_securite)+": "+securite +"\n"

                resulat=resulat+objActivity!!.getString(R.string.wifi_canal)+" "+ canal +" "+  objActivity!!.getString(R.string.whois_date) + " "+ datescan+"\n\n"/*+objActivity!!.getString(R.string.wifi_distance)+" " +distance +" " +objActivity!!.getString(R.string.wifi_metre)+" "*/

            }
            cursor2.close()

        }
        db.close()
        return resulat
    }

    fun getWifiByBSSID(bssid: String?,objActivity: Activity?): String? {

        val db = this.writableDatabase
        var resulat:String=""
        var latitude:String
        var longitude:String
        var ssid:String
        var strbssid:String
        var frequence:String
        var level:String
        var securite:String
        var canal:String
        var distance:String
        var datescan:String

        var query ="SELECT $COLUMN_LATITUDE,$COLUMN_LONGITUDE,$COLUMN_SSID,$COLUMN_BSSID,$COLUMN_FREQUENCE,$COLUMN_LEVEL, $COLUMN_SECURITE, $COLUMN_CANAL, $COLUMN_DISTANCE, $COLUMN_DATE_SCAN_WIFI  FROM $TABLE_POSITION INNER JOIN $TABLE_WIFI_ROUTER ON $TABLE_POSITION.$COLUMN_ID = $TABLE_WIFI_ROUTER.$COLUMN_ID_POSITION WHERE $COLUMN_BSSID='$bssid' ORDER BY $COLUMN_DATE_SCAN_WIFI DESC"

        val cursor2 = db.rawQuery(query, null)

        if (cursor2.count>0) {
            for(y in 0..cursor2.count-1 ){
                cursor2.moveToPosition(y)
                latitude=cursor2.getString(0)
                longitude=cursor2.getString(1)
                ssid=cursor2.getString(2)
                strbssid= cursor2.getString(3)
                frequence = cursor2.getString(4)
                level=cursor2.getString(5)
                securite=cursor2.getString(6)
                canal=cursor2.getString(7)
                distance= cursor2.getString(8)
                datescan = cursor2.getString(9)

                resulat=resulat+"Position: " +latitude +" "+ longitude + "\n"

                resulat=resulat+"SSID: " +ssid +  "\n"

                resulat=resulat+"BSSID: "+strbssid + "  "+objActivity!!.getString(R.string.wifi_frequence)+": "+ frequence +" Ghz\n"

                resulat=resulat+objActivity!!.getString(R.string.wifi_niveau)+": "+level+ "  "+ objActivity!!.getString(R.string.wifi_securite)+": "+securite +"\n"

                resulat=resulat+objActivity!!.getString(R.string.wifi_canal)+" "+ canal +"  "+  objActivity!!.getString(R.string.whois_date) + " "+ datescan+"\n\n"/*+objActivity!!.getString(R.string.wifi_distance)+" " +distance +" " +objActivity!!.getString(R.string.wifi_metre)+" " +datescan+"\n\n"*/

            }
            cursor2.close()

        }
        db.close()
        return resulat
    }

    fun getDistinctPosition(): Cursor {
        val query =
            "SELECT DISTINCT 0,$COLUMN_LATITUDE,$COLUMN_LONGITUDE,'','','' FROM $TABLE_POSITION ORDER BY $COLUMN_ID DESC"

        val db = this.writableDatabase

             val cursor = db.rawQuery(query, null)

        return cursor


    }

    fun getPositionForBSSID(bssid:String): Cursor {
        val query =
            "SELECT $COLUMN_LATITUDE,$COLUMN_LONGITUDE,'','','' FROM $TABLE_POSITION WHERE $COLUMN_ID IN(SELECT $COLUMN_ID_POSITION FROM $TABLE_WIFI_ROUTER WHERE $COLUMN_BSSID='$bssid') ORDER BY $COLUMN_ID DESC"

        val db = this.writableDatabase

           val cursor = db.rawQuery(query, null)

        return cursor

    }


    }



