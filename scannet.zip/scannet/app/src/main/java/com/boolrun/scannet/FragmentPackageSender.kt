package com.boolrun.scannet

import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.TrafficStats
import android.os.Bundle
import android.telephony.TelephonyManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import java.util.*

class FragmentPackageSender : Fragment() {

    companion object {

        val resultSocketMessage = arrayOfNulls<String>(10000)

        private var tx: Long = 0
        private var rx: Long = 0

        private var wifi_tx: Long = 0
        private var wifi_rx: Long = 0

        private var mobil_tx: Long = 0
        private var mobil_rx: Long = 0

        private var current_tx: Long = 0
        private var current_rx: Long = 0

        private var app: ApplicationInfo? = null

        private val isMobil = false

        @JvmStatic
        fun newInstance() =
            FragmentPackageSender().apply {
                arguments = Bundle().apply {

                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view: View = inflater!!.inflate(R.layout.activity_package_sender, container, false)

        val mListView = view.findViewById(R.id.listPackage) as ListView
        for (x in 0..10000-1)
        {
            FragmentPackageSender.resultSocketMessage.set( x, " ")
        }
        val adapter = ArrayAdapter<String>(context, android.R.layout.simple_list_item_1 ,
            FragmentPackageSender.resultSocketMessage
        )
        mListView.setAdapter(adapter)

        val  manager = inflater!!.context!!.getPackageManager()

        val packages:List<ApplicationInfo>
        packages= manager.getInstalledApplications(PackageManager.GET_META_DATA)

        val permission2:String = "android.permission.READ_PHONE_STATE"
        val permission3:String = "android.permission.PACKAGE_USAGE_STATS"
        val permission4:String = "android.permission.UPDATE_APP_OPS_STATS"
        val permission_array = arrayOf( permission2,permission3,permission4)
        ActivityCompat.requestPermissions(activity!!, permission_array, 0)

        for (p in packages)
        {

            val item =  ApplicationInfo(p)

               tx=TrafficStats.getUidTxBytes(item.uid)
               rx=TrafficStats.getUidRxBytes(item.uid)
              current_tx=TrafficStats.getUidTxPackets(item.uid)
              current_rx=TrafficStats.getUidRxPackets(item.uid)

        }

        val networkStatsManager by lazy {
            context!!.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        }

        var iPackageCount:Int=0
        var iPackageCountWithStat:Int=0

        for (p in packages)
        {
            iPackageCount=iPackageCount+1
            var iPos:Int=0

            val idsub= getSubscriberId(inflater!!.context,ConnectivityManager.TYPE_MOBILE)

            var totalBuckets:Int=0
            var totalBucketsWithVal:Int=0
            var totalBucketsWithNoVal:Int=0
            var networkStatsByApp: NetworkStats? = null

            iPos=p.packageName.indexOf("ipsec.service",0,true)

            if (iPos==0)
            {
                networkStatsByApp=networkStatsManager.queryDetailsForUid(ConnectivityManager.TYPE_MOBILE,idsub, System.currentTimeMillis()-(10000000000), System.currentTimeMillis(),  p.uid  )

            }else {
                networkStatsByApp=networkStatsManager.queryDetailsForUid(ConnectivityManager.TYPE_MOBILE,idsub, System.currentTimeMillis()-(10000000000), System.currentTimeMillis(),android.os.Process.myUid())

                iPos=0

                 if  (networkStatsByApp!=null)
                     {

                         iPackageCountWithStat=iPackageCountWithStat+1

                         resultSocketMessage.set( iPackageCount-1,  p.packageName)

                       do {

                             val bucket = NetworkStats.Bucket()
                             networkStatsByApp!!.getNextBucket(bucket)

                           if ( bucket.rxBytes.toInt()>0 || bucket.txBytes.toInt()>0 ){

                               totalBucketsWithVal= totalBucketsWithVal+1

                           }else{
                               totalBucketsWithNoVal= totalBucketsWithNoVal+1
                           }


                             totalBuckets++
                           } while (networkStatsByApp!!.hasNextBucket())

               }
           }

        }

        resultSocketMessage.sort(0,iPackageCountWithStat)
        val adapter1 = ArrayAdapter<String>(context, android.R.layout.simple_list_item_1 ,  resultSocketMessage )
        mListView.setAdapter(adapter1)

        return view

        return inflater.inflate(R.layout.activity_package_sender, container, false)
    }

    private fun getDateTimeFromEpocLongOfSeconds(epoc: Long): String? {
        try {
            val netDate = Date(epoc*1000)
            return netDate.toString()
        } catch (e: Exception) {
            return e.toString()
        }
    }

    private fun getSubscriberId(
        context: Context,
        networkType: Int
    ): String? {
        if (ConnectivityManager.TYPE_MOBILE == networkType) {
            val tm =
                context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

            val permission:String = "android.permission.READ_PHONE_STATE"

            if (context.checkSelfPermission(permission)
                != PackageManager.PERMISSION_GRANTED) {

                return tm.subscriberId

            }else{
                return tm.subscriberId
            }

        }
        return ""
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        activity?.setTitle("")

    }

}






