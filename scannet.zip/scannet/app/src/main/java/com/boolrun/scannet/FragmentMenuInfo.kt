package com.boolrun.scannet

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast

import androidx.fragment.app.Fragment
import java.util.*

class FragmentMenuInfo : Fragment() {

    private lateinit var viewModel: MViewModel

    companion object {

        @JvmStatic
        fun newInstance() =
            FragmentConfig().apply {
                arguments = Bundle().apply {

                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        viewModel= MViewModel()

        val view: View = inflater!!.inflate(R.layout.activity_menu_info, container, false)

        val btn_infonetwork = view.findViewById(R.id.cmdInfoNetwork) as Button
        val btn_config = view.findViewById(R.id.cmdConfiguration) as Button
        val btn_packagesender = view.findViewById(R.id.cmdPackageSender) as Button
        val btn_disclaimer = view.findViewById(R.id.cmdDisclamer) as Button
        val btn_privacy = view.findViewById(R.id.cmdPrivacy) as Button
        val btn_terms = view.findViewById(R.id.cmdTerm) as Button
        val btn_support = view.findViewById(R.id.cmdSupport) as Button
        val btn_help = view.findViewById(R.id.cmdHelp) as Button

        var strLanguage:String= Locale.getDefault().getDisplayLanguage()

        var browserIntentDisclaimer: Intent ?= null
        var browserIntentPrivacy: Intent ?= null
        var browserIntentTerms: Intent ?= null
        var browserIntentHelp: Intent ?= null

        if (strLanguage.indexOf("fran",0)>-1){
            browserIntentDisclaimer= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/legal/disclaimer_fr.pdf"))
            browserIntentPrivacy= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/legal/privacy_fr.pdf"))
            browserIntentTerms= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/legal/terms_and_conditions_fr.pdf"))
            browserIntentHelp= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/document/guide/users_guide_fr.pdf"))
        }else{
            browserIntentDisclaimer= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/legal/disclaimer_en.pdf"))
            browserIntentPrivacy= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/legal/privacy_en.pdf"))
            browserIntentTerms= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/legal/terms_and_conditions_en.pdf"))
            browserIntentHelp= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/document/guide/users_guide_en.pdf"))
        }

        btn_support?.setOnClickListener() {
            val recipient = "support@boolrun.com"
            val subject = activity!!.getString(R.string.title_message_email)
            val message = ""
            sendEmail(recipient, subject, message)
        }

        btn_infonetwork?.setOnClickListener() {
                ButtonInfoNetworkClicked()
            }

        btn_config?.setOnClickListener() {
            ButtonConfigClicked()
        }

        btn_packagesender?.setOnClickListener() {
            ButtonPackageSenderClicked()
        }

        btn_disclaimer?.setOnClickListener() {
            startActivity(browserIntentDisclaimer)
        }

        btn_privacy?.setOnClickListener() {
            startActivity(browserIntentPrivacy)
        }

        btn_terms?.setOnClickListener() {
            startActivity(browserIntentTerms)
        }

        btn_help?.setOnClickListener() {
            startActivity(browserIntentHelp)
        }


        return view

    }

    private fun  ButtonInfoNetworkClicked() {

        val frgInfoNerwork=FragmentStatus()

        val fragmentManager = activity!!.supportFragmentManager
        val fragmentTransaction=  fragmentManager.beginTransaction()
        if (viewModel.lastActiveFragmentTag != null) {
            val lastFragment = fragmentManager.findFragmentByTag(viewModel.lastActiveFragmentTag)
            if (lastFragment != null)
                fragmentTransaction.hide(lastFragment)
        }

        fragmentTransaction.replace(R.id.fragmentContainer,frgInfoNerwork)
        fragmentTransaction.disallowAddToBackStack()

        fragmentTransaction.commit()

    }

    private fun ButtonConfigClicked() {

        val frgConfig=FragmentConfig()

        val fragmentManager = activity!!.supportFragmentManager
        val fragmentTransaction=  fragmentManager.beginTransaction()
        if (viewModel.lastActiveFragmentTag != null) {
            val lastFragment = fragmentManager.findFragmentByTag(viewModel.lastActiveFragmentTag)
            if (lastFragment != null)
                fragmentTransaction.hide(lastFragment)
        }

        fragmentTransaction.replace(R.id.fragmentContainer,frgConfig)
        fragmentTransaction.disallowAddToBackStack()

        fragmentTransaction.commit()

    }

    private fun ButtonPackageSenderClicked() {

        val frgPackageSender=FragmentPackageSender()

        val fragmentManager = activity!!.supportFragmentManager
        val fragmentTransaction=  fragmentManager.beginTransaction()
        if (viewModel.lastActiveFragmentTag != null) {
            val lastFragment = fragmentManager.findFragmentByTag(viewModel.lastActiveFragmentTag)
            if (lastFragment != null)
                fragmentTransaction.hide(lastFragment)
        }

        fragmentTransaction.replace(R.id.fragmentContainer,frgPackageSender)
        fragmentTransaction.disallowAddToBackStack()

        fragmentTransaction.commit()

    }

    fun showMessage(strMessage: String) {
        val toast_obj= Toast.makeText(this.activity,strMessage, Toast.LENGTH_SHORT)
        toast_obj.setGravity(Gravity.TOP, 0, 120)
        toast_obj.show()
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        activity?.setTitle("")

    }

    private fun sendEmail(recipient: String, subject: String, message: String) {

        val mIntent = Intent(Intent.ACTION_SEND)

        mIntent.data = Uri.parse("mailto:")
        mIntent.type = "text/plain"

        mIntent.putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))

        mIntent.putExtra(Intent.EXTRA_SUBJECT, subject)

        mIntent.putExtra(Intent.EXTRA_TEXT, message)


        try {

            startActivity(Intent.createChooser(mIntent, activity!!.getString(R.string.title_intent_email) ))
        }
        catch (e: Exception){

        }

    }










}