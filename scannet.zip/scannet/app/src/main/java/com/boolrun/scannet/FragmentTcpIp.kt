package com.boolrun.scannet

import android.app.Activity
import android.app.Application
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.AsyncTask
import android.os.Bundle
import android.os.StrictMode
import android.text.format.Formatter
import android.text.format.Formatter.formatIpAddress
import android.util.Log
import android.view.*
import android.view.View.INVISIBLE
import android.view.View.VISIBLE
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.activity_tcpip.*
import java.io.IOException
import java.lang.ref.WeakReference
import java.net.*
import java.util.*
import java.util.concurrent.*


class strTCPFavoris {
    var strValue: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class strUDPFavoris {
    var strValue: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class strBSSIDforMap {
    var strValue: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class strTempsDefaut {
    var strValue: String = "0"

        get() = field

        set(value) {
            field = value
        }
}

class strTempsDefautWiFi {
    var strValue: String = "0"

        get() = field

        set(value) {
            field = value
        }
}

class strMaxPrecision {
    var strValue: String = "0"

        get() = field

        set(value) {
            field = value
        }
}

class strAutoScan {
    var strValue: String = "0"

        get() = field

        set(value) {
            field = value
        }
}

class strDisplayMode {
    var strValue: String = "0"

        get() = field

        set(value) {
            field = value
        }
}

class strStatusTCP {
    var strValue: String = "0"

        get() = field

        set(value) {
            field = value
        }
}

class boolPortScan {
    var bValue: Boolean = false

        get() = field

        set(value) {
            field = value
        }
}

class boolSimple {
    var bValue: Boolean = false

        get() = field

        set(value) {
            field = value
        }
}

class strIPAdr1 {
    var strAdr1: String = "0"

        get() = field

        set(value) {
            field = value
        }
}


class strAdrDNS {
    var strName: String = "0"

        get() = field

        set(value) {
            field = value
        }
}

class strPortDe {
    var PortID: String = "0"

              get() = field

        set(value) {
            field = value
        }
}

class strPortA {
    var PortID: String = "0"

        get() = field

        set(value) {
            field = value
        }
}

class indexPort {
    var indexID: Number = 0

        get() = field

        set(value) {
            field = value
        }
}


class numTempsReponse {
    var numMilliseconde: Number = 0

        get() = field

        set(value) {
            field = value
        }
}

class numTotalAddress {
    var numTotal:Int = 0

        get() = field

        set(value) {
            field = value
        }
}


class numTotalPort {
    var numTotal: Number = 0

        get() = field

        set(value) {
            field = value
        }
}

class numCurrentPort {
    var PortID: Number = 0

        get() = field

        set(value) {
            field = value
        }
}

class numPortLastID {
    var numItemID: Number = 0

        get() = field

        set(value) {
            field = value
        }
}

class strResultSocketMessage {
    var strTextMessage: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class strCurrentAdressIP {
    var strAdresse: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class strCurrentPortID {
    var strPortID: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class boolHideFailed {
    var boolHideFailed: Boolean = true

        get() = field

        set(value) {
            field = value
        }
}

class indexPortWhenHideFailedIsTrue {
    var indexID: Number = 0

        get() = field

        set(value) {
            field = value
        }
}

class boolIPClassWildCard {
    var boolIsWildCard: Boolean = true

        get() = field

        set(value) {
            field = value
        }
}

class indexAdressIP {
    var indexID: Number = 0

        get() = field

        set(value) {
            field = value
        }
}

class indexAsterixAdressIP {
    var indexID: Number = 0

        get() = field

        set(value) {
            field = value
        }
}

class adresseOctet4Diff {
    var numOctet: Number = 0

        get() = field

        set(value) {
            field = value
        }
}

class indexOctet4 {
    var numIndex: Number = 0

        get() = field

        set(value) {
            field = value
        }
}

class strCurrentWildCardAdressIP {
    var strAdresse: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class indexIpAdressWhenHideFailedIsTrue {
    var indexID: Number = 0

        get() = field

        set(value) {
            field = value
        }
}

class pubTb {
    var objTb: Toolbar?=null

        get() = field

        set(value) {
            field = value
        }
}

class intPreviousWiFiCount {
    var intCount: Int = 0

        get() = field

        set(value) {
            field = value
        }
}

class mIPActivity {
    var objActivity: Activity?=null
}


class strTextSentUDP {
    var strText: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class strResultDNS {
    var strAddress: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class strAdrPart1{
    var strAddress: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class strAdrPart2{
    var strAddress: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class strAdrPart3{
    var strAddress: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class strAdrPart4{
    var strAddress: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class strAdrPart5{
    var strAddress: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class boolPortDeIsNullAndEmpty {
    var boolIs: Boolean = true

        get() = field

        set(value) {
            field = value
        }
}

class boolPortAIsNullAndEmpty {
    var boolIs: Boolean = true

        get() = field

        set(value) {
            field = value
        }
}

class boolScanFavorites {
    var boolIs: Boolean = true

        get() = field

        set(value) {
            field = value
        }
}

class strPreviousPosition{
    var strPosition: String = ""

        get() = field

        set(value) {
            field = value
        }
}

class MyApplication: Application() {
    companion object {

        val strPreviousPosition=strPreviousPosition()
        val intPreviousWiFiCount=intPreviousWiFiCount()
        val boolScanFavorites=boolScanFavorites()
        val strTCPFavoris=strTCPFavoris()
        val strUDPFavoris=strUDPFavoris()
        val boolPortAIsNullAndEmpty=boolPortAIsNullAndEmpty()
        val boolPortDeIsNullAndEmpty=boolPortDeIsNullAndEmpty()
        val strAdrPart1=strAdrPart1()
        val strAdrPart2=strAdrPart2()
        val strAdrPart3=strAdrPart3()
        val strAdrPart4=strAdrPart4()
        val strAdrPart5=strAdrPart5()
        val strResultDNS=strResultDNS()
        val strTextSentUDP=strTextSentUDP()
        val pubTb=pubTb()
        val strDisplayMode=strDisplayMode()
        val strAutoScan= strAutoScan()
        val strTempsDefaut=strTempsDefaut()
        val strMaxPrecision=strMaxPrecision()
        val strTempsDefautWiFi=strTempsDefautWiFi()
        val boolPortScan=boolPortScan()
        val  asyncRunning= asyncRunning()
        val boolSimple=boolSimple()
        val  indexIpAdressWhenHideFailedIsTrue= indexIpAdressWhenHideFailedIsTrue()
        val indexAsterixAdressIP=indexAsterixAdressIP()
        val indexAdressIP=indexAdressIP()
        val boolIPClassWildCard=boolIPClassWildCard()
        val indexPortWhenHideFailedIsTrue=indexPortWhenHideFailedIsTrue()
        val boolHideFailed=boolHideFailed()
        val strPortDe= strPortDe()
        val strIPAdr1= strIPAdr1()
        val strPortA= strPortA()
        val indexPort=indexPort()
        val numTotalPort =numTotalPort()
        val numTotalAddress =numTotalAddress()
        val numCurrentPort= numCurrentPort()
        val numPortLastID=numPortLastID()
        val strResultSocketMessage=strResultSocketMessage()
        val strCurrentAdressIP=strCurrentAdressIP()
        val strCurrentPortID=strCurrentPortID()
        val numTempsReponse=numTempsReponse()
        val strAdrDNS= strAdrDNS()
        val numOctet4Diff= adresseOctet4Diff()
        val strStatusTCP=strStatusTCP()
        val strBSSIDforMap=strBSSIDforMap()
        var resultSocketMessage = Array(1) {""}
        var resultPreviousWiFi = Array(1) {""}
 val indexOctet4=indexOctet4()



    }

    override fun onCreate() {
        super.onCreate()



    }


}


class FragmentTcpIp : Fragment() {




    companion object {

        private fun validAddress(strAddress: String,intPositionMessage:Int):Boolean {

            MyApplication.strCurrentAdressIP.strAdresse=strAddress
            val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
            val SCT: ScanAddressTask= ScanAddressTask(SPRUT)
            SCT.run()

            if (MyApplication.strResultSocketMessage.strTextMessage!="OK") {

               return true
            }

            return false
        }

        private fun validAddressSansPosition(strAddress: String):Boolean {

            MyApplication.strCurrentAdressIP.strAdresse=strAddress
            val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
            val SCT: ScanAddressTask= ScanAddressTask(SPRUT)
            SCT.run()

            if (MyApplication.strResultSocketMessage.strTextMessage=="OK") {
                return true
            }

            return false
        }



        val mIPActivity= mIPActivity()
        private const val DEBUG_TAG = "NetworkStatusExample"
        private val mListView: ListView? = null
        private var boolEstJoignable:Boolean=false

        class NetworkLogicTask internal constructor(context: FragmentTcpIp) : AsyncTask<String, String, String?>() {
            private val activityReference: WeakReference<FragmentTcpIp> = WeakReference(context)
            override fun doInBackground(vararg adresseIP: String): String {
                return try {



                    var longTemps:Long= MyApplication.numTempsReponse.numMilliseconde.toLong()
                    if(MyApplication.strStatusTCP.strValue=="Stop") {

                        cancel(true)
                        return ""
                    }



                   val activity = activityReference.get()
                   if (activity == null) "Aucun port"



                    MyApplication.strCurrentAdressIP.strAdresse=adresseIP.get(0).toString()
                    val txtCpt = activity!!.view!!.findViewById<View>(R.id.txtCompte) as TextView
                    val txtTotal = activity!!.view!!.findViewById<View>(R.id.txtTotal) as TextView

                    var iTotalPort:Int=0
                    var iCompteur:Int=0
                    var numPortVarDe: Int= 0
                    var numPortVarA: Int= 0

                    var countOK:Int=0

                    val radioUDP = activity!!.view!!.findViewById<View>(R.id.radioUDP) as RadioButton
                    numPortVarDe= MyApplication.strPortDe.PortID.toInt()
                    numPortVarA= MyApplication.strPortA.PortID.toInt()

                    var currentPort:Int=MyApplication.numCurrentPort.PortID.toInt()
                    MyApplication.numPortLastID.numItemID= numPortVarA
                    MyApplication.strCurrentPortID.strPortID= currentPort.toString()

                   //Favori début
                    if(MyApplication.boolScanFavorites.boolIs==true && MyApplication.boolPortAIsNullAndEmpty.boolIs==true)
                    {

                        //Port UDP Favori
                        if (radioUDP.isChecked){

                            val strsAdresseFavori = MyApplication.strUDPFavoris.strValue
                            val arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()

                            //Port UPD Favori une adresse
                            if (MyApplication.boolSimple.bValue==true){



                            if(validAddress(adresseIP.get(0).toString(),0))  {
                                  return ""
                            }

                            MyApplication.resultSocketMessage = Array(arrayAdresseFavori.size) {""}
                            for(x in 0..arrayAdresseFavori.size-1){

                                MyApplication.numCurrentPort.PortID=arrayAdresseFavori[x].toInt()
                                val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                val SCT: ScanPortUDPTask=ScanPortUDPTask(SPRUT,mIPActivity.objActivity)
                                SCT.NumPort=arrayAdresseFavori[x].toInt()
                                SCT.run()
                                var strResultMessage:String
                                strResultMessage= MyApplication.strResultSocketMessage.strTextMessage
                                if (MyApplication.boolHideFailed.boolHideFailed==false){
                                    MyApplication.resultSocketMessage.set(x, strResultMessage)
                                }else{
                                    if(strResultMessage.indexOf("Err",0,true)>-1){
                                        MyApplication.resultSocketMessage.set(countOK,   strResultMessage)
                                        countOK=countOK+1
                                  }
                                }
                              }
                            }

                            //Port UDP Favori adresse multiple
                            if (MyApplication.boolSimple.bValue==false && MyApplication.boolPortScan.bValue==false && MyApplication.boolIPClassWildCard.boolIsWildCard==true){

                                val strAdrPart1=MyApplication.strAdrPart1.strAddress
                                val strAdrPart2=MyApplication.strAdrPart2.strAddress
                                val strAdrPart3=MyApplication.strAdrPart3.strAddress
                                val strAdrPart4=MyApplication.strAdrPart4.strAddress
                                val strAdrPart5=MyApplication.strAdrPart5.strAddress

                                //Port UDP Favori scope
                                if (strAdrPart5!="No"){

                                    val diffadr:Int=strAdrPart5.toInt()-strAdrPart4.toInt()
                                    var part4:Int=0

                                    MyApplication.resultSocketMessage = Array(arrayAdresseFavori.size*(diffadr+1)) {""}

                                    for(x in 0..diffadr) {

                                        if(MyApplication.strStatusTCP.strValue=="Stop") {
                                            cancel(true)
                                            return ""
                                        }

                                        part4=strAdrPart4.toInt()+x
                                        MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"."+strAdrPart2+"."+strAdrPart3+"."+part4.toString()

                                           val estJoignable:Boolean=validAddressSansPosition(MyApplication.strCurrentAdressIP.strAdresse)



                                            for(y in 0..arrayAdresseFavori.size-1){

                                            if(!estJoignable)  {
                                                if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                    MyApplication.resultSocketMessage.set(iCompteur, MyApplication.strCurrentAdressIP.strAdresse+  " " +mIPActivity.objActivity!!.getString(R.string.mess_non_joignable) +  "\n")
                                                }
                                            }

                                            else{

                                            MyApplication.numCurrentPort.PortID=arrayAdresseFavori[y].toInt()
                                            val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                            val SCT: ScanPortUDPTask=ScanPortUDPTask(SPRUT,mIPActivity.objActivity)
                                            SCT.NumPort=arrayAdresseFavori[y].toInt()
                                            SCT.run()
                                            var strResultMessage:String
                                            strResultMessage= MyApplication.strResultSocketMessage.strTextMessage
                                            if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                MyApplication.resultSocketMessage.set(iCompteur, strResultMessage)
                                            }else{
                                                if(strResultMessage.indexOf("Err",0,true)>-1){
                                                    MyApplication.resultSocketMessage.set(countOK,   strResultMessage)
                                                    countOK=countOK+1
                                                }
                                            }
                                            }
                                            iCompteur=iCompteur+1
                                            mIPActivity.objActivity!!.runOnUiThread {
                                                txtCpt.setText(iCompteur.toString())
                                            }
                                        }
                                    }
                                    mIPActivity.objActivity!!.runOnUiThread {
                                        val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                                        progressBar.visibility = View.INVISIBLE
                                    }

                                }

                                //Port UDP Favori wildcard
                                else{

                                    if (strAdrPart1=="*" || strAdrPart2=="*" || strAdrPart3=="*" || strAdrPart4=="*"){

                                        MyApplication.resultSocketMessage = Array(arrayAdresseFavori.size*256) {""}

                                        for(x in 0..255) {

                                            if(MyApplication.strStatusTCP.strValue=="Stop") {
                                                cancel(true)
                                                return ""
                                            }

                                            if (strAdrPart1=="*"){
                                                MyApplication.strCurrentAdressIP.strAdresse=x.toString()+"."+strAdrPart2+"."+strAdrPart3+"."+strAdrPart4
                                            }

                                            if (strAdrPart2=="*"){
                                                MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"." + x.toString()+"."+strAdrPart3+"."+strAdrPart4
                                            }

                                            if (strAdrPart3=="*"){
                                                MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"." +strAdrPart2+"."+ x.toString()+ "."+strAdrPart4
                                            }

                                            if (strAdrPart4=="*"){
                                                MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"."+strAdrPart2+"."+strAdrPart3+"."+x.toString()
                                            }

                                            val estJoignable:Boolean=validAddressSansPosition(MyApplication.strCurrentAdressIP.strAdresse)

                                            for(y in 0..arrayAdresseFavori.size-1){


                                                if(!estJoignable)  {
                                                    if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                        MyApplication.resultSocketMessage.set(iCompteur, MyApplication.strCurrentAdressIP.strAdresse+  " " +mIPActivity.objActivity!!.getString(R.string.mess_non_joignable) +  "\n")
                                                    }
                                                }

                                                else{

                                                MyApplication.numCurrentPort.PortID=arrayAdresseFavori[y].toInt()
                                                val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                                val SCT: ScanPortUDPTask=ScanPortUDPTask(SPRUT,mIPActivity.objActivity)
                                                SCT.NumPort=arrayAdresseFavori[y].toInt()
                                                SCT.run()
                                                var strResultMessage:String
                                                strResultMessage= MyApplication.strResultSocketMessage.strTextMessage
                                                if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                    MyApplication.resultSocketMessage.set(iCompteur, strResultMessage)
                                                }else{
                                                    if(strResultMessage.indexOf("Err",0,true)>-1){
                                                        MyApplication.resultSocketMessage.set(countOK,   strResultMessage)
                                                        countOK=countOK+1
                                                    }
                                                }
                                                }
                                                iCompteur= iCompteur+1
                                                mIPActivity.objActivity!!.runOnUiThread {
                                                    txtCpt.setText(iCompteur.toString())
                                                }
                                            }


                                        }
                                        mIPActivity.objActivity!!.runOnUiThread {
                                            val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                                            progressBar.visibility = View.INVISIBLE
                                        }

                                    }
                                }

                            }

                        }

                        //Port TCP Favori
                        else{
                            val strsAdresseFavori = MyApplication.strTCPFavoris.strValue
                            val arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()

                            //Port TCP Favori une adresse
                            if (MyApplication.boolSimple.bValue==true){

                                MyApplication.strCurrentAdressIP.strAdresse=adresseIP.get(0).toString()

                                if(validAddress(MyApplication.strCurrentAdressIP.strAdresse,0))  {
                                    return ""
                                }

                                MyApplication.resultSocketMessage = Array(arrayAdresseFavori.size) {""}
                                for(x in 0..arrayAdresseFavori.size-1){

                                    MyApplication.numCurrentPort.PortID=arrayAdresseFavori.get(x).toInt()
                                    MyApplication.strCurrentAdressIP.strAdresse=adresseIP.get(0).toString()
                                    val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                    val SCT: ScanPortTask=ScanPortTask(SPRUT)
                                    SCT.NumPort=arrayAdresseFavori[x].toInt()
                                    SCT.run()

                                    if (MyApplication.boolHideFailed.boolHideFailed==false){
                                        if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                            val strResult=activity!!.getString(R.string.connexion) + adresseIP.get(0).toString() + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                            MyApplication.resultSocketMessage.set(x,  strResult)
                                        }else{
                                            val strResult=activity!!.getString(R.string.echec_sans_deux_point) + adresseIP.get(0).toString() + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                            MyApplication.resultSocketMessage.set(x,  strResult)
                                        }
                                    }else{

                                        if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                            val strResult=activity!!.getString(R.string.connexion) + adresseIP.get(0).toString() + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                            MyApplication.resultSocketMessage.set(countOK,  strResult)
                                            countOK=countOK+1
                                        }else {
                                            val strResult=""
                                           // MyApplication.resultSocketMessage.set(0,  strResult)
                                        }
                                    }
                                }
                            }

                            //Port TCP Favori multiple adresse
                            if (MyApplication.boolSimple.bValue==false && MyApplication.boolPortScan.bValue==false && MyApplication.boolIPClassWildCard.boolIsWildCard==true){

                                val strAdrPart1=MyApplication.strAdrPart1.strAddress
                                val strAdrPart2=MyApplication.strAdrPart2.strAddress
                                val strAdrPart3=MyApplication.strAdrPart3.strAddress
                                val strAdrPart4=MyApplication.strAdrPart4.strAddress
                                val strAdrPart5=MyApplication.strAdrPart5.strAddress

                                //Port TCP Favori scope
                                if (strAdrPart5!="No"){

                                    val diffadr:Int=strAdrPart5.toInt()-strAdrPart4.toInt()
                                    var part4:Int=0

                                    MyApplication.resultSocketMessage = Array(arrayAdresseFavori.size*(diffadr+1)) {""}

                                    for(x in 0..diffadr) {

                                        if(MyApplication.strStatusTCP.strValue=="Stop") {
                                            cancel(true)
                                            return ""
                                        }

                                        part4=strAdrPart4.toInt()+x
                                        MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"."+strAdrPart2+"."+strAdrPart3+"."+part4.toString()

                                        val estJoignable:Boolean=validAddressSansPosition(MyApplication.strCurrentAdressIP.strAdresse)

                                        for(y in 0..arrayAdresseFavori.size-1){

                                            if(!estJoignable)  {
                                                if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                    MyApplication.resultSocketMessage.set(iCompteur, MyApplication.strCurrentAdressIP.strAdresse+  " " +mIPActivity.objActivity!!.getString(R.string.mess_non_joignable) +  "\n")
                                                }
                                            }

                                            else{

                                            MyApplication.numCurrentPort.PortID=arrayAdresseFavori[y].toInt()
                                            MyApplication.strCurrentAdressIP.strAdresse= MyApplication.strCurrentAdressIP.strAdresse
                                            val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                            val SCT: ScanPortTask=ScanPortTask(SPRUT)
                                            SCT.NumPort=arrayAdresseFavori[y].toInt()
                                            SCT.run()

                                            if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                                    val strResult=activity!!.getString(R.string.connexion) +  MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                    MyApplication.resultSocketMessage.set(iCompteur,  strResult)
                                                }else{
                                                    val strResult=activity!!.getString(R.string.echec_sans_deux_point) + MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                    MyApplication.resultSocketMessage.set(iCompteur,  strResult)
                                                }
                                            }else{

                                                if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                                    val strResult=activity!!.getString(R.string.connexion) +  MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                    MyApplication.resultSocketMessage.set(countOK,  strResult)
                                                    countOK=countOK+1
                                                }else {
                                                    val strResult=""
                                                    // MyApplication.resultSocketMessage.set(0,  strResult)
                                                }
                                            }
                                            }
                                            iCompteur=iCompteur+1
                                            mIPActivity.objActivity!!.runOnUiThread {
                                                txtCpt.setText(iCompteur.toString())
                                            }

                                        }

                                    }
                                    mIPActivity.objActivity!!.runOnUiThread {
                                        val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                                        progressBar.visibility = View.INVISIBLE
                                    }

                                }

                                //Port TCP Favori wildcard
                                else{

                                    if (strAdrPart1=="*" || strAdrPart2=="*" || strAdrPart3=="*" || strAdrPart4=="*"){


                                        MyApplication.resultSocketMessage = Array(arrayAdresseFavori.size*256) {""}

                                        for(x in 0..255) {

                                            if(MyApplication.strStatusTCP.strValue=="Stop") {
                                                cancel(true)
                                                return ""
                                            }

                                            if (strAdrPart1=="*"){
                                                MyApplication.strCurrentAdressIP.strAdresse=x.toString()+"."+strAdrPart2+"."+strAdrPart3+"."+strAdrPart4
                                            }

                                            if (strAdrPart2=="*"){
                                                MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"." + x.toString()+"."+strAdrPart3+"."+strAdrPart4
                                            }

                                            if (strAdrPart3=="*"){
                                                MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"." +strAdrPart2+"."+ x.toString()+ "."+strAdrPart4
                                            }

                                            if (strAdrPart4=="*"){
                                                MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"."+strAdrPart2+"."+strAdrPart3+"."+x.toString()
                                            }

                                            val estJoignable:Boolean=validAddressSansPosition(MyApplication.strCurrentAdressIP.strAdresse)

                                            for(y in 0..arrayAdresseFavori.size-1){


                                                if(!estJoignable)  {
                                                    if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                        MyApplication.resultSocketMessage.set(iCompteur, MyApplication.strCurrentAdressIP.strAdresse+  " " +mIPActivity.objActivity!!.getString(R.string.mess_non_joignable) +  "\n")
                                                    }
                                                }

                                          else{

                                                MyApplication.numCurrentPort.PortID=arrayAdresseFavori[y].toInt()
                                                MyApplication.strCurrentAdressIP.strAdresse= MyApplication.strCurrentAdressIP.strAdresse
                                                val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                                val SCT: ScanPortTask=ScanPortTask(SPRUT)
                                                SCT.NumPort=arrayAdresseFavori[y].toInt()
                                                SCT.run()

                                                if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                    if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                                        val strResult=activity!!.getString(R.string.connexion) +  MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                        MyApplication.resultSocketMessage.set(iCompteur,  strResult)
                                                    }else{
                                                        val strResult=activity!!.getString(R.string.echec_sans_deux_point) + MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                        MyApplication.resultSocketMessage.set(iCompteur,  strResult)
                                                    }
                                                }else{

                                                    if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                                        val strResult=activity!!.getString(R.string.connexion) +  MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                        MyApplication.resultSocketMessage.set(countOK,  strResult)
                                                        countOK=countOK+1
                                                    }else {
                                                        val strResult=""
                                                        // MyApplication.resultSocketMessage.set(0,  strResult)
                                                    }
                                                }
                                                }
                                                iCompteur= iCompteur+1
                                                mIPActivity.objActivity!!.runOnUiThread {
                                                    txtCpt.setText(iCompteur.toString())
                                                }
                                            }


                                        }

                                        mIPActivity.objActivity!!.runOnUiThread {
                                            val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                                            progressBar.visibility = View.INVISIBLE
                                        }

                                    }
                                }
                            }
                         }//marqueur else
                    }
                    //Favori fin


                    //adresse simple
                    if (MyApplication.boolSimple.bValue==true && MyApplication.boolScanFavorites.boolIs==false && MyApplication.boolScanFavorites.boolIs==false){

                        MyApplication.strCurrentAdressIP.strAdresse=adresseIP.get(0).toString()
                        val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                        val SCT: ScanAddressTask= ScanAddressTask(SPRUT)
                        SCT.run()

                        if (MyApplication.strResultSocketMessage.strTextMessage=="OK") {
                            val strResultatAdresse:String=  MyApplication.strCurrentAdressIP.strAdresse+  " " +activity!!.getString(R.string.mess_joignable) +  "\n"+MyApplication.strResultDNS.strAddress
                            MyApplication.resultSocketMessage.set(0,   strResultatAdresse)
                        }else{
                            if (MyApplication.boolHideFailed.boolHideFailed==false){
                                val strResultatAdresse:String=  MyApplication.strCurrentAdressIP.strAdresse+  " " +activity!!.getString(R.string.mess_non_joignable) +  "\n"
                                MyApplication.resultSocketMessage.set(0,   strResultatAdresse)
                            }
                        }

                        //si juste un port (De)
                        if (MyApplication.strResultSocketMessage.strTextMessage=="OK" && MyApplication.boolPortScan.bValue==true && MyApplication.boolPortDeIsNullAndEmpty.boolIs==false  && MyApplication.boolPortAIsNullAndEmpty.boolIs==true){

                            if(validAddress(adresseIP.get(0).toString(),0))  {
                                return ""
                            }

                            //si port UDP
                            if (radioUDP.isChecked){

                                MyApplication.numCurrentPort.PortID=numPortVarDe
                                MyApplication.strCurrentAdressIP.strAdresse=adresseIP.get(0).toString()
                                val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                val SCT: ScanPortUDPTask=ScanPortUDPTask(SPRUT,mIPActivity.objActivity)
                                SCT.NumPort=numPortVarDe
                                SCT.run()

                                val strResultMessage:String

                                strResultMessage= MyApplication.strResultSocketMessage.strTextMessage

                                if (MyApplication.boolHideFailed.boolHideFailed==false){
                                    MyApplication.resultSocketMessage.set(0,   strResultMessage)
                                }else{
                                    if(strResultMessage.indexOf("Err",0,true)>-1){
                                        MyApplication.resultSocketMessage.set(0,   strResultMessage)
                                    }
                                }

                            //si port TCP
                            }else{

                                MyApplication.numCurrentPort.PortID=numPortVarDe
                                MyApplication.strCurrentAdressIP.strAdresse=adresseIP.get(0).toString()
                                val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                val SCT: ScanPortTask=ScanPortTask(SPRUT)
                                SCT.NumPort=numPortVarDe
                                SCT.run()

                                if (MyApplication.boolHideFailed.boolHideFailed==false){
                                    if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {

                                        val strResult=activity!!.getString(R.string.connexion) + adresseIP.get(0).toString() + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                        MyApplication.resultSocketMessage.set(0,  strResult)
                                    }else{
                                        val strResult=activity!!.getString(R.string.echec_sans_deux_point) + adresseIP.get(0).toString() + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                        MyApplication.resultSocketMessage.set(0,  strResult)
                                    }
                                }else{

                                    if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                        val strResult=activity!!.getString(R.string.connexion) + adresseIP.get(0).toString() + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                        MyApplication.resultSocketMessage.set(0,  strResult)
                                    }else {
                                        val strResult=""
                                        MyApplication.resultSocketMessage.set(0,  strResult)
                                    }
                                }
                            }
                        }
                    }

                    //Recherche Multiple sans port
                    if (MyApplication.boolSimple.bValue==false && MyApplication.boolPortScan.bValue==false && MyApplication.boolIPClassWildCard.boolIsWildCard==true  && MyApplication.boolScanFavorites.boolIs==false &&  MyApplication.boolPortDeIsNullAndEmpty.boolIs==true){


                        val strAdrPart1=MyApplication.strAdrPart1.strAddress
                        val strAdrPart2=MyApplication.strAdrPart2.strAddress
                        val strAdrPart3=MyApplication.strAdrPart3.strAddress
                        val strAdrPart4=MyApplication.strAdrPart4.strAddress
                        val strAdrPart5=MyApplication.strAdrPart5.strAddress

                        //Recherche Multiple sans port scope
                        if (strAdrPart5!="No"){

                            val diffadr:Int=strAdrPart5.toInt()-strAdrPart4.toInt()
                            var part4:Int=0
                            MyApplication.resultSocketMessage = Array(diffadr+1) {""}
                            for(x in 0..diffadr) {

                                if(MyApplication.strStatusTCP.strValue=="Stop") {
                                    cancel(true)
                                    return ""
                                }

                                part4=strAdrPart4.toInt()+x
                                MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"."+strAdrPart2+"."+strAdrPart3+"."+part4.toString()

                                val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                val SCT: ScanAddressTask= ScanAddressTask(SPRUT)
                                SCT.run()

                                if ( MyApplication.strResultSocketMessage.strTextMessage=="OK") {
                                    if (MyApplication.boolHideFailed.boolHideFailed==false){
                                        val strResultatAdresse:String=  MyApplication.strCurrentAdressIP.strAdresse+  " " +activity!!.getString(R.string.mess_joignable) +  "\n"+MyApplication.strResultDNS.strAddress
                                        MyApplication.resultSocketMessage.set(x,   strResultatAdresse)
                                    }else{
                                        val strResultatAdresse:String=  MyApplication.strCurrentAdressIP.strAdresse+  " " +activity!!.getString(R.string.mess_joignable) +  "\n"+MyApplication.strResultDNS.strAddress
                                        MyApplication.resultSocketMessage.set(countOK,   strResultatAdresse)
                                        countOK=countOK+1
                                    }

                                }else{
                                    if (MyApplication.boolHideFailed.boolHideFailed==false){
                                        val strResultatAdresse:String=  MyApplication.strCurrentAdressIP.strAdresse+  " " +activity!!.getString(R.string.mess_non_joignable) +  "\n"
                                        MyApplication.resultSocketMessage.set(x,   strResultatAdresse)
                                    }

                                }
                                iCompteur=x+1
                                mIPActivity.objActivity!!.runOnUiThread {
                                    txtCpt.setText(iCompteur.toString())
                                }
                            }
                            mIPActivity.objActivity!!.runOnUiThread {
                                val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                                progressBar.visibility = View.INVISIBLE
                            }

                        }

                        //Recherche multiple sans port wildcard
                        else{

                            if (strAdrPart1=="*" || strAdrPart2=="*" || strAdrPart3=="*" || strAdrPart4=="*"){
                                MyApplication.resultSocketMessage = Array(256) {""}

                                for(x in 0..255) {

                                    if(MyApplication.strStatusTCP.strValue=="Stop") {
                                        cancel(true)
                                        return ""
                                    }

                                    if (strAdrPart1=="*"){
                                        MyApplication.strCurrentAdressIP.strAdresse=x.toString()+"."+strAdrPart2+"."+strAdrPart3+"."+strAdrPart4
                                    }

                                    if (strAdrPart2=="*"){
                                        MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"." + x.toString()+"."+strAdrPart3+"."+strAdrPart4
                                    }

                                    if (strAdrPart3=="*"){
                                        MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"." +strAdrPart2+"."+ x.toString()+ "."+strAdrPart4
                                    }

                                    if (strAdrPart4=="*"){
                                        MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"."+strAdrPart2+"."+strAdrPart3+"."+x.toString()
                                    }

                                    val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                    val SCT: ScanAddressTask= ScanAddressTask(SPRUT)
                                    SCT.run()

                                    if ( MyApplication.strResultSocketMessage.strTextMessage=="OK") {
                                        if (MyApplication.boolHideFailed.boolHideFailed==false){
                                            val strResultatAdresse:String=  MyApplication.strCurrentAdressIP.strAdresse+  " " +activity!!.getString(R.string.mess_joignable) +  "\n"+MyApplication.strResultDNS.strAddress
                                            MyApplication.resultSocketMessage.set(x,   strResultatAdresse)
                                        }else{
                                            val strResultatAdresse:String=  MyApplication.strCurrentAdressIP.strAdresse+  " " +activity!!.getString(R.string.mess_joignable) +  "\n"+MyApplication.strResultDNS.strAddress
                                            MyApplication.resultSocketMessage.set(countOK,   strResultatAdresse)
                                            countOK=countOK+1
                                        }
                                    }else{
                                        if (MyApplication.boolHideFailed.boolHideFailed==false){
                                            val strResultatAdresse:String=  MyApplication.strCurrentAdressIP.strAdresse+  " " +activity!!.getString(R.string.mess_non_joignable) +  "\n"
                                            MyApplication.resultSocketMessage.set(x,   strResultatAdresse)
                                        }
                                    }
                                    iCompteur=x+1
                                    mIPActivity.objActivity!!.runOnUiThread {
                                        txtCpt.setText(iCompteur.toString())
                                    }

                                }
                                mIPActivity.objActivity!!.runOnUiThread {
                                    val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                                    progressBar.visibility = View.INVISIBLE
                                }

                            }
                        }
                    }

                    //Recherche par port multiple
                    if (MyApplication.boolSimple.bValue==false && MyApplication.boolPortScan.bValue==true && MyApplication.boolIPClassWildCard.boolIsWildCard==false  && MyApplication.boolScanFavorites.boolIs==false){

                       MyApplication.strCurrentAdressIP.strAdresse=adresseIP.get(0).toString()
                          val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                         val SCT: ScanAddressTask= ScanAddressTask(SPRUT)
                         SCT.run()

                         if ( MyApplication.strResultSocketMessage.strTextMessage=="Fail") {
                             MyApplication.resultSocketMessage = Array(1) {""}
                             MyApplication.resultSocketMessage.set(0,    MyApplication.strCurrentAdressIP.strAdresse+  " " +activity!!.getString(R.string.mess_non_joignable) +  "\n")

                             cancel(true)
                             return  ""
                         }


                        iTotalPort=numPortVarA-numPortVarDe
                        iTotalPort=iTotalPort+1

                        MyApplication.resultSocketMessage = Array(iTotalPort+1) {""}

                        for (x in 0..iTotalPort-1)
                        {
                            if(MyApplication.strStatusTCP.strValue=="Stop") {

                                cancel(true)
                                return ""
                            }

                            iCompteur=x+1
                            mIPActivity.objActivity!!.runOnUiThread {
                                txtCpt.setText(iCompteur.toString())

                            }

                            //Recherche par port UDP multiple
                            if (radioUDP.isChecked){

                                MyApplication.numCurrentPort.PortID=numPortVarDe+x
                                MyApplication.strCurrentAdressIP.strAdresse=adresseIP.get(0).toString()
                                val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")

                                val SCT: ScanPortUDPTask=ScanPortUDPTask(SPRUT,mIPActivity.objActivity)
                                SCT.NumPort=numPortVarDe+x
                                SCT.run()

                                var strResultMessage:String

                                strResultMessage= MyApplication.strResultSocketMessage.strTextMessage

                                if (MyApplication.boolHideFailed.boolHideFailed==false){
                                    MyApplication.resultSocketMessage.set(x,   strResultMessage)
                                }else{
                                    if(strResultMessage.indexOf("Err",0,true)>-1){
                                        MyApplication.resultSocketMessage.set(countOK,   strResultMessage)
                                        countOK=countOK+1
                                    }

                                }

                            }
                            //Recherche par port TCP multiple
                            else{

                                MyApplication.numCurrentPort.PortID=numPortVarDe+x
                                MyApplication.strCurrentAdressIP.strAdresse=adresseIP.get(0).toString()
                                val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")

                                val SCT: ScanPortTask=ScanPortTask(SPRUT)
                                SCT.NumPort=numPortVarDe+x
                                SCT.run()

                                if (MyApplication.boolHideFailed.boolHideFailed==false){
                                    if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {

                                        val strResult=activity!!.getString(R.string.connexion) + adresseIP.get(0).toString() + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                        MyApplication.resultSocketMessage.set(x,  strResult)
                                    }else{
                                        val strResult=activity!!.getString(R.string.echec_sans_deux_point) + adresseIP.get(0).toString() + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                        MyApplication.resultSocketMessage.set(x,  strResult)
                                    }
                                }else{

                                    if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                        val strResult=activity!!.getString(R.string.connexion) + adresseIP.get(0).toString() + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                        MyApplication.resultSocketMessage.set(countOK,  strResult)
                                        countOK=countOK+1
                                    }

                                }
                            }

                        }

                        mIPActivity.objActivity!!.runOnUiThread {
                            val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                            progressBar.visibility = View.INVISIBLE
                        }

                    }


                    //Wildcard pour un port (Port de)
                    if (MyApplication.boolSimple.bValue==false && MyApplication.boolPortScan.bValue==false && MyApplication.boolIPClassWildCard.boolIsWildCard==true  && MyApplication.boolScanFavorites.boolIs==false &&  MyApplication.boolPortDeIsNullAndEmpty.boolIs==false){

                        if (radioUDP.isChecked){

                            val strAdrPart1=MyApplication.strAdrPart1.strAddress
                            val strAdrPart2=MyApplication.strAdrPart2.strAddress
                            val strAdrPart3=MyApplication.strAdrPart3.strAddress
                            val strAdrPart4=MyApplication.strAdrPart4.strAddress
                            val strAdrPart5=MyApplication.strAdrPart5.strAddress

                            if (strAdrPart5!="No"){

                                val diffadr:Int=strAdrPart5.toInt()-strAdrPart4.toInt()
                                var part4:Int=0

                                MyApplication.resultSocketMessage = Array(diffadr+1) {""}

                                for(x in 0..diffadr) {

                                    if(MyApplication.strStatusTCP.strValue=="Stop") {
                                        cancel(true)
                                        return ""
                                    }

                                    part4=strAdrPart4.toInt()+x
                                    MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"."+strAdrPart2+"."+strAdrPart3+"."+part4.toString()
                                    val estJoignable:Boolean=validAddressSansPosition(MyApplication.strCurrentAdressIP.strAdresse)
                                    if(!estJoignable)  {
                                        if (MyApplication.boolHideFailed.boolHideFailed==false){
                                            MyApplication.resultSocketMessage.set(iCompteur, MyApplication.strCurrentAdressIP.strAdresse+  " " +mIPActivity.objActivity!!.getString(R.string.mess_non_joignable) +  "\n")
                                        }
                                    }

                                    else{

                                            MyApplication.numCurrentPort.PortID=numPortVarDe
                                            val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                            val SCT: ScanPortUDPTask=ScanPortUDPTask(SPRUT,mIPActivity.objActivity)
                                            SCT.NumPort=numPortVarDe
                                            SCT.run()
                                            var strResultMessage:String
                                            strResultMessage= MyApplication.strResultSocketMessage.strTextMessage
                                            if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                MyApplication.resultSocketMessage.set(iCompteur, strResultMessage)
                                            }else{
                                                if(strResultMessage.indexOf("Err",0,true)>-1){
                                                    MyApplication.resultSocketMessage.set(countOK,   strResultMessage)
                                                    countOK=countOK+1
                                                }
                                            }
                                        }
                                        iCompteur=iCompteur+1
                                    mIPActivity.objActivity!!.runOnUiThread {
                                        txtCpt.setText(iCompteur.toString())
                                    }

                                }
                                mIPActivity.objActivity!!.runOnUiThread {
                                    val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                                    progressBar.visibility = View.INVISIBLE
                                }

                            }else{

                                if (strAdrPart1=="*" || strAdrPart2=="*" || strAdrPart3=="*" || strAdrPart4=="*"){

                                    MyApplication.resultSocketMessage = Array(256) {""}

                                    for(x in 0..255) {

                                        if(MyApplication.strStatusTCP.strValue=="Stop") {
                                            cancel(true)
                                            return ""
                                        }

                                        if (strAdrPart1=="*"){
                                            MyApplication.strCurrentAdressIP.strAdresse=x.toString()+"."+strAdrPart2+"."+strAdrPart3+"."+strAdrPart4
                                        }

                                        if (strAdrPart2=="*"){
                                            MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"." + x.toString()+"."+strAdrPart3+"."+strAdrPart4
                                        }

                                        if (strAdrPart3=="*"){
                                            MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"." +strAdrPart2+"."+ x.toString()+ "."+strAdrPart4
                                        }

                                        if (strAdrPart4=="*"){
                                            MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"."+strAdrPart2+"."+strAdrPart3+"."+x.toString()
                                        }
                                        val estJoignable:Boolean=validAddressSansPosition(MyApplication.strCurrentAdressIP.strAdresse)
                                        if(!estJoignable)  {
                                            if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                MyApplication.resultSocketMessage.set(iCompteur, MyApplication.strCurrentAdressIP.strAdresse+  " " +mIPActivity.objActivity!!.getString(R.string.mess_non_joignable) +  "\n")
                                            }
                                        }

                                    else{

                                                MyApplication.numCurrentPort.PortID=numPortVarDe
                                                val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                                val SCT: ScanPortUDPTask=ScanPortUDPTask(SPRUT,mIPActivity.objActivity)
                                                SCT.NumPort=numPortVarDe
                                                SCT.run()
                                                var strResultMessage:String
                                                strResultMessage= MyApplication.strResultSocketMessage.strTextMessage
                                                if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                    MyApplication.resultSocketMessage.set(iCompteur, strResultMessage)
                                                }else{
                                                    if(strResultMessage.indexOf("Err",0,true)>-1){
                                                        MyApplication.resultSocketMessage.set(countOK,   strResultMessage)
                                                        countOK=countOK+1
                                                    }
                                                }
                                            }
                                            iCompteur= iCompteur+1

                                        mIPActivity.objActivity!!.runOnUiThread {
                                            txtCpt.setText(iCompteur.toString())
                                        }

                                    }
                                    mIPActivity.objActivity!!.runOnUiThread {
                                        val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                                        progressBar.visibility = View.INVISIBLE
                                    }

                                }
                            }
                       }else{

                            val strAdrPart1=MyApplication.strAdrPart1.strAddress
                            val strAdrPart2=MyApplication.strAdrPart2.strAddress
                            val strAdrPart3=MyApplication.strAdrPart3.strAddress
                            val strAdrPart4=MyApplication.strAdrPart4.strAddress
                            val strAdrPart5=MyApplication.strAdrPart5.strAddress

                            if (strAdrPart5!="No"){

                                val diffadr:Int=strAdrPart5.toInt()-strAdrPart4.toInt()
                                var part4:Int=0

                                MyApplication.resultSocketMessage = Array(diffadr+1) {""}

                                for(x in 0..diffadr) {

                                    if(MyApplication.strStatusTCP.strValue=="Stop") {
                                        cancel(true)
                                        return ""
                                    }

                                    part4=strAdrPart4.toInt()+x
                                    MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"."+strAdrPart2+"."+strAdrPart3+"."+part4.toString()
                                    val estJoignable:Boolean=validAddressSansPosition(MyApplication.strCurrentAdressIP.strAdresse)
                                    if(!estJoignable)  {
                                        if (MyApplication.boolHideFailed.boolHideFailed==false){
                                            MyApplication.resultSocketMessage.set(iCompteur, MyApplication.strCurrentAdressIP.strAdresse+  " " +mIPActivity.objActivity!!.getString(R.string.mess_non_joignable) +  "\n")
                                        }
                                    }

                                    else{

                                            MyApplication.numCurrentPort.PortID=numPortVarDe
                                            MyApplication.strCurrentAdressIP.strAdresse= MyApplication.strCurrentAdressIP.strAdresse
                                            val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                            val SCT: ScanPortTask=ScanPortTask(SPRUT)
                                            SCT.NumPort=numPortVarDe
                                            SCT.run()

                                            if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                                    val strResult=activity!!.getString(R.string.connexion) +  MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                    MyApplication.resultSocketMessage.set(iCompteur,  strResult)
                                                }else{
                                                    val strResult=activity!!.getString(R.string.echec_sans_deux_point) + MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                    MyApplication.resultSocketMessage.set(iCompteur,  strResult)
                                                }
                                            }else{

                                                if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                                    val strResult=activity!!.getString(R.string.connexion) +  MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                    MyApplication.resultSocketMessage.set(countOK,  strResult)
                                                    countOK=countOK+1
                                                }else {
                                                    val strResult=""
                                                    // MyApplication.resultSocketMessage.set(0,  strResult)
                                                }
                                            }
                                        }
                                        iCompteur=iCompteur+1
                                    mIPActivity.objActivity!!.runOnUiThread {
                                        txtCpt.setText(iCompteur.toString())
                                    }

                                    }

                                mIPActivity.objActivity!!.runOnUiThread {
                                    val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                                    progressBar.visibility = View.INVISIBLE
                                }

                            }else{

                                if (strAdrPart1=="*" || strAdrPart2=="*" || strAdrPart3=="*" || strAdrPart4=="*"){

                                    MyApplication.resultSocketMessage = Array(256) {""}

                                    for(x in 0..255) {

                                        if(MyApplication.strStatusTCP.strValue=="Stop") {
                                            cancel(true)
                                            return ""
                                        }

                                        if (strAdrPart1=="*"){
                                            MyApplication.strCurrentAdressIP.strAdresse=x.toString()+"."+strAdrPart2+"."+strAdrPart3+"."+strAdrPart4
                                        }

                                        if (strAdrPart2=="*"){
                                            MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"." + x.toString()+"."+strAdrPart3+"."+strAdrPart4
                                        }

                                        if (strAdrPart3=="*"){
                                            MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"." +strAdrPart2+"."+ x.toString()+ "."+strAdrPart4
                                        }

                                        if (strAdrPart4=="*"){
                                            MyApplication.strCurrentAdressIP.strAdresse=strAdrPart1+"."+strAdrPart2+"."+strAdrPart3+"."+x.toString()
                                        }
                                        val estJoignable:Boolean=validAddressSansPosition(MyApplication.strCurrentAdressIP.strAdresse)
                                        if(!estJoignable)  {
                                            if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                MyApplication.resultSocketMessage.set(iCompteur, MyApplication.strCurrentAdressIP.strAdresse+  " " +mIPActivity.objActivity!!.getString(R.string.mess_non_joignable) +  "\n")
                                            }
                                        }

                                        else{


                                                MyApplication.numCurrentPort.PortID=numPortVarDe
                                                MyApplication.strCurrentAdressIP.strAdresse= MyApplication.strCurrentAdressIP.strAdresse
                                                val SPRUT:ScanPortResultUpdateTask=ScanPortResultUpdateTask("Test")
                                                val SCT: ScanPortTask=ScanPortTask(SPRUT)
                                                SCT.NumPort=numPortVarDe
                                                SCT.run()

                                                if (MyApplication.boolHideFailed.boolHideFailed==false){
                                                    if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                                        val strResult=activity!!.getString(R.string.connexion) +  MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                        MyApplication.resultSocketMessage.set(iCompteur,  strResult)
                                                    }else{
                                                        val strResult=activity!!.getString(R.string.echec_sans_deux_point) + MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                        MyApplication.resultSocketMessage.set(iCompteur,  strResult)
                                                    }
                                                }else{

                                                    if ( MyApplication.strResultSocketMessage.strTextMessage=="OKPort") {
                                                        val strResult=activity!!.getString(R.string.connexion) +  MyApplication.strCurrentAdressIP.strAdresse + " (port " +   MyApplication.numCurrentPort.PortID.toString() +")"
                                                        MyApplication.resultSocketMessage.set(countOK,  strResult)
                                                        countOK=countOK+1
                                                    }else {
                                                        val strResult=""
                                                        // MyApplication.resultSocketMessage.set(0,  strResult)
                                                    }
                                                }
                                            }
                                            iCompteur= iCompteur+1

                                        mIPActivity.objActivity!!.runOnUiThread {
                                            txtCpt.setText(iCompteur.toString())
                                        }

                                    }
                                    mIPActivity.objActivity!!.runOnUiThread {
                                        val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                                        progressBar.visibility = View.INVISIBLE
                                    }

                                }
                            }
                        }

                        mIPActivity.objActivity!!.runOnUiThread {
                            val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                            progressBar.visibility = View.INVISIBLE

                        }

                    }

                    mIPActivity.objActivity!!.runOnUiThread {
                        val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                        progressBar.visibility = View.INVISIBLE

                    }
                    return ""
                } catch (e: IOException) {
                    e.message.toString()
                }
            }

            override fun onCancelled(result: String?) {
                val activity = activityReference.get()
                if (activity == null) return


                val mListView = activity!!.view!!.findViewById<View>(R.id.listViewResult) as ListView
                val adapter = ArrayAdapter<String>(activity.context, android.R.layout.simple_list_item_1 ,  MyApplication.resultSocketMessage )
                mListView.setAdapter(adapter)

                val btnStop:Button =  activity.view!!.findViewById(R.id.cmdStopSearchIP) as Button
                val btnStart:Button =  activity.view!!.findViewById(R.id.cmdOKSearch) as Button
                val txtAdress1 =   activity.view!!.findViewById(R.id.editAdressePart1) as EditText
                val txtAdress2 =   activity.view!!.findViewById(R.id.editAdressePart2) as EditText
                val txtAdress3 =  activity.view!!.findViewById(R.id.editAdressePart3) as EditText
                val txtAdress4 =   activity.view!!.findViewById(R.id.editAdressePart4) as EditText
                val txtAdress5 =   activity.view!!.findViewById(R.id.editAdressePart5) as EditText
                val txtTemps = activity.view!!.findViewById(R.id.editTemps) as EditText
                val txtPortDe = activity.view!!.findViewById(R.id.editPortDe) as EditText
                val txtPortA =   activity.view!!.findViewById(R.id.editPortA) as EditText
                val chkHideFailed =   activity.view!!.findViewById(R.id.chkHideFailed) as CheckBox
                val ButtonUDP =   activity.view!!.findViewById(R.id.radioUDP) as RadioButton
                val ButtonTCP =  activity.view!!.findViewById(R.id.radioTCP) as RadioButton
                val editMessUDP = activity.view!!.findViewById(R.id.editUDPMessage) as EditText
                val chkScanFavorite =   activity.view!!.findViewById(R.id.chkScanFavori) as CheckBox

                btnStop.isClickable=false
                btnStop.isEnabled=false
                btnStart.isClickable=true
                txtAdress1.isEnabled=true
                txtAdress2.isEnabled=true
                txtAdress3.isEnabled=true
                txtAdress4.isEnabled=true
                txtAdress5.isEnabled=true
                txtTemps.isEnabled=true
                txtPortDe.isEnabled=true
                txtPortA.isEnabled=true
                chkHideFailed.isEnabled=true
                ButtonUDP.isEnabled=true
                ButtonTCP.isEnabled=true
                editMessUDP.isEnabled=true

                chkScanFavorite.isEnabled=true

                MyApplication.asyncRunning.bValue=false

                val progressBar = activity.view!!.findViewById<View>(R.id.progressBar1)
                progressBar.visibility = View.INVISIBLE

            }



            override fun onPostExecute(result: String?) {

                if(MyApplication.strStatusTCP.strValue=="Stop") {
                    cancel(true)
                    return
                }



                if (isCancelled()) return

                val activity = activityReference.get()
                if (activity == null) return



                val mListView = activity!!.view!!.findViewById<View>(R.id.listViewResult) as ListView
                val adapter = ArrayAdapter<String>(activity.context, android.R.layout.simple_list_item_1 ,  MyApplication.resultSocketMessage )
                mListView.setAdapter(adapter)

                val btnStop:Button =  activity.view!!.findViewById(R.id.cmdStopSearchIP) as Button
                val btnStart:Button =  activity.view!!.findViewById(R.id.cmdOKSearch) as Button
                val txtAdress1 =   activity.view!!.findViewById(R.id.editAdressePart1) as EditText
                val txtAdress2 =   activity.view!!.findViewById(R.id.editAdressePart2) as EditText
                val txtAdress3 =  activity.view!!.findViewById(R.id.editAdressePart3) as EditText
                val txtAdress4 =   activity.view!!.findViewById(R.id.editAdressePart4) as EditText
                val txtAdress5 =   activity.view!!.findViewById(R.id.editAdressePart5) as EditText
                val txtTemps = activity.view!!.findViewById(R.id.editTemps) as EditText
                val txtPortDe = activity.view!!.findViewById(R.id.editPortDe) as EditText
                val txtPortA =   activity.view!!.findViewById(R.id.editPortA) as EditText
                val chkHideFailed =   activity.view!!.findViewById(R.id.chkHideFailed) as CheckBox
                val ButtonUDP =   activity.view!!.findViewById(R.id.radioUDP) as RadioButton
                val ButtonTCP =  activity.view!!.findViewById(R.id.radioTCP) as RadioButton
                val editMessUDP = activity.view!!.findViewById(R.id.editUDPMessage) as EditText
                val chkScanFavorite =   activity.view!!.findViewById(R.id.chkScanFavori) as CheckBox

                btnStop.isClickable=false
                btnStop.isEnabled=false
                btnStart.isClickable=true
                txtAdress1.isEnabled=true
                txtAdress2.isEnabled=true
                txtAdress3.isEnabled=true
                txtAdress4.isEnabled=true
                txtAdress5.isEnabled=true
                txtTemps.isEnabled=true
                txtPortDe.isEnabled=true
                txtPortA.isEnabled=true
                chkHideFailed.isEnabled=true
                ButtonUDP.isEnabled=true
                ButtonTCP.isEnabled=true
                editMessUDP.isEnabled=true

                chkScanFavorite.isEnabled=true
                MyApplication.asyncRunning.bValue=false

               return

          }
        }
       @JvmStatic
        fun newInstance() =
            FragmentTcpIp().apply {
                arguments = Bundle().apply {

                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    internal inner class ButtonStopClick : View.OnClickListener {

        override fun onClick(v: View) {

            ButtonStopClicked()
        }
    }

    private fun ButtonStopClicked() {

        val progressBar = activity!!.findViewById<View>(R.id.progressBar1)

        if (progressBar != null) {

            progressBar.visibility = View.INVISIBLE
            MyApplication.asyncRunning.bValue=false
        }

        MyApplication.strStatusTCP.strValue= "Stop"
        val btnStop:Button = getView()?.findViewById(R.id.cmdStopSearchIP) as Button
        btnStop.isClickable=false
        btnStop.isEnabled=false
        val btnStart:Button = getView()?.findViewById(R.id.cmdOKSearch) as Button
        btnStart.isClickable=true

        val txtAdress1 =   getView()?.findViewById(R.id.editAdressePart1) as EditText
        val txtAdress2 =   getView()?.findViewById(R.id.editAdressePart2) as EditText
        val txtAdress3 =   getView()?.findViewById(R.id.editAdressePart3) as EditText
        val txtAdress4 =   getView()?.findViewById(R.id.editAdressePart4) as EditText
        val txtAdress5 =   getView()?.findViewById(R.id.editAdressePart5) as EditText
        val txtTemps = getView()?.findViewById(R.id.editTemps) as EditText
        val txtPortDe = getView()?.findViewById(R.id.editPortDe) as EditText
        val txtPortA =   getView()?.findViewById(R.id.editPortA) as EditText
        val chkHideFailed =   getView()?.findViewById(R.id.chkHideFailed) as CheckBox
        val ButtonUDP =   getView()?.findViewById(R.id.radioUDP) as RadioButton
        val ButtonTCP =   getView()?.findViewById(R.id.radioTCP) as RadioButton
        val editMessUDP =   getView()?.findViewById(R.id.editUDPMessage) as EditText

        txtAdress1.isEnabled=true
        txtAdress2.isEnabled=true
        txtAdress3.isEnabled=true
        txtAdress4.isEnabled=true
        txtAdress5.isEnabled=true
        txtTemps.isEnabled=true
        txtPortDe.isEnabled=true
        txtPortA.isEnabled=true
        chkHideFailed.isEnabled=true
        ButtonUDP.isEnabled=true
        ButtonTCP.isEnabled=true
        editMessUDP.isEnabled=true

    }

    internal inner class ButtonOkClick : View.OnClickListener {

        override fun onClick(v: View) {

            if (MyApplication.asyncRunning.bValue==true){
                showMessage(getString(R.string.info_scan_actif))

                return
            }
            MyApplication.boolPortScan.bValue=false
            MyApplication.indexOctet4.numIndex=0
            MyApplication.indexPort.indexID= 0
            MyApplication.indexAsterixAdressIP.indexID=0
            MyApplication.indexAdressIP.indexID=0
            MyApplication.numCurrentPort.PortID=MyApplication.strPortDe.PortID.toInt()
            MyApplication.boolIPClassWildCard.boolIsWildCard=false
            MyApplication.numOctet4Diff.numOctet=0

            ButtonOkClicked()
        }
    }

    internal inner class  CheckHiddenFailedClick : View.OnClickListener {

        override fun onClick(v: View) {

            if (MyApplication.asyncRunning.bValue==true){
                 val chkHiddenFailed =   getView()?.findViewById(R.id.chkHideFailed) as CheckBox

                if (chkHiddenFailed.isChecked){
                    chkHiddenFailed.isChecked=false
                }else
                {
                    chkHiddenFailed.isChecked=true
                }

                showMessage(getString(R.string.info_scan_actif))
                return@onClick
            }

        }
    }

    internal inner class RadioButtonTCPClick : View.OnClickListener {

        override fun onClick(v: View) {

            if (MyApplication.asyncRunning.bValue==true){
                val ButtonTCP =   getView()?.findViewById(R.id.radioTCP) as RadioButton
                ButtonTCP.isChecked=false
                showMessage(getString(R.string.info_scan_actif))
                return@onClick
            }

            val chkCacherEchec =  getView()?.findViewById(R.id.chkHideFailed) as CheckBox
            val ButtonUDP =   getView()?.findViewById(R.id.radioUDP) as RadioButton
            val txtTime =   getView()?.findViewById(R.id.editTemps) as EditText
            val txtLabelMess =   getView()?.findViewById(R.id.txtUDPMessage) as TextView
            val editMessUDP =   getView()?.findViewById(R.id.editUDPMessage) as EditText

            txtLabelMess.visibility = INVISIBLE
            editMessUDP.visibility = INVISIBLE

            chkCacherEchec.setText(getString(R.string.bouton_cacher_echec))
            chkCacherEchec.isChecked=true
            txtTime.setText(MyApplication.strTempsDefaut.strValue)
            txtTime.isEnabled=true

            ButtonUDP.isChecked=false

            RadioButtonTCPClick()
        }
    }

    internal inner class RadioButtonUDPClick : View.OnClickListener {

        override fun onClick(v: View) {

            if (MyApplication.asyncRunning.bValue==true){
                val ButtonUDP =   getView()?.findViewById(R.id.radioUDP) as RadioButton
                ButtonUDP.isChecked=false
                showMessage(getString(R.string.info_scan_actif))
                return@onClick
            }

            val chkCacherEchec =  getView()?.findViewById(R.id.chkHideFailed) as CheckBox
            val ButtonTCP =   getView()?.findViewById(R.id.radioTCP) as RadioButton
            val txtTime =   getView()?.findViewById(R.id.editTemps) as EditText
            val txtLabelMess =   getView()?.findViewById(R.id.txtUDPMessage) as TextView
            val editMessUDP =   getView()?.findViewById(R.id.editUDPMessage) as EditText

            txtLabelMess.visibility = VISIBLE
            editMessUDP.visibility = VISIBLE

            ButtonTCP.isChecked=false
            chkCacherEchec.isChecked=false
            chkCacherEchec.setText(getString(R.string.cacher_udp_permission_refuse))
            txtTime.setText(MyApplication.strTempsDefaut.strValue)
            txtTime.isEnabled=false

            RadioButtonUDPClick()
        }
    }

    private fun showMessage(strMessage: String) {
        val toast_obj= Toast.makeText(this.activity,strMessage, Toast.LENGTH_SHORT)
        toast_obj.setGravity(Gravity.TOP, 0, 120)
        toast_obj.show()
    }

    private fun ButtonOkClicked() {

        MyApplication.strStatusTCP.strValue="Start"
        MyApplication.boolSimple.bValue=false
        MyApplication.boolPortDeIsNullAndEmpty.boolIs=false
        MyApplication.boolScanFavorites.boolIs=false


        val txtTotal =   getView()?.findViewById(R.id.txtTotal) as TextView
        val txtCompte =   getView()?.findViewById(R.id.txtCompte) as TextView
        txtTotal.setText("")
        txtCompte.setText("")

        val txtAdress1 =   getView()?.findViewById(R.id.editAdressePart1) as EditText
        val txtAdress2 =   getView()?.findViewById(R.id.editAdressePart2) as EditText
        val txtAdress3 =   getView()?.findViewById(R.id.editAdressePart3) as EditText
        val txtAdress4 =   getView()?.findViewById(R.id.editAdressePart4) as EditText
        val txtAdress5 =   getView()?.findViewById(R.id.editAdressePart5) as EditText
        val txtTemps = getView()?.findViewById(R.id.editTemps) as EditText
        val txtPortDe = getView()?.findViewById(R.id.editPortDe) as EditText
        val txtPortA =   getView()?.findViewById(R.id.editPortA) as EditText
        val chkHideFailed =   getView()?.findViewById(R.id.chkHideFailed) as CheckBox
        val chkScanFavorite =   getView()?.findViewById(R.id.chkScanFavori) as CheckBox
        val buttonOK =   getView()?.findViewById(R.id.cmdOKSearch) as Button
        val buttonUDPchk =   getView()?.findViewById(R.id.radioUDP) as RadioButton


        if (chkScanFavorite.isChecked==true){
            MyApplication.boolScanFavorites.boolIs=true
            txtPortDe.setText("")
            txtPortA.setText("")
        }

        val btnStop:Button = getView()?.findViewById(R.id.cmdStopSearchIP) as Button
        btnStop.isClickable=true
        btnStop.isEnabled=true
        val btnStart:Button = getView()?.findViewById(R.id.cmdOKSearch) as Button
        btnStart.isClickable=false

        val resultSocketMessageBlank = Array(2000) { "" }

          val mListView = activity?.findViewById(R.id.listViewResult) as ListView
          for (x in 0..2000-1)
          {
              resultSocketMessageBlank.set( x, " ")
          }
          val adapter = ArrayAdapter<String>(context, android.R.layout.simple_list_item_1 , resultSocketMessageBlank)
          mListView.setAdapter(adapter)

        MyApplication.boolHideFailed.boolHideFailed= chkHideFailed.isChecked

        if (chkHideFailed.isChecked) {
            MyApplication.indexPortWhenHideFailedIsTrue.indexID=0
            MyApplication.indexIpAdressWhenHideFailedIsTrue.indexID=0
        }

        MyApplication.indexAdressIP.indexID=0

        var stringPortDe: String=""
        var stringPortA: String=""
        var stringTemps: String=""

        var intSwitchPortValue:Int=0
        var intPortDe:Int=0
        var intPortA:Int=0

        var intAdrPart1:Int=0
        var intAdrPart2:Int=0
        var intAdrPart3:Int=0
        var intAdrPart4:Int=0
        var intAdrPart5:Int=0


        var longTemps:Long=0
        var asterix_id:Int=0
        var asterix_count:Int=0

        if (txtAdress1.text.isNullOrEmpty())
        {
            hideKeyboard(this.activity)

            showMessage(getString(R.string.demande_adresse))
            ButtonStopClicked()

            return@ButtonOkClicked

        }

        if (!isNumeric(txtAdress1.text.toString()) )
        {

            if (txtAdress1.text.toString()=="*")
            {
                asterix_id=1
                asterix_count=1
            }else
            {

                showMessage(getString(R.string.valeur_numerique_adresse))
                ButtonStopClicked()
                return@ButtonOkClicked
            }

        }
        else
        {
           intAdrPart1=txtAdress1.text.toString().toInt()
        }

        if (txtAdress2.text.isNullOrEmpty())
        {

            hideKeyboard(this.activity)
            showMessage(getString(R.string.demande_adresse))
            ButtonStopClicked()
            return@ButtonOkClicked

        }

        if (!isNumeric(txtAdress2.text.toString()))
        {
            if (txtAdress2.text.toString()=="*")
            {
                asterix_id=2
                asterix_count+=1
            }else
            {
                hideKeyboard(this.activity)
                showMessage(getString(R.string.valeur_numerique_adresse))
                ButtonStopClicked()
                return@ButtonOkClicked
            }

        }
        else
        {
            intAdrPart2=txtAdress2.text.toString().toInt()
        }


        if (txtAdress3.text.isNullOrEmpty())
        {

            hideKeyboard(this.activity)
            showMessage(getString(R.string.demande_adresse))
            ButtonStopClicked()
            return

        }

        if (!isNumeric(txtAdress3.text.toString()))
        {
            if (txtAdress3.text.toString()=="*")
            {
                asterix_id=3
                asterix_count+=1
            }else
            {
                hideKeyboard(this.activity)
                showMessage(getString(R.string.valeur_numerique_adresse))
                ButtonStopClicked()
                return@ButtonOkClicked
            }

        }
        else
        {
            intAdrPart3=txtAdress3.text.toString().toInt()
        }

        if (txtAdress4.text.isNullOrEmpty())
        {

            hideKeyboard(this.activity)
            showMessage(getString(R.string.demande_adresse))
            ButtonStopClicked()
            return

        }

        if (!isNumeric(txtAdress4.text.toString()))
        {
            if (txtAdress4.text.toString()=="*")
            {
                asterix_id=4
                asterix_count+=1
            }else
            {
                hideKeyboard(this.activity)
                showMessage(getString(R.string.valeur_numerique_adresse))
                ButtonStopClicked()
                return@ButtonOkClicked
            }
        }
        else
        {
            intAdrPart4=txtAdress4.text.toString().toInt()
        }

        if (asterix_count>1){


            hideKeyboard(this.activity)

            showMessage(getString(R.string.un_asterique))
            ButtonStopClicked()
            return@ButtonOkClicked

        }

     if (!isNumeric(txtPortDe.text.toString()) && !txtPortDe.text.isNullOrEmpty())
        {
            hideKeyboard(this.activity)

            showMessage(getString(R.string.port_numerique))
            ButtonStopClicked()
            return

        } else{

              if (!txtPortDe.text.isNullOrEmpty()) {
                  stringPortDe=txtPortDe.text.toString()
                  intPortDe=stringPortDe.toInt()
                  MyApplication.boolPortScan.bValue=true
                  MyApplication.boolPortDeIsNullAndEmpty.boolIs=false
              }else{
                  MyApplication.boolPortScan.bValue=false
                  MyApplication.boolPortDeIsNullAndEmpty.boolIs=true
              }
        }





        if (!txtPortA.text.isNullOrEmpty())
        {
            if (!isNumeric(txtPortA.text.toString()))
            {
                hideKeyboard(this.activity)

                showMessage(getString(R.string.port_numerique))
                ButtonStopClicked()
                return

            }else{

                  stringPortA=txtPortA.text.toString()
                  intPortA=stringPortA.toInt()

            }

        }

        if (txtTemps.text.isNullOrEmpty())
        {
            hideKeyboard(this.activity)
            showMessage(getString(R.string.demande_temps))
            ButtonStopClicked()
            return
        }

        if (!isNumeric(txtTemps.text.toString()))
        {
            hideKeyboard(this.activity)
            showMessage(getString(R.string.temps_numerique))
            ButtonStopClicked()
            return

        } else{

            stringTemps=txtTemps.text.toString()
            longTemps=stringTemps.toLong()
            MyApplication.numTempsReponse.numMilliseconde= longTemps

        }

        if ((intAdrPart1 <0 || intAdrPart1>255 && (isNumeric(txtAdress1.text.toString())))  || (intAdrPart2 <0 || intAdrPart2>255 && (isNumeric(txtAdress2.text.toString())))  || (intAdrPart3 <0 || intAdrPart3>255 && (isNumeric(txtAdress3.text.toString())))   || (intAdrPart4 <0 || intAdrPart4>255 && (isNumeric(txtAdress4.text.toString())))){
            hideKeyboard(this.activity)
            showMessage(getString(R.string.borne_adresse))
            ButtonStopClicked()
            return
        }

        var intSwitchAdrValue:Int=0
        var intAdrDiff:Int=0
        if (txtAdress5.text.toString() != "" && !txtAdress5.text.isNullOrEmpty())
        {
            if(!isNumeric(txtAdress5.text.toString()))
            {
                hideKeyboard(this.activity)
                showMessage(getString(R.string.valeur_numerique_adresse))
                ButtonStopClicked()
                return@ButtonOkClicked
            }else
            {
                intAdrPart5=txtAdress5.text.toString().toInt()
                if (-1<intAdrPart5 && intAdrPart5<256)
                {
                    if (intAdrPart5 < intAdrPart4 && intAdrPart5>0)
                    {
                        intSwitchAdrValue=intAdrPart5
                        intAdrPart5=intAdrPart4
                        intAdrPart4=intSwitchAdrValue
                        txtAdress4.setText(intAdrPart4.toString())
                        txtAdress5.setText(intAdrPart5.toString())
                        intAdrDiff=intAdrPart5-intAdrPart4
                    }else
                    {
                        intAdrDiff=intAdrPart5-intAdrPart4
                    }

                }else
                {
                    txtAdress5.setText("")
                    hideKeyboard(this.activity)
                    showMessage(getString(R.string.borne_adresse))
                    ButtonStopClicked()
                    return
                }
            }
        }

        if (isNumeric(txtPortA.text.toString())) {
            if (intPortA>65535 || intPortA<0)
            {
                hideKeyboard(this.activity)
                showMessage(getString(R.string.borne_port))
                ButtonStopClicked()
                return
            }

        }

        if (intPortDe>65535 || intPortDe<0)
        {
            hideKeyboard(this.activity)
            showMessage(getString(R.string.borne_port))
            ButtonStopClicked()
            return
        }

        if (asterix_id>0  && intPortA>0)
        {
            txtPortA.setText("")
            intPortA=0
            txtPortDe.setText("")
            intPortDe=0
            showMessage(getString(R.string.type_recherche_permise))
            ButtonStopClicked()
            return
        }

        if (intAdrDiff>0  && intPortA>0)
        {
            txtPortA.setText("")
            intPortA=0
            txtPortDe.setText("")
            intPortDe=0
            showMessage(getString(R.string.type_recherche_permise))
            ButtonStopClicked()
            return
        }

        if (intPortA < intPortDe && intPortA>0)
        {

            intSwitchPortValue=intPortA
            intPortA=intPortDe
            intPortDe=intSwitchPortValue
            txtPortDe.setText(intPortDe.toString())
            txtPortA.setText(intPortA.toString())

            showMessage(getString(R.string.borne_interverties))

        }

        if (view != null) {
            val lstView = view!!.findViewById<View>(R.id.listViewResult)

            if (lstView != null) {

                lstView.visibility = VISIBLE
            }

             txtAdress1.isEnabled=false
             txtAdress2.isEnabled=false
             txtAdress3.isEnabled=false
             txtAdress4.isEnabled=false
             txtAdress5.isEnabled=false
             txtTemps.isEnabled=false
             txtPortDe.isEnabled=false
             txtPortA.isEnabled=false
             chkHideFailed.isEnabled=false
             val ButtonUDP =   getView()?.findViewById(R.id.radioUDP) as RadioButton
             val ButtonTCP =   getView()?.findViewById(R.id.radioTCP) as RadioButton
             val editMessUDP =   getView()?.findViewById(R.id.editUDPMessage) as EditText
              ButtonUDP.isEnabled=false
              ButtonTCP.isEnabled=false
              editMessUDP.isEnabled=false
            chkScanFavorite.isEnabled=false

        }

        val editMessUDP =   getView()?.findViewById(R.id.editUDPMessage) as EditText
        val strMessageUDP:String

        strMessageUDP=editMessUDP.text.toString()

        if(strMessageUDP.length<1){
            MyApplication.strTextSentUDP.strText="UDP test"
        }else{
            MyApplication.strTextSentUDP.strText=strMessageUDP
        }

        MyApplication.strResultSocketMessage.strTextMessage=""
        MyApplication.strPortDe.PortID =intPortDe.toString()
        MyApplication.strPortA.PortID=intPortA.toString()
        MyApplication.strCurrentPortID.strPortID=intPortDe.toString()
        MyApplication.numCurrentPort.PortID  =intPortDe

       var strConcat:String=""

         if (asterix_id>0) {

             if (MyApplication.boolScanFavorites.boolIs==true){
              if(buttonUDPchk.isChecked==true){
                  val strsAdresseFavori = MyApplication.strUDPFavoris.strValue
                  val arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()
                  var iCountTotal:Int
                  iCountTotal=256*arrayAdresseFavori.size
                  strConcat="/"+ iCountTotal.toString()
                  txtTotal.setText(strConcat)
                  MyApplication.numTotalAddress.numTotal=256
              }else{
                  val strsAdresseFavori = MyApplication.strTCPFavoris.strValue
                  val arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()
                  var iCountTotal:Int
                  iCountTotal=256*arrayAdresseFavori.size
                  strConcat="/"+ iCountTotal.toString()
                  txtTotal.setText(strConcat)
                  MyApplication.numTotalAddress.numTotal=256
              }

              }else{
                 strConcat="/256"
                 txtTotal.setText(strConcat)
                 MyApplication.numTotalAddress.numTotal=256
             }



         }

        if (intPortA>0)

        {
            var iTotal: Int=0
            iTotal=intPortA-intPortDe+1
            MyApplication.numTotalAddress.numTotal=iTotal

            //MyApplication.resultSocketMessage = Array(iTotal) {""}


            if (MyApplication.boolScanFavorites.boolIs==true){
                if(buttonUDPchk.isChecked==true){
                    val strsAdresseFavori = MyApplication.strUDPFavoris.strValue
                    val arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()
                    var iCountTotal:Int
                    iCountTotal=iTotal*arrayAdresseFavori.size
                    strConcat="/"+ iCountTotal.toString()
                    txtTotal.setText(strConcat)
                    MyApplication.numTotalAddress.numTotal=iTotal
                }else{
                    val strsAdresseFavori = MyApplication.strTCPFavoris.strValue
                    val arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()
                    var iCountTotal:Int
                    iCountTotal=iTotal*arrayAdresseFavori.size
                    strConcat="/"+ iCountTotal.toString()
                    txtTotal.setText(strConcat)
                    MyApplication.numTotalAddress.numTotal=iTotal
                }

            }else{
                strConcat="/" + iTotal.toString()
                txtTotal.setText(strConcat)
            }





            MyApplication.asyncRunning.bValue=true
            MyApplication.boolPortScan.bValue=true
            MyApplication.boolIPClassWildCard.boolIsWildCard=false
            MyApplication.boolSimple.bValue=false

            if (view != null) {
                val lstView = view!!.findViewById<View>(R.id.listViewResult)

                if (lstView != null) {

                    lstView.visibility = VISIBLE
                }

                val progressBar = view!!.findViewById<View>(R.id.progressBar1)
                if (progressBar != null) {


                    progressBar.visibility = VISIBLE
                    progressBar.animate()
                }
            }

            MyApplication.numTotalPort.numTotal=intPortA-intPortDe+1
            hideKeyboard(this.activity)

       //     Thread {



                val task =NetworkLogicTask(this)
                task.execute(txtAdress1.text.toString() +"."+txtAdress2.text.toString()+"."+txtAdress3.text.toString()+"."+txtAdress4.text.toString() )

         //   }.start()

        }else

        {

            if (asterix_id>0 || intAdrDiff>0)
            {

                   if (view != null) {
                        val progressBar = view!!.findViewById<View>(R.id.progressBar1)
                        if (progressBar != null) {

                            progressBar.visibility = VISIBLE
                            progressBar.animate()
                        }
                    }

                    MyApplication.asyncRunning.bValue=true

                    MyApplication.strAdrPart1.strAddress=txtAdress1.text.toString()
                    MyApplication.strAdrPart2.strAddress=txtAdress2.text.toString()
                    MyApplication.strAdrPart3.strAddress=txtAdress3.text.toString()
                    MyApplication.strAdrPart4.strAddress=txtAdress4.text.toString()
                    MyApplication.strAdrPart5.strAddress=txtAdress5.text.toString()
                    MyApplication.boolSimple.bValue=false
                    MyApplication.boolIPClassWildCard.boolIsWildCard=true
                    MyApplication.boolPortScan.bValue=false

                  if(intAdrDiff>0){
                      intAdrDiff=intAdrDiff+1
                      if (MyApplication.boolScanFavorites.boolIs==true){
                          if(buttonUDPchk.isChecked==true){
                              val strsAdresseFavori = MyApplication.strUDPFavoris.strValue
                              val arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()
                              var iCountTotal:Int
                              iCountTotal=intAdrDiff*arrayAdresseFavori.size
                              strConcat="/"+ iCountTotal.toString()
                              txtTotal.setText(strConcat)
                              MyApplication.numTotalAddress.numTotal=iCountTotal
                          }else{
                              val strsAdresseFavori = MyApplication.strTCPFavoris.strValue
                              val arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()
                              var iCountTotal:Int
                              iCountTotal=intAdrDiff*arrayAdresseFavori.size
                              strConcat="/"+ iCountTotal.toString()
                              txtTotal.setText(strConcat)
                              MyApplication.numTotalAddress.numTotal=iCountTotal
                          }

                      }else{
                          strConcat="/"+intAdrDiff.toString()
                          txtTotal.setText(strConcat)
                      }

                  }else{
                      MyApplication.strAdrPart5.strAddress="No"

                      if (MyApplication.boolScanFavorites.boolIs==true){
                          if(buttonUDPchk.isChecked==true){
                              val strsAdresseFavori = MyApplication.strUDPFavoris.strValue
                              val arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()
                              var iCountTotal:Int
                              iCountTotal=256*arrayAdresseFavori.size
                              strConcat="/"+ iCountTotal.toString()
                              txtTotal.setText(strConcat)
                              MyApplication.numTotalAddress.numTotal=iCountTotal
                          }else{
                              val strsAdresseFavori = MyApplication.strTCPFavoris.strValue
                              val arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()
                              var iCountTotal:Int
                              iCountTotal=256*arrayAdresseFavori.size
                              strConcat="/"+ iCountTotal.toString()
                              txtTotal.setText(strConcat)
                              MyApplication.numTotalAddress.numTotal=iCountTotal
                          }

                      }else{
                          strConcat="/256"
                          txtTotal.setText(strConcat)
                      }

                  }

                      //  Thread {

                               val task =NetworkLogicTask(this)
                            task.execute("byaddress" )
                       // }.start()

                }else
                {
                    MyApplication.boolIPClassWildCard.boolIsWildCard=false
                    MyApplication.resultSocketMessage = Array(  1) {""}
                    MyApplication.boolSimple.bValue=true



                    val task =NetworkLogicTask(this)
                    task.execute(txtAdress1.text.toString() +"."+txtAdress2.text.toString()+"."+txtAdress3.text.toString()+"."+txtAdress4.text.toString() )



                }
        }

        hideKeyboard(this.activity)

    }



    private fun showDialog(title: String) {

        val dialog = Dialog(activity)
        dialog .requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog .setCancelable(false)
        dialog .setContentView(R.layout.activity_legal_agree)

        val btnClose = dialog.findViewById(R.id.btn_close) as Button
        val chkPrivacy = dialog.findViewById(R.id.chkPrivacy) as CheckBox
        val chkTerms = dialog.findViewById(R.id.chkTerms) as CheckBox

        val labelPrivacy = dialog.findViewById(R.id.labelPrivacyCheck) as TextView
        val labelTerms = dialog.findViewById(R.id.labelTermsCheck) as TextView

        var strLanguage:String= Locale.getDefault().getDisplayLanguage()

        var browserIntentDisclaimer: Intent?= null
        var browserIntentPrivacy: Intent?= null
        var browserIntentTerms: Intent?= null

        if (strLanguage.indexOf("fran",0)>-1){

            browserIntentPrivacy= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/legal/privacy_fr.pdf"))
            browserIntentTerms= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/legal/terms_and_conditions_fr.pdf"))
        }else{

            browserIntentPrivacy= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/legal/privacy_en.pdf"))
            browserIntentTerms= Intent(Intent.ACTION_VIEW, Uri.parse("http://www.boolrun.com/legal/terms_and_conditions_en.pdf"))
        }

        labelPrivacy.isClickable=true
        labelTerms.isClickable=true

        labelPrivacy?.setOnClickListener() {
            startActivity(browserIntentPrivacy)
        }

        labelTerms?.setOnClickListener() {
            startActivity(browserIntentTerms)
        }

        btnClose.isClickable=false
        btnClose.isEnabled=false

        chkPrivacy.setOnClickListener {
            if(chkPrivacy.isChecked==true && chkTerms.isChecked==true){
                btnClose.isClickable=true
                btnClose.isEnabled=true
                }

        }

        chkTerms.setOnClickListener {
            if(chkPrivacy.isChecked==true && chkTerms.isChecked==true){
                btnClose.isClickable=true
                btnClose.isEnabled=true
            }

        }

        btnClose.setOnClickListener {

            val dbHandler = ObjectBDSetting(view!!.context!!, null, null, 1)

            dbHandler.resetSetting()

            dbHandler.addSetting("iptime","155")
            dbHandler.addSetting("maxaccu","20")
            dbHandler.addSetting("autowifisave","1")
            dbHandler.addSetting("displaymode","bn")
            dbHandler.addSetting("wifitime","5")
            dbHandler.addSetting("legal","Yes")
            dbHandler.addSetting("tcpfavori","21:23:25:53:80:443:8080")
            dbHandler.addSetting("udpfavori","53:123:161:5353:1900")


            dbHandler.updateSettingValue("legal",  "Yes")

            MyApplication.strTempsDefaut.strValue= "155"
            MyApplication.strMaxPrecision.strValue="20"
            MyApplication.strAutoScan.strValue= "1"
            MyApplication.strDisplayMode.strValue= "bn"
            MyApplication.strTempsDefautWiFi.strValue="5"
            MyApplication.strTCPFavoris.strValue="21:23:25:53:80:443:8080"
            MyApplication.strUDPFavoris.strValue="53:123:161:5353:1900"

            dialog .dismiss()
        }

        dialog .show()

    }

        override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

            val view: View = inflater!!.inflate(R.layout.activity_tcpip, container, false)

            val dbHandler = ObjectBDSetting(this!!.context!!, null, null, 1)

            val setting_agree_legal= dbHandler.getSettingValue("legal")

            if(setting_agree_legal!="Yes"){
                showDialog("legal")
            }

             mIPActivity.objActivity=this.activity

        if (MyApplication.strIPAdr1.strAdr1.toString() !="0"){
            var adrIp:String

            adrIp=MyApplication.strIPAdr1.strAdr1.toString()

            val strsIP = adrIp.split(".").toTypedArray()

            val txtAdress1 =   view.findViewById(R.id.editAdressePart1) as EditText
            val txtAdress2 =   view.findViewById(R.id.editAdressePart2) as EditText
            val txtAdress3 =   view.findViewById(R.id.editAdressePart3) as EditText
            val txtAdress4 =   view.findViewById(R.id.editAdressePart4) as EditText
            val txtPort =   view.findViewById(R.id.editPortDe) as EditText

            txtAdress1.setText(strsIP[0].toString())
            txtAdress2.setText(strsIP[1].toString())
            txtAdress3.setText(strsIP[2].toString())
            txtAdress4.setText(strsIP[3].toString())
            txtPort.setText("")

        }else{
            val wifiManager =  inflater!!.context!!.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiManager.reconnect()
            wifiManager.getScanResults()


            if (!wifiManager.dhcpInfo.gateway.toString().isNullOrEmpty()){
                var adrIp:String

                adrIp= Formatter.formatIpAddress(wifiManager.dhcpInfo.gateway)

                val strsIP = adrIp.split(".").toTypedArray()
                val txtAdress1 =   view.findViewById(R.id.editAdressePart1) as EditText
                val txtAdress2 =   view.findViewById(R.id.editAdressePart2) as EditText
                val txtAdress3 =   view.findViewById(R.id.editAdressePart3) as EditText
                val txtAdress4 =   view.findViewById(R.id.editAdressePart4) as EditText
                val txtPort =   view.findViewById(R.id.editPortDe) as EditText

                txtAdress1.setText(strsIP[0].toString())
                txtAdress2.setText(strsIP[1].toString())
                txtAdress3.setText(strsIP[2].toString())
                txtAdress4.setText(strsIP[3].toString())
                txtPort.setText("")


            }

        }



            val txtTemps =   view.findViewById(R.id.editTemps) as EditText

            txtTemps.setText(MyApplication.strTempsDefaut.strValue)

        hideKeyboard(this.activity)

        val btn_click_me = view.findViewById(R.id.cmdOKSearch) as Button
        val btn_click_stop = view.findViewById(R.id.cmdStopSearchIP) as Button
        val edit_adr4 = view.findViewById(R.id.editAdressePart4) as EditText

        val radio_click_tcp = view.findViewById(R.id.radioTCP) as RadioButton
        val radio_click_udp = view.findViewById(R.id.radioUDP) as RadioButton
        val check_hidden_click = view.findViewById(R.id.chkHideFailed) as CheckBox

        edit_adr4.requestFocus()

        btn_click_me.setOnClickListener(ButtonOkClick())

        btn_click_stop.setOnClickListener(ButtonStopClick())

        radio_click_tcp.setOnClickListener( RadioButtonTCPClick() )

        radio_click_udp.setOnClickListener( RadioButtonUDPClick() )

        check_hidden_click.setOnClickListener( CheckHiddenFailedClick() )



        return view

        //return inflater.inflate(R.layout.activity_tcpip, container, false)

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

      activity?.setTitle("")

    }

}











