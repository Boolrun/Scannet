package com.boolrun.scannet;

import android.app.Activity;
import android.os.StrictMode;
import android.util.Log;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;


public class ScanPortUDPTask implements Runnable{


  int NumPort;

    ScanPortResultUpdateTask resultUpdateTask;
    Activity act;

    String LocalAdress;
    String LocalPort;
    String RemortPort;

    public ScanPortUDPTask(ScanPortResultUpdateTask drUpdateTask,Activity actin){

        act=actin;
        resultUpdateTask = drUpdateTask;
    }

    @Override
    public void run() {
        String msg;
        msg="";

        MyApplication.Companion.getStrResultSocketMessage().setStrTextMessage(ScanPort());

        resultUpdateTask.setBackgroundMsg(msg);
        ScanPortManager.getScanPortManager().getMainThreadExecutor()
                .execute(resultUpdateTask);
    }

    public String ScanPort(){
       try{

           DatagramSocket socket = new DatagramSocket();

           int port = MyApplication.Companion.getNumCurrentPort().getPortID().intValue();

         //  byte bufReceive[] = new byte[2048];

           socket.connect(InetAddress.getByName(MyApplication.Companion.getStrCurrentAdressIP().getStrAdresse()), port);

           socket.setBroadcast(true);
           String strMessageReturn;
           String strMessageSent;
           strMessageSent=MyApplication.Companion.getStrTextSentUDP().getStrText();

           byte[] sendData;
           sendData=strMessageSent.getBytes();

           LocalAdress=socket.getLocalAddress().toString();
           LocalAdress=LocalAdress.substring(1,LocalAdress.length());
           LocalPort=Integer.toString(socket.getLocalPort());
           RemortPort= MyApplication.Companion.getNumCurrentPort().getPortID().toString();

           DatagramPacket sendPacket  = new DatagramPacket(sendData, sendData.length, InetAddress.getByName(MyApplication.Companion.getStrCurrentAdressIP().getStrAdresse()), port);
           socket.send(sendPacket);

           strMessageReturn=   act.getString(R.string.info_udp)+"\n";
           strMessageReturn= strMessageReturn+ act.getString(R.string.info_udp_adresse_distant)+ " " + MyApplication.Companion.getStrCurrentAdressIP().getStrAdresse()+"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_port_distant)+ " "  + RemortPort +"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_texte_envoye)+ " " +  strMessageSent+"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_adresse_locale)+ " "+ LocalAdress+"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_port_local)+" " +  LocalPort +"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_donnees_envoyees)+" " +sendData.toString() +"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_lie)+" "+Boolean.toString(socket.isBound()) +"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_connecte)+" " +Boolean.toString(socket.isConnected()) +"\n";

            if(socket.isConnected()){
                socket.disconnect();
                socket.close();
                return  strMessageReturn;
            }else{

                socket.close();
                return "";
            }

        }catch (UnknownHostException e){

           String strMessageReturn;
           strMessageReturn= act.getString(R.string.info_udp_erreur)+"\n";
           strMessageReturn=  strMessageReturn+ "UnknownHost: "+ e.getMessage()+"\n";
           strMessageReturn= strMessageReturn+ act.getString(R.string.info_udp_adresse_distant)+ " " + MyApplication.Companion.getStrCurrentAdressIP().getStrAdresse()+"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_port_distant)+ " "  + RemortPort +"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_texte_envoye)+ " " + MyApplication.Companion.getStrTextSentUDP().getStrText()+"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_adresse_locale)+ " "+LocalAdress +"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_port_local)+" " +  LocalPort +"\n";

            return  strMessageReturn;}

       catch (IOException e1) {

           String strMessageReturn;
           strMessageReturn= act.getString(R.string.info_udp_erreur)+"\n";
           strMessageReturn=  strMessageReturn+ "IOException: "+ e1.getMessage()+"\n";
           strMessageReturn= strMessageReturn+ act.getString(R.string.info_udp_adresse_distant)+ " " + MyApplication.Companion.getStrCurrentAdressIP().getStrAdresse()+"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_port_distant)+ " "  + RemortPort +"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_texte_envoye)+ " " + MyApplication.Companion.getStrTextSentUDP().getStrText()+"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_adresse_locale)+ " "+LocalAdress +"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_port_local)+" " +  LocalPort +"\n";

           return  strMessageReturn;
        }

       catch (SecurityException e2) {
           String strMessageReturn;
           strMessageReturn= act.getString(R.string.info_udp_erreur)+"\n";
           strMessageReturn=  strMessageReturn+ "SecurityException: "+ e2.getMessage()+"\n";
           strMessageReturn= strMessageReturn+ act.getString(R.string.info_udp_adresse_distant)+ " " + MyApplication.Companion.getStrCurrentAdressIP().getStrAdresse()+"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_port_distant)+ " "  + RemortPort +"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_texte_envoye)+ " " + MyApplication.Companion.getStrTextSentUDP().getStrText()+"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_adresse_locale)+ " "+LocalAdress +"\n";
           strMessageReturn= strMessageReturn+act.getString(R.string.info_udp_port_local)+" " +  LocalPort +"\n";

           return  strMessageReturn;
       }

    }
}
