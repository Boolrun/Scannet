package com.boolrun.scannet

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import java.net.UnknownHostException
import android.view.Gravity
import androidx.core.app.ActivityCompat.startActivityForResult
import java.io.IOException
import java.lang.ref.WeakReference

class BluetoothReceiver : BroadcastReceiver() {

    var deviceName:String=""
    var deviceAddress:String=""

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (BluetoothDevice.ACTION_FOUND == action) {

            val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)


            if  (deviceName.isNullOrEmpty()){
                deviceName=device.address
            }else{
                deviceName=device.name
            }

            deviceAddress=device.address

        }
    }
}


class FragmentBlueTooth : Fragment() {

    class mBBActivity {
        var objActivity: Activity?=null
    }

    class mBBContext {
        var objContext: Context?=null
    }

    class mDevice {
        var strName: String=""
    }

    class strStatusBB {
        var strValue: String = "Start"
    }

    companion object {

        private var countDevice:Int=0
        private var countDeviceDiscovered:Int=1
        private var countDevicePaired:Int=0
        var bluetoothReceiverCompanion: BluetoothReceiver?= null
        private val REQUEST_ENABLE_BT = 1
        private val SCAN_PERIOD: Long = 5000
        private val PERMISSION_REQUEST_COARSE_LOCATION = 1
        private val mListView: ListView? = null
        val strStatusBB=strStatusBB()

        val mBBContext= mBBContext()
        val mBBActivity=mBBActivity()

        val resultBlueTScan = arrayOfNulls<String>(1000)
        val resultBlueTScanDiscovered = arrayOfNulls<String>(1000)
        val resultBlueTScanMixed = arrayOfNulls<String>(1000)

        @JvmStatic
        fun newInstance() =
            FragmentBlueTooth().apply {
                arguments = Bundle().apply {

                }
            }

        class BBLogicTask internal constructor(context: FragmentBlueTooth) : AsyncTask<String, String, String?>() {
            private val activityReference: WeakReference<FragmentBlueTooth> = WeakReference(context)
            override fun doInBackground(vararg statutBouton: String): String {
                return try {

                    if( strStatusBB.strValue=="Stop") {

                        cancel(true)
                        return ""
                    }

                    val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
                    if (bluetoothAdapter == null) {
                        Toast.makeText(mBBContext.objContext,  mBBActivity.objActivity!!.getString(R.string.blue_tooth_non_supporte), Toast.LENGTH_SHORT).show()
                    }

                    val REQUEST_ENABLE_BLUETOOTH = 1

                    val permission2:String = "android.permission.BLUETOOTH_ADMIN"
                    val permission3:String = "android.permission.BLUETOOTH"
                    val permission_array = arrayOf( permission2, permission3)

                    ActivityCompat.requestPermissions(mBBActivity.objActivity!!, permission_array, 0)

                    if(!bluetoothAdapter!!.isEnabled) {
                        val enableBluetoothIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                        val bundle= Bundle()
                        startActivityForResult(mBBActivity.objActivity!!,enableBluetoothIntent, REQUEST_ENABLE_BLUETOOTH,bundle)
                    }

                    if (bluetoothReceiverCompanion == null) {
                        bluetoothReceiverCompanion = BluetoothReceiver()
                        val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
                        mBBActivity.objActivity!!.registerReceiver(bluetoothReceiverCompanion, filter)

                    }
                    if (bluetoothAdapter.isDiscovering) {
                        bluetoothAdapter.cancelDiscovery()
                    }
                    bluetoothAdapter.startDiscovery()

                    bluetoothReceiverCompanion!!.goAsync()

                    Thread.sleep(3000)

                    if (bluetoothReceiverCompanion!!.deviceName.isNullOrEmpty()){

                        return ""
                    }else{
                        val strdevice:String=bluetoothReceiverCompanion!!.deviceName
                        val stradress:String=bluetoothReceiverCompanion!!.deviceAddress

                        if(strdevice==stradress){
                            return ""
                        }

                        return strdevice + "\n"+ stradress +" - " + mBBActivity.objActivity!!.getString(R.string.bb_decouvert)
                    }

                } catch (e: IOException) {

                    e.message.toString()
                }
            }

            override fun onCancelled(result: String?) {

            }

            override fun onPostExecute(result: String?) {

              try {

                  var bdevicefound:Boolean=false

                  if (!result.isNullOrEmpty()){
                      for (x in 0..countDeviceDiscovered-1)
                      {

                          if(resultBlueTScanDiscovered.get(x)==result){

                              bdevicefound=true
                          }
                      }
                  }

                  var iCount:Int=0


                  if  (bdevicefound==false && !result.isNullOrEmpty()){
                      resultBlueTScanDiscovered.set(countDeviceDiscovered-1,result)
                      countDeviceDiscovered=countDeviceDiscovered+1

                  }

                  for (x in 0..countDevice-1){

                        resultBlueTScanMixed.set(x,resultBlueTScan.get(x))
                        iCount=iCount+1
                  }

                  if (countDeviceDiscovered>1){
                      for (x in 0..countDeviceDiscovered-2){

                          resultBlueTScanMixed.set(iCount,resultBlueTScanDiscovered.get(x))
                          iCount=iCount+1
                      }
                  }

                  if (strStatusBB.strValue!="Stop"){
                        if (iCount>countDevice){
                            val mListView =  mBBActivity.objActivity!!.findViewById(R.id.listViewResultBlueT) as ListView
                            val adapter = ArrayAdapter<String>(mBBContext.objContext, android.R.layout.simple_list_item_1 ,  resultBlueTScanMixed)
                            mListView.setAdapter(adapter)
                          }else{
                            val mListView =  mBBActivity.objActivity!!.findViewById(R.id.listViewResultBlueT) as ListView
                            val adapter = ArrayAdapter<String>(mBBContext.objContext, android.R.layout.simple_list_item_1 ,  resultBlueTScan)
                            mListView.setAdapter(adapter)
                        }

                  }

                } catch (e: UnknownHostException) {

                }
            }

        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {



        mBBContext.objContext=inflater.context

        val view: View = inflater.inflate(R.layout.activity_bluetooth, container, false)
        val btn_click_me = view.findViewById(R.id.cmdOKSearchBlueT) as Button
        val btn_click_stop = view.findViewById(R.id.cmdStopSearchBlueT) as Button
        btn_click_stop.isClickable=false
        btn_click_stop.isEnabled=false

        btn_click_me.setOnClickListener(ButtonOkClick())
        btn_click_stop.setOnClickListener(ButtonStopClick())

        mBBActivity.objActivity=activity

        return view


    }

    internal inner class ButtonStopClick : View.OnClickListener {

        override fun onClick(v: View) {

            ButtonStopClicked()
        }
    }

    private fun ButtonStopClicked() {

        val progressBar = activity!!.findViewById<View>(R.id.progressB)

          if (progressBar != null) {
             progressBar.visibility = View.INVISIBLE
             MyApplication.asyncRunning.bValue=false
         }

         strStatusBB.strValue="Stop"
         val btnStop:Button = view?.findViewById(R.id.cmdStopSearchBlueT) as Button
         btnStop.isClickable=false
         btnStop.isEnabled=false
         val btnStart:Button = view?.findViewById(R.id.cmdOKSearchBlueT) as Button
         btnStart.isClickable=true

        countDevice=0
        countDeviceDiscovered=1
        countDevicePaired=0

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        activity?.setTitle("")

    }

    private fun ButtonOkClicked() {


        var i:Int=0

        val progressBar = activity!!.findViewById<View>(R.id.progressB)

        if (progressBar != null) {
            progressBar.visibility = View.VISIBLE
             MyApplication.asyncRunning.bValue=true
        }

        strStatusBB.strValue="Start"
        val btnStop:Button = view?.findViewById(R.id.cmdStopSearchBlueT) as Button
        btnStop.isClickable=true
        btnStop.isEnabled=true
        val btnStart:Button = view?.findViewById(R.id.cmdOKSearchBlueT) as Button
        btnStart.isClickable=false

        try {
            val mListView = activity!!.findViewById(R.id.listViewResultBlueT) as ListView

            for (x in 0..200)
            {
                resultBlueTScan.set( x, " ")
                resultBlueTScanMixed.set( x, " ")
                resultBlueTScanDiscovered.set( x, " ")
            }

            val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
            if (bluetoothAdapter == null) {
                Toast.makeText(context, getString(R.string.blue_tooth_non_supporte), Toast.LENGTH_SHORT).show()
            }

              val mBluetoothAdapter =  BluetoothAdapter.getDefaultAdapter()
              val pairedDevices = mBluetoothAdapter.bondedDevices

                for (bt in pairedDevices){
                    bt.address
                    resultBlueTScan.set(i,bt.name +"\n"+ bt.address + " - " +getString(R.string.bb_lie) )
                    i+=1
                    countDevice=i
                }

            countDevicePaired=countDevice

            for (x in 0..5000)
            {
                if (strStatusBB.strValue=="Stop") {
                    btnStop.isClickable=false
                    btnStop.isEnabled=false
                    btnStart.isClickable=true
                    if (progressBar != null) {
                        progressBar.visibility = View.INVISIBLE
                         MyApplication.asyncRunning.bValue=false
                    }

                    break
                }
                val task =BBLogicTask(this)
                task.execute("Scan" )
            }


            val adapter = ArrayAdapter<String>(context, android.R.layout.simple_list_item_1 , resultBlueTScan)
            mListView.setAdapter(adapter)

        } catch (e: UnknownHostException) {

        }

    }

    fun showMessage(strMessage: String) {
        val toast_obj= Toast.makeText(this.activity,strMessage, Toast.LENGTH_SHORT)
        toast_obj.setGravity(Gravity.TOP, 0, 120)
        toast_obj.show()
    }

    internal inner class ButtonOkClick : View.OnClickListener {

        override fun onClick(v: View) {

            if (MyApplication.asyncRunning.bValue==true){
                showMessage(getString(R.string.info_scan_actif))
                return
            }

            ButtonOkClicked()
        }
    }

   private fun makeDiscoverable() {
        val discoverableIntent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
        discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
        startActivity(discoverableIntent)
        //Log.i("Log", "Discoverable ")
    }

}







