package com.boolrun.scannet;

import android.util.Log;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;


public class ScanPortTask implements Runnable{

  int NumPort;

    ScanPortResultUpdateTask resultUpdateTask;



    public ScanPortTask(ScanPortResultUpdateTask drUpdateTask){

          resultUpdateTask = drUpdateTask;
    }

    @Override
    public void run() {
        String msg;
        msg="";

       if(ScanPort()){

            msg = "OKPort";
        }else{
            msg = "FailPort";
        }

        MyApplication.Companion.getStrResultSocketMessage().setStrTextMessage(msg);


        resultUpdateTask.setBackgroundMsg(msg);
        ScanPortManager.getScanPortManager().getMainThreadExecutor()
                .execute(resultUpdateTask);
    }

    public boolean ScanPort(){
       try{

            Socket socket;

     //      Log.d("ScanPort()",   MyApplication.Companion.getNumCurrentPort().getPortID().toString());


           socket = new Socket();


            socket.connect(new InetSocketAddress(MyApplication.Companion.getStrCurrentAdressIP().getStrAdresse(), MyApplication.Companion.getNumCurrentPort().getPortID().intValue()), MyApplication.Companion.getNumTempsReponse().getNumMilliseconde().intValue());

           return socket.isConnected();






        }catch (UnknownHostException e){


           e.printStackTrace();

            return false;}  catch (IOException e1) {

        e1.printStackTrace();
           return false;
    }

    }
}
