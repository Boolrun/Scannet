package com.boolrun.scannet

class ObjectPosition {

    var id: Int = 0
    var strLatitude: String? = null
    var strLongitude: String? = null
    var dateScan: String?=null
    var strMethode: String?=null
    var strPrecision: String?=null

    constructor(id: Int, latitude: String, longitude: String, datescan:String, methode:String,precision:String) {
        this.id = id
        this.strLatitude = latitude
        this.strLongitude =longitude
        this.dateScan=datescan
        this.strMethode=methode
        this.strPrecision=precision

    }

    constructor(latitude: String, longitude: String, datescan:String, methode:String, precision:String) {
        this.strLatitude = latitude
        this.strLongitude =longitude
        this.dateScan=datescan
        this.strMethode=methode
        this.strPrecision=precision
    }

}

class ObjectWifi {

    var id: Int = 0
    var strSSID: String? = null
    var strBSSID: String? = null
    var strFrequence: String? = null
    var strLevel: String? = null
    var strSecurite: String? = null
    var strCanal: String? = null
    var strDistance: String? = null
    var dateScanWifi: String?=null
    var idPosition: Int = 0

    constructor(id: Int, strssid: String, strbssid: String,strfrequence: String,strlevel: String,strsecurite: String,strcanal: String,strdistance: String, datescanwifi:String,idposition: Int) {
        this.id = id
        this.strSSID = strssid
        this.strBSSID =strbssid
        this.strFrequence = strfrequence
        this.strLevel =strlevel
        this.strSecurite = strsecurite
        this.strCanal =strcanal
        this.strDistance = strdistance
        this.dateScanWifi = datescanwifi
        this.idPosition =idposition
    }

    constructor(strssid: String, strbssid: String,strfrequence: String,strlevel: String,strsecurite: String,strcanal: String,strdistance: String, datescanwifi:String,idposition: Int) {
        this.strSSID = strssid
        this.strBSSID =strbssid
        this.strFrequence = strfrequence
        this.strLevel =strlevel
        this.strSecurite = strsecurite
        this.strCanal =strcanal
        this.strDistance = strdistance
        this.dateScanWifi = datescanwifi
        this.idPosition =idposition
    }

}