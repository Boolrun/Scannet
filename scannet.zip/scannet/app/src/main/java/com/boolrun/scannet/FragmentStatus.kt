package com.boolrun.scannet


import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Context.CLIPBOARD_SERVICE
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.wifi.WifiManager
import android.os.Bundle
import android.telephony.TelephonyManager
import android.text.format.Formatter
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.*
import androidx.lifecycle.ViewModel
import android.widget.ImageButton
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.math.BigDecimal
import java.math.RoundingMode

class MViewModelStatus : ViewModel() {
    internal var lastActiveFragmentTag: String? = null
}

class FragmentStatus : Fragment() {

    private var strGateway:String?=""

  companion object {


      fun getNetworkClass(context: Context): String {
          val mTelephonyManager =
              context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
          val networkType = mTelephonyManager.networkType
          return when (networkType) {
              TelephonyManager.NETWORK_TYPE_GPRS, TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_CDMA, TelephonyManager.NETWORK_TYPE_1xRTT, TelephonyManager.NETWORK_TYPE_IDEN -> "2G"
              TelephonyManager.NETWORK_TYPE_UMTS, TelephonyManager.NETWORK_TYPE_EVDO_0, TelephonyManager.NETWORK_TYPE_EVDO_A, TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA, TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_EVDO_B, TelephonyManager.NETWORK_TYPE_EHRPD, TelephonyManager.NETWORK_TYPE_HSPAP -> "3G"
              TelephonyManager.NETWORK_TYPE_LTE -> "4G"
              else -> "Unknown"
          }
      }

      fun getMacAddr(): String {
          try {
              val all: List<NetworkInterface> =
                  Collections.list(NetworkInterface.getNetworkInterfaces())
              for (nif in all) {
                  if (!nif.name.equals("wlan0", ignoreCase = true)) continue
                  val macBytes = nif.hardwareAddress ?: return ""
                  val res1 = StringBuilder()
                  for (b in macBytes) {
                      res1.append(String.format("%02X:", b))
                  }
                  if (res1.length > 0) {
                      res1.deleteCharAt(res1.length - 1)
                  }
                  return res1.toString()
              }
          } catch (ex: java.lang.Exception) {
          }
          return "02:00:00:00:00:00"
      }

      @JvmStatic
        fun newInstance() =
            FragmentStatus().apply {
                arguments = Bundle().apply {
                    // putString(ARG_PARAM1, param1)
                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            // param1 = it.getString(ARG_PARAM1)
        }
    }

    private lateinit var viewModel: MViewModel

    @SuppressLint("DefaultLocale")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        viewModel= MViewModel()


        val view: View = inflater!!.inflate(R.layout.activity_status, container, false)

        val btn_click_scanip = view.findViewById(R.id.imgScanIP) as ImageButton

        btn_click_scanip?.setOnClickListener() {
            ButtonScanIPClicked()

        }

        val imgViewCopyButton = view.findViewById<ImageButton>(R.id.imageCopyStatus)

        imgViewCopyButton?.setOnClickListener() {
            ButtonCopyClicked()

        }

        val bNetConnect:Boolean=netConnect(inflater.context)

        val iAdr:InetAddress=InetAddress.getLocalHost()
        val wifiManager =  inflater!!.context!!.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val editStatus =  view!!.findViewById(R.id.editStatus) as EditText

        editStatus.isEnabled=false

        wifiManager.reconnect()
        wifiManager.startScan()
        val MobileIPAddress=getMobileIPAddress()

        val configMobile=inflater!!.context!!.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val mWifi = configMobile.activeNetworkInfo//  .getNetworkInfo(ConnectivityManager.TYPE_WIFI)

        var wifiStr:String
        var mobileStr:String

        wifiManager.getScanResults()

        var wifiIpAdress:String
        var wifiDNS1:String
        var wifiDNS2:String
        var wifiGateway:String
        var wifiNetmask:String
        var wifiServer:String

        var macAdress:String
        var  wifiSSID:String
        var  wifiBSSID:String
        var  wifiFrequency:String
        var  wifiSeepd:String
        var  wifiFrequencyFloat:Float

        wifiStr= getString(R.string.info_network_wifi)+"\n"
        mobileStr=getString(R.string.info_network_mobile_network)+"\n"

        if ( mWifi!=null){

        if (mWifi.isConnected && configMobile.activeNetworkInfo.isConnected && wifiManager.connectionInfo.bssid !=null) {

            macAdress= getMacAddr()
            wifiIpAdress=Formatter.formatIpAddress(wifiManager.dhcpInfo.ipAddress)
            wifiGateway=Formatter.formatIpAddress(wifiManager.dhcpInfo.gateway)
            strGateway=wifiGateway
            wifiDNS1=Formatter.formatIpAddress(wifiManager.dhcpInfo.dns1)
            wifiDNS2=Formatter.formatIpAddress(wifiManager.dhcpInfo.dns2)
            wifiNetmask=Formatter.formatIpAddress(wifiManager.dhcpInfo.netmask)
            wifiServer=Formatter.formatIpAddress(wifiManager.dhcpInfo.serverAddress)
            wifiSSID=wifiManager.connectionInfo.ssid
            wifiStr=wifiStr+"SSID: "+  wifiSSID+"\n"
            if(wifiManager.connectionInfo.bssid!=null){
                wifiBSSID=wifiManager.connectionInfo.bssid
                wifiStr=wifiStr+"BSSID: "+  wifiBSSID+"\n"
            }

            wifiFrequencyFloat=wifiManager.connectionInfo.frequency.toFloat()/1000
            wifiFrequency= wifiFrequencyFloat.toString()
            wifiSeepd= wifiManager.connectionInfo.linkSpeed.toString()

            wifiStr=wifiStr+getString(R.string.info_network_wifi_mac)+" "+ macAdress+"\n"
            wifiStr=wifiStr+getString(R.string.info_network_wifi_ip)+" "+ wifiIpAdress+"\n"
            wifiStr=wifiStr+getString(R.string.info_network_wifi_passerelle)+" "+ wifiGateway+"\n"
            wifiStr=wifiStr+getString(R.string.info_network_wifi_dns1)+" "+ wifiDNS1+"\n"
            wifiStr=wifiStr+getString(R.string.info_network_wifi_dns2)+" "+ wifiDNS2+"\n"
            wifiStr=wifiStr+getString(R.string.info_network_wifi_masque)+" "+ wifiNetmask+"\n"
            wifiStr=wifiStr+getString(R.string.info_network_wifi_serveur)+" "+  wifiServer+"\n"
            wifiStr=wifiStr+getString(R.string.info_network_wifi_frequence)+" "+  wifiFrequency+" GHz \n"
            wifiStr=wifiStr+getString(R.string.info_network_wifi_vitesse)+" "+ wifiSeepd+" mbps \n"

        }else{
            wifiStr=getString(R.string.info_network_wifi)+"\n"
            wifiStr=wifiStr+getString(R.string.info_udp_reception_non_connecte)+"\n"

        }
        }else{
            wifiStr=getString(R.string.info_network_wifi)+"\n"
            wifiStr=wifiStr+getString(R.string.info_udp_reception_non_connecte)+"\n"
        }

        if (configMobile.getNetworkInfo(0) !=null){

            val mobileAdr:NetworkInfo=configMobile.getNetworkInfo(0)

        var mobileIpAdress:String
        var mobileEstConnecte:String
        var mobileExtra:String
        var mobileUPDbl:Double
        var mobileUP:String
        var mobileDownDbl:Double
        var mobileDown:String
        var iPos:Int
        var mobileType:String
        var mobileRoaming:String
        var mobileByteInputStream:String

        if (configMobile.activeNetworkInfo !=null){

            val tm=inflater!!.context!!.getSystemService(android.content.Context.TELEPHONY_SERVICE) as TelephonyManager

            val nc =configMobile.getNetworkCapabilities(configMobile.allNetworks[0])

            var longdecimal = BigDecimal(nc.linkUpstreamBandwidthKbps/1024).setScale(4, RoundingMode.HALF_EVEN)
            mobileUPDbl=longdecimal.toDouble()
            longdecimal = BigDecimal( nc.linkDownstreamBandwidthKbps/1024).setScale(4, RoundingMode.HALF_EVEN)
            mobileDownDbl= longdecimal.toDouble()

            mobileUP=mobileUPDbl.toString()
            mobileDown=mobileDownDbl.toString()
            mobileType=getNetworkClass(inflater!!.context)

            mobileIpAdress=MobileIPAddress.toString()

            if (mobileIpAdress.length>0){
                iPos=mobileIpAdress.indexOf("%dummy",0,true)
                if (iPos>0){
                    mobileIpAdress=mobileIpAdress.substring(0,iPos)
                }
            }


            mobileStr=mobileStr+getString(R.string.info_network_mobile_type)+" "+    mobileType +"\n"
            mobileStr=mobileStr+getString(R.string.info_network_mobile_operateur)+" "+  tm.networkOperatorName +" ("+ tm.networkOperator.toString() +")\n"

            val permission2:String = "android.permission.READ_PHONE_STATE"
            val permission_array = arrayOf( permission2)
            ActivityCompat.requestPermissions(activity!!, permission_array, 0)

            mobileStr=mobileStr+getString(R.string.info_network_mobile_pays)+" "+  tm.networkCountryIso.toUpperCase() +"\n"

            mobileStr=mobileStr+getString(R.string.info_network_mobile_agent)+" "+  tm.mmsUserAgent+ "\n"

            mobileStr=mobileStr+getString(R.string.info_network_mobile_ip)+" "+ mobileIpAdress +"\n"
            mobileStr=mobileStr+getString(R.string.info_network_mobile_vitesse_up)+" "+  mobileUP +" Mbps\n"
            mobileStr=mobileStr+getString(R.string.info_network_mobile_vitesse_down)+" "+   mobileDown +" Mbps \n"

        }else{
            mobileStr=getString(R.string.info_network_mobile_network)+"\n"
            mobileStr=mobileStr+getString(R.string.info_udp_reception_non_connecte)+"\n"
        }
        }else{
            mobileStr=getString(R.string.info_network_mobile_network)+"\n"
            mobileStr=mobileStr+getString(R.string.info_udp_reception_non_connecte)+"\n"
        }
        editStatus.setText(wifiStr+"\n"+mobileStr)

        return view

        return inflater.inflate(R.layout.activity_status, container, false)
    }

fun getMobileIPAddress(): String? {
        try {
            val interfaces: List<NetworkInterface> =
                Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val addrs: List<InetAddress> =
                    Collections.list(intf.getInetAddresses())
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress()) {
                        return addr.getHostAddress().toString()

                    }
                }
            }
        } catch (ex: java.lang.Exception) {
        }
        return ""
    }

     fun netConnect(ctx: Context): Boolean {
         val cm: ConnectivityManager
         var info: NetworkInfo? = null
         try {
             cm =
                 ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
             info = cm.activeNetworkInfo
         } catch (e: Exception) {
             e.printStackTrace()
         }
         return if (info != null) {
             true
         } else {
             false
         }
     }


    private fun ButtonCopyClicked() {

        val editStatus =  view!!.findViewById(R.id.editStatus) as EditText
        val myClipboard: ClipboardManager = activity!!.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val myClip: ClipData
        val strText=editStatus.text

        myClip = ClipData.newPlainText("textStatus", strText);
        myClipboard.setPrimaryClip(myClip);

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
         super.onActivityCreated(savedInstanceState)

         activity?.setTitle("")

     }

    fun showMessage(strMessage: String) {
        val toast_obj= Toast.makeText(this.activity,strMessage, Toast.LENGTH_SHORT)
        toast_obj.setGravity(Gravity.TOP, 0, 120)
        toast_obj.show()
    }

    private fun ButtonScanIPClicked() {

        if (MyApplication.asyncRunning.bValue==true){
            showMessage(getString(R.string.info_scan_actif))
            return
        }

        if (strGateway.isNullOrEmpty()){
            return
        }
        MyApplication.strIPAdr1.strAdr1=strGateway!!

        val frgTCPIP=FragmentTcpIp()
        val fragmentManager = activity!!.supportFragmentManager
        val fragmentTransaction=  fragmentManager.beginTransaction()

        if (viewModel.lastActiveFragmentTag != null) {
            val lastFragment = fragmentManager.findFragmentByTag(viewModel.lastActiveFragmentTag)
            if (lastFragment != null)
                fragmentTransaction.hide(lastFragment)
        }

        fragmentTransaction.replace(R.id.fragmentContainer,frgTCPIP)
        fragmentTransaction.disallowAddToBackStack()
        fragmentTransaction.commit()

        val navigationView =
            activity!!.findViewById<View>(R.id.nav_view) as BottomNavigationView
        navigationView.menu.getItem(0).isChecked = true

    }
    internal inner class ButtonCopyText : View.OnClickListener {

        override fun onClick(v: View) {


            ButtonCopyClicked()
        }
    }

}



