package com.boolrun.scannet

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.*
import android.content.res.Resources
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import com.google.android.gms.maps.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.provider.Settings
import android.view.*
import android.widget.*

import androidx.core.app.ActivityCompat
import com.google.android.gms.maps.model.*
import kotlin.math.roundToInt

class mMapContext {
    var objContext: Context ?=null
}

class mMapActivity {
    var objActivity: Activity?=null
}

class FragmentMaps : Fragment(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap

    companion object {

        val mMapActivity= mMapActivity()
        var mapFragment : SupportMapFragment?=null
        val TAG: String = MapFragment::class.java.simpleName
        fun newInstance() = MapFragment()

        lateinit var locationManagerMap:LocationManager
        private var hasGPSMap=false
        private var hasNetworkaMap=false
        private  var locationGPSMap: Location?=null
        private  var locationNetworkMap: Location?=null
        private  var locationBestMap: Location?=null
        private  var strMethodeMap:String ?=""
        private  var strPrecisionMap:String ?=""
        private  var strCurrentLongitude:String?=""
        private  var strCurrentLatitude:String?=""
        private  var currentMarker: Marker?=null
        val mMapContext= mMapContext()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        getLocation(inflater!!.context)

        var rootView = inflater.inflate(R.layout.activity_maps, container, false)

        mapFragment =  childFragmentManager.findFragmentById(R.id.objMap) as SupportMapFragment// fragmentManager?.findFragmentById(R.id.fallasMap) as SupportMapFragment?
        mapFragment?.getMapAsync(this)

        mMapContext.objContext=inflater!!.context
        mMapActivity.objActivity=this.activity

        val imgViewDeleteMarker = rootView.findViewById<ImageButton>(R.id.imgDeleteMarker)
        val imgWifiCopyButton =rootView.findViewById<ImageButton>(R.id.imageCopyWifi)

        imgViewDeleteMarker?.setOnClickListener() {
                showDialog(getString(R.string.question_supprimer_position))
        }

        imgWifiCopyButton?.setOnClickListener() {

            ButtonCopyWiFiClicked()
        }

        return rootView
    }

    override fun onMapReady(googleMap: GoogleMap?) {
        mMap = googleMap!!

        if(locationBestMap==null){

        }else{
            val currentLocation= LatLng(locationBestMap!!.latitude.toDouble(), locationBestMap!!.longitude.toDouble() )

            mMap.addMarker(MarkerOptions().position(currentLocation).title(getString(R.string.titre_position_courrante)).icon(
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)))
            mMap.moveCamera(CameraUpdateFactory.newLatLng(currentLocation))

            val cameraPosition = CameraPosition.Builder()
                .target(currentLocation)
                .zoom(17.5F)
                .bearing(0f)
                .tilt(25f)
                .build()

            mMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition))

        }

        try {

            val success = googleMap.setMapStyle(
                MapStyleOptions.loadRawResourceStyle(
                    context, R.raw.style_json
                )
            )
            if (!success) {

            }
        } catch (e: Resources.NotFoundException) {

        }

        val dbHandler = ObjectBD(mMapContext!!.objContext!!, null, null, 3)

        var x:Int = 0
        var id:Int = 0
        var latitude:String=""
        var longitude:String=""
        var datescan:String=""
        var multipleLocation: LatLng

        if (MyApplication.strBSSIDforMap.strValue.isNullOrEmpty()){

        var cursor:Cursor=dbHandler.getDistinctPosition()
        if (cursor.count>0) {

            for(x in 0..cursor.count-1 ){
                cursor.moveToPosition(x)
                id = x
                latitude = cursor.getString(1)
                longitude = cursor.getString(2)
                datescan = ""

                if (datescan.isNullOrEmpty()) {
                    datescan=""
                }

                if (!latitude!!.isNullOrEmpty()){
                    multipleLocation=LatLng(latitude!!.toDouble(), longitude!!.toDouble() )
                    mMap.addMarker(MarkerOptions().position(multipleLocation).title(latitude+","+ longitude))
                }

            }
        }
            cursor.close()
            dbHandler.close()
        }else{

            var cursor:Cursor=dbHandler.getPositionForBSSID(MyApplication.strBSSIDforMap.strValue)

            if (cursor.count>0) {

                val imgCopyWifi=   getView()?.findViewById(R.id.imageCopyWifi) as ImageButton
                imgCopyWifi.visibility = View.VISIBLE

                for(x in 0..cursor.count-1 ){
                    cursor.moveToPosition(x)
                    id = x
                    latitude = cursor.getString(0)
                    longitude = cursor.getString(1)
                    datescan = ""

                    if (datescan.isNullOrEmpty()) {
                        datescan=""
                    }

                    if (!latitude!!.isNullOrEmpty() && !longitude!!.isNullOrEmpty()){

                        multipleLocation=LatLng(latitude!!.toDouble(), longitude!!.toDouble() )
                        mMap.addMarker(MarkerOptions().position(multipleLocation).title(latitude+","+ longitude))
                    }

                }
            }
            cursor.close()
            dbHandler.close()

            var strResultat:String=""
            val editTextResultWifi=   getView()?.findViewById(R.id.editTextResultWifi) as EditText
            strResultat= dbHandler.getWifiByBSSID(MyApplication.strBSSIDforMap.strValue,mMapActivity.objActivity).toString()
            editTextResultWifi.setText(strResultat)

        }

        val txtPosition=   getView()?.findViewById(R.id.positiomap) as TextView
        val editTextResultWifi=   getView()?.findViewById(R.id.editTextResultWifi) as EditText
        var ipos:Int
        var strPosition:String=""
        var strLat:String=""
        var strLong:String=""

        var strResultat:String=""

        mMap.setOnMarkerClickListener { marker ->
            if (marker.isInfoWindowShown) {
                marker.hideInfoWindow()
                txtPosition.setText(marker.title)
            } else {
                marker.showInfoWindow()
                txtPosition.setText(marker.title)

                if (getString(R.string.titre_position_courrante)==marker.title){

                }else{

                    if (MyApplication.strBSSIDforMap.strValue.isNullOrEmpty()){

                    currentMarker=marker
                    strPosition=marker.title
                    ipos=strPosition.indexOf(",",0)
                    strLat=strPosition.substring(0,ipos)
                    strLong=strPosition.substring(ipos+1,strPosition.length)

                    strCurrentLongitude=strLong
                    strCurrentLatitude=strLat
                    strResultat= dbHandler.getWifiByPosition(strLat,strLong,mMapActivity.objActivity).toString()
                    editTextResultWifi.setText(strResultat)

                    val posResult:ObjectPosition ?= dbHandler.findPosition(strLat, strLong)
                    var strMethode=posResult!!.strMethode
                    var strPrecision=posResult!!.strPrecision

                    val txtInfoPosition=   getView()?.findViewById(R.id.infopositiomap) as TextView

                    txtInfoPosition.setText(getString(R.string.pos_method) +" "+ strMethode  +"   "+ getString(R.string.pos_precision)+" "+strPrecision)

                    val imgDeleteMarker=   getView()?.findViewById(R.id.imgDeleteMarker) as ImageButton
                    imgDeleteMarker.visibility = View.VISIBLE

                    val imgCopyWifi=   getView()?.findViewById(R.id.imageCopyWifi) as ImageButton
                    imgCopyWifi.visibility = View.VISIBLE
                    }

                }

            }
            true
        }

    }

    private fun ButtonCopyWiFiClicked() {

        val editWifiResult =  view!!.findViewById(R.id.editTextResultWifi) as EditText
        val txtPosition =  view!!.findViewById(R.id.positiomap) as TextView
        val myClipboard: ClipboardManager = activity!!.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val myClip: ClipData
        val strText=txtPosition.text.toString() + "\n\n"+ editWifiResult.text

        myClip = ClipData.newPlainText("textWiFi Router", strText);
        myClipboard.setPrimaryClip(myClip);

    }

    fun showMessage(strMessage: String) {
        val toast_obj= Toast.makeText(this.activity,strMessage, Toast.LENGTH_SHORT)
        toast_obj.setGravity(Gravity.TOP, 0, 120)
        toast_obj.show()
    }

    public fun getLocation(ctx: Context?){
        var locationManager: LocationManager =ctx!!.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var hasGPS=locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        var hasNetwork=locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)


        if (ActivityCompat.checkSelfPermission(
                ctx,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                ctx,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            val permission2:String = "android.permission.ACCESS_COARSE_LOCATION"
            val permission:String = "android.permission.ACCESS_FINE_LOCATION"
            val permission_array = arrayOf( permission,permission2)
            ActivityCompat.requestPermissions(activity!!, permission_array, 0)

        }

        if( hasGPS || hasNetwork){

            if (hasGPS){

                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000, 0F,  object:
                    LocationListener {

                    @Override
                    override fun onLocationChanged(location: Location?) {
                        if(location !=null){
                            locationGPSMap=location
                        }
                    }

                    @Override
                    override fun onStatusChanged( provider: String?,  status: Int,  extras: Bundle?) {

                    }

                    @Override
                    override fun onProviderEnabled( provider:String?) {

                    }

                    @Override
                    override  fun onProviderDisabled( provider:String?) {

                    }

                })

                val localGPSLocation=  locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                if (localGPSLocation!=null)locationGPSMap=localGPSLocation

            }

            if (hasNetwork){

                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,5000, 0F,
                    object:LocationListener{

                        @Override
                        override fun onLocationChanged(location: Location?) {
                            if(location !=null){
                                locationNetworkMap=location
                            }
                        }

                        @Override
                        override fun onStatusChanged( provider: String?,  status: Int,  extras: Bundle?) {

                        }

                        @Override
                        override fun onProviderEnabled( provider:String?) {

                        }

                        @Override
                        override  fun onProviderDisabled( provider:String?) {

                        }

                    })

                val localNetworkLocation=  locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                if (localNetworkLocation!=null)locationNetworkMap=localNetworkLocation

            }

            if (locationGPSMap !=null && locationNetworkMap!=null ){
                if(locationGPSMap!!.accuracy<locationNetworkMap!!.accuracy)
                {
                    strPrecisionMap=locationGPSMap!!.accuracy.roundToInt().toString()+" m"
                    strMethodeMap="GPS "

                    locationBestMap=locationGPSMap

                }else{
                    strPrecisionMap=locationNetworkMap!!.accuracy.roundToInt().toString()+" m"
                    strMethodeMap="Réseau "

                    locationBestMap=locationNetworkMap
                }

            }

        }else
        {
            startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
        }

    }

    private fun showDialog(title: String) {

      val txtPosition=   getView()?.findViewById(R.id.positiomap) as TextView

        if ( txtPosition.text.toString()=="Position"){

            return
        }
       val dialog = Dialog(activity)
       dialog .requestWindowFeature(Window.FEATURE_NO_TITLE)
       dialog .setCancelable(false)
       dialog .setContentView(R.layout.activity_yesno_dialog)
       val body = dialog.findViewById(R.id.tvTitle) as TextView
       body.text = title
       val yesBtn = dialog.findViewById(R.id.btn_yes) as Button
       val noBtn = dialog.findViewById(R.id.btn_no) as TextView
       yesBtn.setOnClickListener {

           deleteMarker()

           dialog .dismiss()
       }
       noBtn.setOnClickListener { dialog .dismiss() }
       dialog .show()

   }

    private fun deleteMarker() {
        val dbHandler = ObjectBD(mMapContext!!.objContext!!, null, null, 3)

        val posResult:ObjectPosition ?= dbHandler.findPosition(strCurrentLatitude!!, strCurrentLongitude!!)
        val idPosition:Int
        val txtInfoPosition=   getView()?.findViewById(R.id.infopositiomap) as TextView
        val txtPosition=   getView()?.findViewById(R.id.positiomap) as TextView
        val editResult=   getView()?.findViewById(R.id.editTextResultWifi) as EditText

        val imgDeleteMarker=   getView()?.findViewById(R.id.imgDeleteMarker) as ImageButton
        val imgCopyWifi=   getView()?.findViewById(R.id.imageCopyWifi) as ImageButton

        if (posResult!=null) {
            idPosition=posResult.id
            dbHandler.deleteWifiByPositionId(idPosition)
            dbHandler.deletePositionById(idPosition)
            txtPosition.setText("Position")
            editResult.setText("")
            txtInfoPosition.setText("")
            imgDeleteMarker.visibility = View.INVISIBLE
            imgCopyWifi.visibility = View.INVISIBLE

            currentMarker!!.remove()

        }

    }

}
