package com.boolrun.scannet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.StrictMode
import android.util.Log
import android.view.Gravity
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModel
import com.google.android.material.bottomnavigation.BottomNavigationView

class asyncRunning {
    var bValue: Boolean= false

        get() = field


        set(value) {
            field = value
        }
}


class MainViewModel : ViewModel() {
    internal var lastActiveFragmentTag: String? = null
}

class MainActivity : AppCompatActivity()  {

    private var receiver: BroadcastReceiver? = null

    companion object {

        const val PARAM_NAVIGATION_ID = "navigation_id"

        fun newInstance(context: Context, navigationId: Int) =  Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra(PARAM_NAVIGATION_ID, navigationId)
        }

    }

    private lateinit var textMessage: TextView
    protected var textAdress: String =""
    private var internet: String =""


    private val onNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->

         loadFragment(item.itemId)
        true

    }

    private lateinit var viewModel: MainViewModel

    private val SPLASH_TIME_OUT = 3000L


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        viewModel= MainViewModel()

       val navView: BottomNavigationView = findViewById(R.id.nav_view)

        val topNavView: Toolbar = findViewById(R.id.mtoolbar)

        topNavView.title="test"

       navView.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener)

       val navigationId = intent.getIntExtra(PARAM_NAVIGATION_ID, R.id.navigation_tcpip)
       navView.selectedItemId = navigationId


      val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        val toolbar = findViewById(R.id.mtoolbar) as Toolbar
        toolbar.isVisible=true
        setSupportActionBar(toolbar)
        MyApplication.pubTb.objTb =toolbar
        toolbar?.title = "Statut"
        toolbar?.subtitle = "Statut"
        toolbar?.navigationIcon =   ContextCompat.getDrawable(this,R.drawable.icon_info)

            toolbar?.setNavigationOnClickListener {

                if (MyApplication.asyncRunning.bValue==true){
                    showMessage(getString(R.string.info_scan_actif))
                }else{
                    MyApplication.strIPAdr1.strAdr1="0"
                    val frgStatus=FragmentMenuInfo()
                    val fragmentManager = supportFragmentManager
                    val fragmentTransaction=  fragmentManager.beginTransaction()

                    if (viewModel.lastActiveFragmentTag != null) {

                        val lastFragment = fragmentManager.findFragmentByTag(viewModel.lastActiveFragmentTag)


                        if (lastFragment != null)
                            fragmentTransaction.hide(lastFragment)
                    }
                    fragmentTransaction.replace(R.id.fragmentContainer,frgStatus)
                    fragmentTransaction.isAddToBackStackAllowed()
                    fragmentTransaction.commit()

                }

        }

    }

    public fun showMessage(strMessage: String) {
        val toast_obj= Toast.makeText(this,strMessage, Toast.LENGTH_SHORT)
        toast_obj.setGravity(Gravity.CENTER, 0, 225)
        toast_obj.show()
    }


    public fun loadFragment(itemId: Int) {
        val tag = itemId.toString()

        var fragment = supportFragmentManager.findFragmentByTag(tag) ?: when (itemId) {
            R.id.navigation_tcpip -> {
                MyApplication.strIPAdr1.strAdr1="0"

                FragmentTcpIp.newInstance()
            }
            R.id.navigation_wifi -> {

                FragmentWiFi.newInstance()
            }
            R.id.navigation_bluetooth -> {


                FragmentBlueTooth.newInstance()
            }
            R.id.navigation_dns -> {
                MyApplication.strIPAdr1.strAdr1=""

                FragmentDNS.newInstance()
            }


            else -> {
                null
            }
        }

                if (fragment != null) {
                    val transaction = supportFragmentManager.beginTransaction()

                    if (viewModel.lastActiveFragmentTag != null) {
                        val lastFragment = supportFragmentManager.findFragmentByTag(viewModel.lastActiveFragmentTag)
                        if (lastFragment != null)
                            transaction.hide(lastFragment)
                    }

                    if (!fragment.isAdded) {
                        transaction.add(R.id.fragmentContainer, fragment, tag)
                    }
                    else {
                        transaction.show(fragment)
                    }

                    transaction.commit()
                    viewModel.lastActiveFragmentTag = tag
                }
    }


}
