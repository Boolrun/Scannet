package com.boolrun.scannet

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.*
import android.widget.*

import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import androidx.fragment.app.Fragment
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.channels.FileChannel
import java.text.SimpleDateFormat
import java.util.*

class mConfigActivity {
    var objActivity: Activity?=null
}

class FragmentConfig : Fragment() {

private val mConfigActivity=mConfigActivity()

    companion object {


        @JvmStatic
        fun newInstance() =
            FragmentConfig().apply {
                arguments = Bundle().apply {

                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        super.onCreate(savedInstanceState)
        inflater.context

        mConfigActivity.objActivity=this.activity

            if (ActivityCompat.checkSelfPermission(inflater.context, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission( inflater.context,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            val permission:String = "android.permission.WRITE_EXTERNAL_STORAGE"
            val permission_array = arrayOf( permission)
            ActivityCompat.requestPermissions(mConfigActivity!!.objActivity!!, permission_array, 0)

        val direct =
            File(Environment.getExternalStorageDirectory().toString() + "/BoolrunBackup")
        if (!direct.exists()) {
            if (direct.mkdir()) {

            }
        }
        }

        val dbHandler = ObjectBDSetting(inflater.context, null, null, 1)
        val setting_iptime= dbHandler.getSettingValue("iptime")
        val setting_maxaccu= dbHandler.getSettingValue("maxaccu")
        val setting_autowifisave= dbHandler.getSettingValue("autowifisave")
        val setting_displaymode= dbHandler.getSettingValue("displaymode")
        val setting_wifitime= dbHandler.getSettingValue("wifitime")
        val setting_tcpfav= dbHandler.getSettingValue("tcpfavori")
        val setting_udpfav= dbHandler.getSettingValue("udpfavori")

        val view: View = inflater.inflate(R.layout.activity_config, container, false)

        var editTCPFav = view.findViewById(R.id.edittcpfavori) as EditText
        var editUDPFav = view.findViewById(R.id.editudpfavori) as EditText

        var editPrecisionMax = view.findViewById(R.id.editmaxprecision) as EditText
        var editIpTempsReponse = view.findViewById(R.id.editTempsParDefaut) as EditText
        var editWiFiTempsReponse = view.findViewById(R.id.editTempsParDefautWiFi) as EditText
        var chkAutoSave = view.findViewById(R.id.chkAutoSaveWifiScan) as CheckBox
        var toggleDisplay = view.findViewById(R.id.toggleButtonDisplay) as ToggleButton
        editPrecisionMax.isEnabled=false

        editIpTempsReponse.setText(setting_iptime)
        editWiFiTempsReponse.setText(setting_wifitime)

        editTCPFav.setText(setting_tcpfav)
        editUDPFav.setText(setting_udpfav)


        if(setting_autowifisave=="1")
        {
            chkAutoSave.isChecked=true
        }else{
            chkAutoSave.isChecked=false
        }

        if(setting_displaymode=="bn"){
            toggleDisplay.isChecked=true
        }else{
            toggleDisplay.isChecked=false
        }

        val button_save_config = view.findViewById(R.id.cmdSaveConfig) as Button

        toggleDisplay.setOnClickListener() {

            ButtonSaveDisplaySetting()
        }

        button_save_config.setOnClickListener() {

            ButtonSaveSetting()
        }

        val spinner = view.findViewById(R.id.spinnerdmaxprecision) as Spinner
        val list_values : Array<String> = arrayOf("55","50","45","40","35","30", "25", "20", "15", "10", "8", "5")
        if (spinner != null) {


            val adapter = ArrayAdapter(inflater.context,  android.R.layout.simple_spinner_item, list_values)
            spinner.adapter = adapter
        }

        spinner.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>,
                                        view: View, position: Int, id: Long) {
                    editPrecisionMax.setText(list_values.get(position))

        }

            override fun onNothingSelected(parent: AdapterView<*>) {   editPrecisionMax.setText(setting_maxaccu)
                        }
        }

        for (x in 0..list_values.size-1){
            if (list_values.get(x)==setting_maxaccu){
                spinner.setSelection(x)
                editPrecisionMax.setText(setting_maxaccu)
            }
        }

        val btn_click_resetdata= view.findViewById(R.id.cmdResetData) as Button
        btn_click_resetdata.setOnClickListener(ButtonResetDataClick())

        val btn_click_exportdata= view.findViewById(R.id.cmdExportData) as Button
        btn_click_resetdata.setOnClickListener(ButtonResetDataClick())

        btn_click_exportdata.setOnClickListener() {
            ButtonExportDataClicked()
        }

        val btn_click_importdata= view.findViewById(R.id.cmdImportData) as Button
        btn_click_importdata.setOnClickListener() {
            ButtonImportDataClicked()
        }

        return view

        }

    private fun  ButtonSaveSetting() {

        var editTCPFav = view!!.findViewById(R.id.edittcpfavori) as EditText
        var editUDPFav = view!!.findViewById(R.id.editudpfavori) as EditText
        val editPrecisionMax = view!!.findViewById(R.id.editmaxprecision) as EditText
        val editIpTempsReponse = view!!.findViewById(R.id.editTempsParDefaut) as EditText
        val editWiFiTempsReponse = view!!.findViewById(R.id.editTempsParDefautWiFi) as EditText
        val chkAutoSave = view!!.findViewById(R.id.chkAutoSaveWifiScan) as CheckBox

        if(editIpTempsReponse.text.isNullOrEmpty()){
            showMessage(getString(R.string.demande_temps))
            return
        }

        if(editWiFiTempsReponse.text.isNullOrEmpty()){
            showMessage(getString(R.string.demande_temps))
            return
        }



        val setting_wifitime:String= editWiFiTempsReponse.text.toString()
        val setting_iptime:String= editIpTempsReponse.text.toString()
        val setting_maxaccu:String= editPrecisionMax.text.toString()
        val setting_tcpfav= editTCPFav.text.toString()
        val setting_udpfav=  editUDPFav.text.toString()


        var strsAdresseFavori =  setting_tcpfav
        var arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()

        for (x in 0..arrayAdresseFavori.size-1){
            if (arrayAdresseFavori[x].toInt() <0 || arrayAdresseFavori[x].toInt()>65535){
                showMessage(getString(R.string.borne_port))
                return
            }
        }

       strsAdresseFavori =  setting_udpfav
        arrayAdresseFavori=strsAdresseFavori.split(":").toTypedArray()

        for (x in 0..arrayAdresseFavori.size-1){
            if (arrayAdresseFavori[x].toInt() <0 || arrayAdresseFavori[x].toInt()>65535){
                showMessage(getString(R.string.borne_port))
                return
            }
        }

        val dbHandler = ObjectBDSetting(view!!.context!!, null, null, 1)
        dbHandler.updateSettingValue("tcpfavori",  setting_tcpfav)
        dbHandler.updateSettingValue("udpfavori", setting_udpfav)
        dbHandler.updateSettingValue("wifitime",  setting_wifitime)
        dbHandler.updateSettingValue("iptime", setting_iptime)
        dbHandler.updateSettingValue("maxaccu",  setting_maxaccu)

        if (chkAutoSave.isChecked){
            MyApplication.strAutoScan.strValue= "1"
            dbHandler.updateSettingValue("autowifisave", "1")
        }else{
            MyApplication.strAutoScan.strValue= "0"
            dbHandler.updateSettingValue("autowifisave",  "0")
        }

        MyApplication.strUDPFavoris.strValue=setting_udpfav
        MyApplication.strTCPFavoris.strValue=setting_tcpfav
        MyApplication.strTempsDefautWiFi.strValue=setting_wifitime
        MyApplication.strTempsDefaut.strValue= setting_iptime
        MyApplication.strMaxPrecision.strValue=setting_maxaccu
        dbHandler.close()
        showMessage(getString(R.string.message_saved))

    }

    private fun  ButtonSaveDisplaySetting() {

        var toggleDisplay = view!!.findViewById(R.id.toggleButtonDisplay) as ToggleButton

        val dbHandler = ObjectBDSetting(view!!.context!!, null, null, 1)

        if (toggleDisplay.isChecked){
            MyApplication.strDisplayMode.strValue= "bn"
            dbHandler.updateSettingValue("displaymode", "bn")
        }else {
            MyApplication.strDisplayMode.strValue= "nb"
            dbHandler.updateSettingValue("displaymode", "nb")
        }

        dbHandler.close()
        val textcritereRecherche=this.view!!.findViewById(R.id.critereRecherche) as TextView

        if (MyApplication.strDisplayMode.strValue=="bn"){
            this!!.view!!.setBackgroundColor(ContextCompat.getColor(this!!.view!!.context, R.color.colorText))
            MyApplication.pubTb.objTb!!.setBackgroundColor(ContextCompat.getColor(this!!.view!!.context, R.color.colorText))
            textcritereRecherche.setTextColor(ContextCompat.getColor(this!!.view!!.context, R.color.colorNoir))

        }else{
            this!!.view!!.setBackgroundColor(ContextCompat.getColor(this!!.view!!.context, R.color.colorNoir))
            MyApplication.pubTb.objTb!!.setBackgroundColor(ContextCompat.getColor(this!!.view!!.context, R.color.colorNoir))
            textcritereRecherche.setTextColor(ContextCompat.getColor(this!!.view!!.context, R.color.colorText))
        }

    }

    private fun ButtonImportDataClicked() {

        showDialog(getString(R.string.question_importer_position),"import")

    }

    private fun ButtonExportDataClicked() {

        this.exportDB()

    }

    private fun ButtonResetDataClicked() {
        showDialog(getString(R.string.question_supprimer_toutes_position),"deleteall")
    }

    fun showMessage(strMessage: String) {
        val toast_obj= Toast.makeText(this.activity,strMessage, Toast.LENGTH_SHORT)
        toast_obj.setGravity(Gravity.TOP, 0, 120)
        toast_obj.show()
    }

    internal inner class ButtonResetDataClick : View.OnClickListener {

        override fun onClick(v: View) {

            ButtonResetDataClicked()
        }
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        activity?.setTitle("")

    }


    private fun importDB() {

        try {
            val sd: File = Environment.getExternalStorageDirectory()
            val data: File = Environment.getDataDirectory()
            if (sd.canWrite()) {
                val currentDBPath = ("//data//" + "com.boolrun.scannet"
                        + "//databases//" + "positionDBLite.db")
                val backupDBPath = "/BoolrunBackup/positionDBLite.db"

                val backupDB = File(data, currentDBPath)
                val currentDB = File(sd, backupDBPath)

                val src: FileChannel = FileInputStream(currentDB).getChannel()
                val dst: FileChannel = FileOutputStream(backupDB).getChannel()
                dst.transferFrom(src, 0, src.size())
                src.close()
                dst.close()

            }
        } catch (e: Exception) {


        }
    }


    private fun exportDB() {

        try {
            val sd: File = Environment.getExternalStorageDirectory()
            val data: File = Environment.getDataDirectory()


            val pattern = "yyyy-MM-dd hhmmss"
            val simpleDateFormat = SimpleDateFormat(pattern)
            val date = simpleDateFormat.format(Date())

            if (sd.canWrite()) {
                val currentDBPath = ("//data//" + "com.boolrun.scannet"
                        + "//databases//" + "positionDBLite.db")
                val backupDBPath = "/BoolrunBackup/positionDBLite.db"
                val backupDBPath_date = "/BoolrunBackup/positionDBLite_"+ date+".db"

                val direct =
                    File(Environment.getExternalStorageDirectory().toString() + "/BoolrunBackup")
                if (!direct.exists()) {
                    if (direct.mkdir()) {

                    }else{
                        showMessage("Unable to create directory")
                    }
                }else{

                }



                val currentDB = File(data, currentDBPath)
                val backupDB = File(sd, backupDBPath)
                val backupDBDate = File(sd, backupDBPath_date)

                val src: FileChannel = FileInputStream(currentDB).getChannel()
                val dst: FileChannel = FileOutputStream(backupDB).getChannel()

                val src_date: FileChannel = FileInputStream(currentDB).getChannel()
                val dst_date: FileChannel = FileOutputStream(backupDBDate).getChannel()

                dst.transferFrom(src, 0, src.size())
                dst_date.transferFrom(src_date, 0, src.size())

                src.close()
                dst.close()

                src_date.close()
                dst_date.close()

                showMessage(getString(R.string.message_export) +"\n"+backupDB.toString())

            }else{
                showMessage("Cant write file")
            }
        } catch (e: Exception) {
            showMessage("Error"+ e.message)

        }
    }

    private fun deleteAllData(){
        val dbHandler = ObjectBD(context!!, null, null, 3)
        dbHandler.deleteallWifi()
        dbHandler.deleteallPosition()
        showMessage(getString(R.string.info_data_deleted))
    }

    private fun showDialog(title: String,action:String) {

        val dialog = Dialog(activity)
        dialog .requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog .setCancelable(false)
        dialog .setContentView(R.layout.activity_yesno_dialog)
        val body = dialog.findViewById(R.id.tvTitle) as TextView
        body.text = title
        val yesBtn = dialog.findViewById(R.id.btn_yes) as Button
        val noBtn = dialog.findViewById(R.id.btn_no) as TextView
        yesBtn.setOnClickListener {

            if (action=="deleteall"){
                deleteAllData()
            }
            if (action=="import"){
                importDB()
                showMessage(getString(R.string.message_import))
            }

            dialog .dismiss()
        }
        noBtn.setOnClickListener { dialog .dismiss() }
        dialog .show()

    }

}






