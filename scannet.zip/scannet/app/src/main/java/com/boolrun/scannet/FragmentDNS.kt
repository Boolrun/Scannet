package com.boolrun.scannet

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModel
import com.google.android.material.bottomnavigation.BottomNavigationView
import org.json.JSONObject
import org.json.JSONArray
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.lang.ref.WeakReference
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.net.UnknownHostException
import org.json.JSONTokener

class Response(json: String?) : JSONObject(json) {
    val type: String? = this.optString("type")
    val data = this.optJSONArray("data")
        ?.let { 0.until(it.length()).map { i -> it.optJSONObject(i) } }
        ?.map { Foo(it.toString()) }
}

class Foo(json: String) : JSONObject(json) {
    val id = this.optInt("id")
    val title: String? = this.optString("title")
}

class MViewModel : ViewModel() {
    internal var lastActiveFragmentTag: String? = null
}
class strDNSTexte {
    var strTexte: String = ""


        get() = field


        set(value) {
            field = value
        }
}

class FragmentDNS : Fragment() {

    companion object {

        val strDNSTexte=strDNSTexte()

        class DNSTask internal constructor(context:FragmentDNS) : AsyncTask<String, String, String?>() {
            private val activityReference: WeakReference<FragmentDNS> = WeakReference(context)
            override fun doInBackground(vararg adrIP: String): String {
                return try {
                    var result = ""
                    val url = URL("https://rdap.arin.net/bootstrap/ip/"+MyApplication.strIPAdr1.strAdr1)
                    val httpURLConnection = url.openConnection() as HttpURLConnection


                    httpURLConnection.readTimeout = 8000
                    httpURLConnection.connectTimeout = 8000
                    httpURLConnection.doOutput = true
                    httpURLConnection.requestMethod="GET"

                    httpURLConnection.connect()
                    val responseCode: Int = httpURLConnection.responseCode

                    if (responseCode == 200) {
                        val inStream: InputStream = httpURLConnection.inputStream
                        val isReader = InputStreamReader(inStream)
                        val bReader = BufferedReader(isReader)
                        var tempStr: String?
                        try {
                           while (true) {
                           tempStr = bReader.readLine()
                           if (tempStr == null) {
                               break
                           }
                                result += tempStr
                             }
                        } catch (Ex: Exception) {
                            Log.e("Erreur conn", "Error in convertToString " + Ex.printStackTrace())
                            }
                        }


                    return result
            }
             catch (e: IOException) {

                e.message.toString()
            }
            }

            override fun onCancelled(result: String?) {

            }

            override fun onPostExecute(result: String?) {

             //   super.onPostExecute(result)

                val activity =  activityReference.get()
                if (activity == null) {return }
                if (activity.context == null) {return }

         /*    try{
                 val txtResultat:EditText=  activity.view!!.findViewById(R.id.editTextResultDNS)  as EditText
                } catch (e: IOException) { return   }*/

                var EditText:String=""
                EditText=  strDNSTexte.strTexte

                if (result.isNullOrEmpty() || result.indexOf("nable",0)>0) {
                    Thread.sleep(1000)
                    val txtResultat:EditText=  activity.view!!.findViewById(R.id.editTextResultDNS)  as EditText
                    txtResultat.setText(EditText +"\n"+activity.getString(R.string.erreur_reseau))
                    return
                 }
                else
                {

                    var strGroupEntitie1:String=""
                    var strGroupEntitie2:String=""

                    val foos1 = Response(result)
                    val strNom:String=foos1.getString("name")
                    val strType:String=foos1.getString("type")
                    val strStartAdr:String=foos1.getString("startAddress")
                    val strEndAdr:String=foos1.getString("endAddress")
                    val strParentHandle:String=foos1.getString("parentHandle")
                    val strEvents:String=foos1.getString("events")
                    val jArray:JSONArray
                    jArray=JSONArray(strEvents)
                    var strJEventAction1:String=""
                    var strEventDate1:String=""

                    var strJEventAction2:String=""
                    var strEventDate2:String=""

                    if (jArray.length()  >1) {
                        val foosEvent1 = Response(jArray.getString(1))
                        strEventDate1=foosEvent1.getString("eventDate")
                        strJEventAction1=foosEvent1.getString("eventAction")
                    }

                    val foosEvent2 = Response(jArray.getString(0))
                    strEventDate2=foosEvent2.getString("eventDate")
                    strJEventAction2=foosEvent2.getString("eventAction")

                    val foos = Response(result)

                    var json = JSONTokener(result).nextValue()
                   /* when (json) {
                        is JSONObject -> {
                        }
                        is JSONArray -> {
                        }
                        else -> {
                        }
                    }*/

                    for(i in 0..foos.names().length()-1) {


                        if(foos.names().getString(i)=="entities"){
                            var arrayJSonEnt:JSONArray
                            arrayJSonEnt=foos.getJSONArray("entities")

                           for (j in 0..arrayJSonEnt.length()-1){

                               var objJSonEnt:JSONObject
                               objJSonEnt= arrayJSonEnt.getJSONObject(j)

                               for(k in 0.. objJSonEnt.length()-1){
                                   Log.d("JSONTypeobjJSonEnt",objJSonEnt.names().getString(k) + " "+k.toString())

                                   if(objJSonEnt.names().getString(k)=="handle"){

                                       var jsonHandle = JSONTokener(objJSonEnt.names().getString(k)).nextValue()

                                       if (jsonHandle is JSONArray){
                                           var arrayJSonhandle:JSONArray
                                           arrayJSonhandle=objJSonEnt.getJSONArray("handle")

                                           strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_handle)+ " " + objJSonEnt.getString("handle")

                                       }

                                   }

                                   if(objJSonEnt.names().getString(k)=="vcardArray"){
                                       var arrayJSonVCardArray:JSONArray
                                       arrayJSonVCardArray=objJSonEnt.getJSONArray("vcardArray")

                                       for(l in 0.. arrayJSonVCardArray.length()-1){

                                           var jsonVCAC = JSONTokener(arrayJSonVCardArray.get(l).toString()).nextValue()
                                           when (jsonVCAC) {
                                               is JSONObject -> {

                                               }
                                               is JSONArray -> {

                                                   var arrayJSonVCAC:JSONArray
                                                   arrayJSonVCAC= arrayJSonVCardArray.getJSONArray(l)
                                                   for(m in 0..arrayJSonVCAC.length()-1){

                                                       var jsonVCACSub = JSONTokener(arrayJSonVCAC.getString(m).toString()).nextValue()
                                                       when (jsonVCACSub) {
                                                           is JSONObject -> {
                                                           }
                                                           is JSONArray -> {

                                                               if (m==0){

                                                               }
                                                               if (m==1){
                                                                   var arrayTemp:JSONArray
                                                                   arrayTemp= JSONArray(arrayJSonVCAC.getString(m))
                                                                   var strText:String
                                                                   strText= arrayTemp.getString(3)

                                                                   strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_org)+ " " +strText

                                                               }
                                                               if (m==2){
                                                                   var arrayTemp:JSONArray
                                                                   arrayTemp= JSONArray(arrayJSonVCAC.getString(m))
                                                                   var strAdresseTemp:String
                                                                   strAdresseTemp= arrayTemp.getString(1)
                                                                   val foosAdr = Response(strAdresseTemp)

                                                                   if(foosAdr.has("label")){
                                                                       strAdresseTemp=foosAdr.getString("label")

                                                                       strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_adresse)+ "\n" +strAdresseTemp

                                                                   }

                                                               }
                                                               if (m==3){

                                                               }

                                                           }
                                                           else -> {
                                                           }
                                                       }


                                                   }

                                               }
                                               else -> {

                                               }
                                           }

                                       }

                                   }

                                   if(objJSonEnt.names().getString(k)=="roles"){
                                       var arrayJSonroles:JSONArray
                                       arrayJSonroles=objJSonEnt.getJSONArray("roles")

                                   }

                                   if(objJSonEnt.names().getString(k)=="remarks"){
                                       var arrayJSonremarks:JSONArray
                                       arrayJSonremarks=objJSonEnt.getJSONArray("remarks")

                                   }

                                   if(objJSonEnt.names().getString(k)=="links"){
                                       var arrayJSonlinks:JSONArray
                                       arrayJSonlinks=objJSonEnt.getJSONArray("links")

                                   }

                                   if(objJSonEnt.names().getString(k)=="events"){
                                       var arrayJSonEvent:JSONArray
                                       arrayJSonEvent=objJSonEnt.getJSONArray("events")

                                       var jsonEvents = JSONTokener(arrayJSonEvent.toString()).nextValue()

                                       when (jsonEvents) {
                                           is JSONObject -> {
                                           }
                                           is JSONArray -> {

                                               var strTempEvent1:String
                                               var strTempEvent2:String

                                               var strTypeActionTemp1:String
                                               var strTypeActionTemp2:String
                                               var strDateActionTemp1:String
                                               var strDateActionTemp2:String

                                               strTempEvent1= arrayJSonEvent.getString(0)
                                               strTempEvent2= arrayJSonEvent.getString(1)

                                               val foosEvent1 = Response( strTempEvent2)
                                               val foosEvent2 = Response( strTempEvent1)

                                               strTypeActionTemp1=foosEvent1.getString("eventAction")
                                               strTypeActionTemp2=foosEvent2.getString("eventAction")
                                               strDateActionTemp1=foosEvent1.getString("eventDate")
                                               strDateActionTemp2=foosEvent2.getString("eventDate")

                                               strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_action)+ " " + strTypeActionTemp1
                                               strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_date)+ " " +  strDateActionTemp1
                                               strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_action)+ " " +strTypeActionTemp2
                                               strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_date)+ " " +  strDateActionTemp2

                                           }
                                           else -> {
                                           }
                                       }

                                   }

                                   if(objJSonEnt.names().getString(k)=="entities"){
                                       var arrayJSonEntities:JSONArray
                                       arrayJSonEntities=objJSonEnt.getJSONArray("entities")


                                       var jsonsubEntities = JSONTokener(arrayJSonEntities.toString()).nextValue()

                                       when (jsonsubEntities) {
                                           is JSONObject -> {
                                           }
                                           is JSONArray -> {

                                               var arrayTemp:JSONArray
                                               arrayTemp= JSONArray(arrayJSonEntities.toString())

                                               var strTemp1:String
                                               var strTemp2:String
                                               strTemp1=arrayTemp.getString(0)

                                               var jsonTemp1 = JSONTokener(strTemp1).nextValue()
                                               when (jsonTemp1) {
                                                   is JSONObject -> {
                                                       val foosSubEntities = Response(strTemp1)

                                                       for (m in 0..foosSubEntities.length()-1){

                                                           val strName:String=foosSubEntities.names().get(m).toString()
                                                           var strTemp:String=""

                                                           if (strName=="handle"){
                                                                strTemp=foosSubEntities.getString("handle")
                                                                var strHandle=strTemp
                                                               strGroupEntitie1=strGroupEntitie1+"\n\n"+activity!!.getString(R.string.whois_handle)+ " " +strHandle

                                                           }
                                                           if (strName=="vcardArray"){
                                                                strTemp=foosSubEntities.getString("vcardArray")

                                                               var arrayJSonVCardArray:JSONArray
                                                               arrayJSonVCardArray= JSONArray(strTemp)

                                                               for(n in 0.. arrayJSonVCardArray.length()-1){
                                                                   val jsonTemp2 = JSONTokener(arrayJSonVCardArray.getString(n)).nextValue()

                                                                   when (jsonTemp2) {
                                                                       is JSONObject -> {
                                                                       }
                                                                       is JSONArray -> {

                                                                           var arrayTemp:JSONArray
                                                                           var arrayTempMain:JSONArray
                                                                           arrayTempMain= JSONArray(arrayJSonVCardArray.getString(n))

                                                                           var strText:String
                                                                           var strText1:String
                                                                           var strText2:String
                                                                           var strText3:String
                                                                           var strText4:String
                                                                           var strText5:String
                                                                           var strText6:String
                                                                           var strCourriel:String=""
                                                                           var  strTel:String=""

                                                                           strText= arrayTempMain.getString(0)
                                                                           strText1=arrayTempMain.getString(1)
                                                                           strText2= arrayTempMain.getString(2)
                                                                           strText3=arrayTempMain.getString(3)

                                                                           if (arrayTempMain.length() >4){
                                                                               strText4= arrayTempMain.getString(4)
                                                                               strText5=arrayTempMain.getString(5)
                                                                               strText6= arrayTempMain.getString(6)

                                                                               arrayTemp= JSONArray(strText5)
                                                                               strCourriel= arrayTemp.getString(3)
                                                                               arrayTemp= JSONArray(strText6)
                                                                               strTel= arrayTemp.getString(3)
                                                                           }

                                                                           arrayTemp= JSONArray(strText1)
                                                                           var strAdrTemp:String
                                                                           strAdrTemp= arrayTemp.getString(1)
                                                                           val foosAdr = Response(strAdrTemp)
                                                                           var strUserTemp:String=""

                                                                           if (foosAdr.has("label")){

                                                                           strAdrTemp=foosAdr.getString("label")
                                                                           arrayTemp= JSONArray(strText2)
                                                                           strUserTemp= arrayTemp.getString(3)

                                                                           }
                                                                           strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_type_contact)+ " " + strUserTemp
                                                                           strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_adresse)+ "\n" + strAdrTemp
                                                                           strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_courriel)+ " " + strCourriel
                                                                           strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_telephone)+ " " + strTel

                                                                       }
                                                                       else -> {

                                                                       }
                                                                   }
                                                               }

                                                           }
                                                           if (strName=="remarks"){
                                                               val arrayJSonremarks:JSONArray

                                                               if (objJSonEnt.has("remarks")){

                                                               arrayJSonremarks=objJSonEnt.getJSONArray("remarks")

                                                               for(n in 0..0 ){

                                                                 strTemp=arrayJSonremarks.getString(n)

                                                                   var jsonTemp = JSONTokener(strTemp).nextValue()
                                                                   when (jsonTemp) {
                                                                       is JSONObject -> {

                                                                           val foosRemarks = Response(strTemp)

                                                                           for(p in 0..0){

                                                                               var strTempTitle:String
                                                                               var strTempDesc:String
                                                                               var strTempDesc1:String
                                                                               var strTempDesc2:String
                                                                               var strTempDesc3:String
                                                                               var strTempDesc4:String
                                                                               var strTempDesc5:String

                                                                                var arrayTempRemark:JSONArray

                                                                               strTempTitle=foosRemarks.getString("title")
                                                                               strTempDesc=foosRemarks.getString("description")
                                                                               arrayTempRemark= JSONArray(strTempDesc)
                                                                               strTempDesc1= arrayTempRemark.getString(0)
                                                                               strTempDesc2= arrayTempRemark.getString(1)
                                                                               strTempDesc3= arrayTempRemark.getString(2)
                                                                               strTempDesc4= arrayTempRemark.getString(3)
                                                                               strTempDesc5= arrayTempRemark.getString(4)

                                                                               strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_remarque)+ " " + strTempTitle+ "\n"+  strTempDesc1+   strTempDesc2+  strTempDesc3+  strTempDesc4+  strTempDesc5

                                                                           }
                                                                       }
                                                                       is JSONArray -> {
                                                                       }
                                                                       else -> {
                                                                       }
                                                                   }
                                                               }

                                                               }

                                                           }
                                                           if (strName=="links"){
                                                               strTemp=foosSubEntities.getString("links")
                                                               val arrayJSonlinks:JSONArray

                                                               arrayJSonlinks= JSONArray(strTemp)

                                                           }
                                                           if (strName=="events"){
                                                               strTemp=foosSubEntities.getString("events")

                                                               val arrayJSonEvent=JSONArray(strTemp)

                                                               var strTempEvent1:String
                                                               var strTempEvent2:String

                                                               var strTypeActionTemp1:String
                                                               var strTypeActionTemp2:String
                                                               var strDateActionTemp1:String
                                                               var strDateActionTemp2:String

                                                               strTempEvent1= arrayJSonEvent.getString(0)
                                                               strTempEvent2= arrayJSonEvent.getString(1)

                                                               val foosEvent1 = Response( strTempEvent2)
                                                               val foosEvent2 = Response( strTempEvent1)

                                                               strTypeActionTemp1=foosEvent1.getString("eventAction")
                                                               strTypeActionTemp2=foosEvent2.getString("eventAction")
                                                               strDateActionTemp1=foosEvent1.getString("eventDate")
                                                               strDateActionTemp2=foosEvent2.getString("eventDate")

                                                               strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_action)+ " " + strTypeActionTemp1
                                                               strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_date)+ " " +strDateActionTemp1
                                                               strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_action)+ " " + strTypeActionTemp2
                                                               strGroupEntitie1=strGroupEntitie1+"\n"+activity!!.getString(R.string.whois_date)+ " " +strDateActionTemp2

                                                           }

                                                       }

                                                   }
                                                   is JSONArray -> {
                                                   }
                                                   else -> {
                                                   }
                                               }

                                               if (arrayTemp.length()>1){
                                                   strTemp2=arrayTemp.getString(1)

                                                   var jsonTemp2 = JSONTokener(strTemp2).nextValue()
                                                   when (jsonTemp2) {
                                                       is JSONObject -> {
                                                           val foosSubEntities = Response(strTemp2)

                                                           for (m in 0..foosSubEntities.length()-1){

                                                               val strName:String=foosSubEntities.names().get(m).toString()
                                                               var strTemp:String=""

                                                               if (strName=="handle"){
                                                                   strTemp=foosSubEntities.getString("handle")
                                                                   var strHandle=strTemp

                                                                   strGroupEntitie2=strGroupEntitie2+activity!!.getString(R.string.whois_handle)+ " " + strHandle

                                                               }
                                                               if (strName=="vcardArray"){
                                                                   strTemp=foosSubEntities.getString("vcardArray")

                                                                   var arrayJSonVCardArray:JSONArray
                                                                   arrayJSonVCardArray= JSONArray(strTemp)

                                                                   for(n in 0.. arrayJSonVCardArray.length()-1){
                                                                       val jsonTemp2 = JSONTokener(arrayJSonVCardArray.getString(n)).nextValue()

                                                                       when (jsonTemp2) {
                                                                           is JSONObject -> {
                                                                           }
                                                                           is JSONArray -> {

                                                                               var arrayTemp:JSONArray
                                                                               arrayTemp= JSONArray(arrayJSonVCardArray.getString(n))

                                                                               var strText:String
                                                                               var strText1:String
                                                                               var strText2:String
                                                                               var strText3:String
                                                                               var strText4:String
                                                                               var strText5:String
                                                                               var strText6:String

                                                                               strText= arrayTemp.getString(0)
                                                                               strText1= arrayTemp.getString(1)
                                                                               strText2= arrayTemp.getString(2)
                                                                               strText3= arrayTemp.getString(3)
                                                                               strText4= arrayTemp.getString(4)
                                                                               strText5= arrayTemp.getString(5)
                                                                               strText6= arrayTemp.getString(6)

                                                                               arrayTemp= JSONArray(strText1)
                                                                               var strAdrTemp:String
                                                                               strAdrTemp= arrayTemp.getString(1)
                                                                               val foosAdr = Response(strAdrTemp)
                                                                               strAdrTemp=foosAdr.getString("label")

                                                                               arrayTemp= JSONArray(strText2)
                                                                               var strUserTemp:String
                                                                               strUserTemp= arrayTemp.getString(3)

                                                                               arrayTemp= JSONArray(strText5)

                                                                               var strContactrTemp0000:String

                                                                               strContactrTemp0000= arrayTemp.getString(3)

                                                                               arrayTemp= JSONArray(strText6)

                                                                               var strContactrTemp4:String

                                                                               strContactrTemp4= arrayTemp.getString(3)

                                                                               strGroupEntitie2=strGroupEntitie2+"\n"+activity!!.getString(R.string.whois_type_contact)+ " " + strUserTemp
                                                                               strGroupEntitie2=strGroupEntitie2+"\n"+activity!!.getString(R.string.whois_adresse)+ "\n" + strAdrTemp
                                                                               strGroupEntitie2=strGroupEntitie2+"\n"+activity!!.getString(R.string.whois_courriel)+ " " + strContactrTemp0000
                                                                               strGroupEntitie2=strGroupEntitie2+"\n"+activity!!.getString(R.string.whois_telephone)+ " " + strContactrTemp4

                                                                           }
                                                                           else -> {

                                                                           }
                                                                       }
                                                                   }

                                                               }
                                                               if (strName=="remarks"){
                                                                   val arrayJSonremarks:JSONArray

                                                                   if (objJSonEnt.has("remarks")){

                                                                       arrayJSonremarks=objJSonEnt.getJSONArray("remarks")

                                                                       for(n in 0.. arrayJSonremarks.length()-1){

                                                                           strTemp=arrayJSonremarks.getString(n)

                                                                           var jsonTemp = JSONTokener(strTemp).nextValue()
                                                                           when (jsonTemp) {
                                                                               is JSONObject -> {

                                                                                   val foosRemarks = Response(strTemp)

                                                                                   for(p in 0..foosRemarks.length()-1){

                                                                                       var strTempTitle:String
                                                                                       var strTempDesc:String
                                                                                       var strTempDesc1:String
                                                                                       var strTempDesc2:String
                                                                                       var strTempDesc3:String
                                                                                       var strTempDesc4:String
                                                                                       var strTempDesc5:String

                                                                                       var arrayTempRemark:JSONArray

                                                                                       strTempTitle=foosRemarks.getString("title")
                                                                                       strTempDesc=foosRemarks.getString("description")
                                                                                       arrayTempRemark= JSONArray(strTempDesc)
                                                                                       strTempDesc1= arrayTempRemark.getString(0)
                                                                                       strTempDesc2= arrayTempRemark.getString(1)
                                                                                       strTempDesc3= arrayTempRemark.getString(2)
                                                                                       strTempDesc4= arrayTempRemark.getString(3)
                                                                                       strTempDesc5= arrayTempRemark.getString(4)

                                                                                       strGroupEntitie2=strGroupEntitie2+"\n"+activity!!.getString(R.string.whois_remarque)+ " " + strTempTitle+ "\n"+  strTempDesc1+   strTempDesc2+ strTempDesc3+   strTempDesc4+   strTempDesc5

                                                                                   }


                                                                               }
                                                                               is JSONArray -> {
                                                                               }
                                                                               else -> {
                                                                               }
                                                                           }
                                                                       }

                                                                   }

                                                               }
                                                               if (strName=="links"){
                                                                   strTemp=foosSubEntities.getString("links")
                                                                   val arrayJSonlinks:JSONArray

                                                                   arrayJSonlinks= JSONArray(strTemp)

                                                               }
                                                               if (strName=="events"){
                                                                   strTemp=foosSubEntities.getString("events")

                                                                   val arrayJSonEvent=JSONArray(strTemp)

                                                                   var strTempEvent1:String
                                                                   var strTempEvent2:String

                                                                   var strTypeActionTemp1:String
                                                                   var strTypeActionTemp2:String
                                                                   var strDateActionTemp1:String
                                                                   var strDateActionTemp2:String

                                                                   strTempEvent1= arrayJSonEvent.getString(0)
                                                                   strTempEvent2= arrayJSonEvent.getString(1)

                                                                   val foosEvent1 = Response( strTempEvent2)
                                                                   val foosEvent2 = Response( strTempEvent1)

                                                                   strTypeActionTemp1=foosEvent1.getString("eventAction")
                                                                   strTypeActionTemp2=foosEvent2.getString("eventAction")
                                                                   strDateActionTemp1=foosEvent1.getString("eventDate")
                                                                   strDateActionTemp2=foosEvent2.getString("eventDate")

                                                                   strGroupEntitie2=strGroupEntitie2+"\n"+activity!!.getString(R.string.whois_action)+ " " + strTypeActionTemp1
                                                                   strGroupEntitie2=strGroupEntitie2+"\n"+activity!!.getString(R.string.whois_date)+ " " +  strDateActionTemp1
                                                                   strGroupEntitie2=strGroupEntitie2+"\n"+activity!!.getString(R.string.whois_action)+ " " + strTypeActionTemp2
                                                                   strGroupEntitie2=strGroupEntitie2+"\n"+activity!!.getString(R.string.whois_date)+ " " +  strDateActionTemp2

                                                               }

                                                           }

                                                       }
                                                       is JSONArray -> {
                                                       }
                                                       else -> {
                                                       }
                                                   }

                                               }

                                           }
                                           else -> {
                                           }
                                       }

                                   }

                               }

                           }

                        }

                    }


                    if(  strGroupEntitie2.length>1){
                        strGroupEntitie1=strGroupEntitie1+ "\n\n"+ strGroupEntitie2
                    }

                    val strMessageDNS:String

                    strMessageDNS=EditText +"\nInformation RDAP (WHOIS)\n"  + activity!!.getString(R.string.whois_nom)+ " "+ strNom+"\n" +activity!!.getString(R.string.whois_action)+ " "+strType+"\n" +activity!!.getString(R.string.whois_adresse_debut)+ " "+ strStartAdr+"\n"+activity!!.getString(R.string.whois_adresse_fin)+ " "+strEndAdr+"\n"                +activity!!.getString(R.string.whois_handle_parent)+ " "+ strParentHandle+"\n" + strGroupEntitie1+"\n\n\n" +
                            "\n\n" +
                            "\n\n" +
                            "\n\n\n" +
                            "\n"

                    Thread.sleep(1000)
                    val txtResultat:EditText=  activity.view!!.findViewById(R.id.editTextResultDNS)  as EditText
                    txtResultat.setText(strMessageDNS)
                 }

        }
        }

        @JvmStatic
        fun newInstance() =
            FragmentDNS().apply {
                arguments = Bundle().apply {

                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    private lateinit var viewModel: MViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        viewModel= MViewModel()
        val view: View = inflater!!.inflate(R.layout.activity_dns, container, false)
        val btn_click_me = view.findViewById(R.id.cmdOKSearchDNS) as Button
        btn_click_me.setOnClickListener(ButtonOkClick())

        val btn_click_scanip = view.findViewById(R.id.cmdScanIP) as Button
                btn_click_scanip.setOnClickListener(ButtonScanIPClick())

        val imgViewCopyButton = view.findViewById<ImageButton>(R.id.imageCopyDNS)
        imgViewCopyButton?.setOnClickListener() {
            ButtonCopyClicked()

        }

        return view

        return inflater.inflate(R.layout.activity_dns, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        activity?.setTitle("")
        val txtAdress =   getView()?.findViewById(R.id.editAdresseDNS) as EditText

        if (MyApplication.strAdrDNS.strName.toString() =="0"  ){
            txtAdress.setText("boolrun.com")
            MyApplication.strAdrDNS.strName="boolrun.com"

        }else {
            txtAdress.setText(MyApplication.strAdrDNS.strName)

        }

        DNSSearch(false)

    }

    fun byteArrayOfInts(vararg ints: Int) = ByteArray(ints.size) { pos -> ints[pos].toByte() }

  private fun ButtonScanIPClicked() {

      var iPos:Int=0
      var resultMess:String
      if (MyApplication.asyncRunning.bValue==true){
          showMessage(getString(R.string.info_scan_actif))
          return
      }

      iPos=   MyApplication.strIPAdr1.strAdr1.indexOf(":",0,true)

    if (iPos>1){
        showMessage("IPV6 non supporté")
        return
    }

      val frgTCPIP=FragmentTcpIp()
      val fragmentManager = activity!!.supportFragmentManager
      val fragmentTransaction=  fragmentManager.beginTransaction()

      if (viewModel.lastActiveFragmentTag != null) {
          val lastFragment = fragmentManager.findFragmentByTag(viewModel.lastActiveFragmentTag)
          if (lastFragment != null)
              fragmentTransaction.hide(lastFragment)
      }

      fragmentTransaction.replace(R.id.fragmentContainer,frgTCPIP)

      fragmentTransaction.disallowAddToBackStack()

      fragmentTransaction.commit()

      val navigationView =
          activity!!.findViewById<View>(R.id.nav_view) as BottomNavigationView
      navigationView.menu.getItem(0).isChecked = true

  }

    public fun showMessage(strMessage: String) {
        val toast_obj= Toast.makeText(this.activity,strMessage, Toast.LENGTH_SHORT)
        toast_obj.setGravity(Gravity.TOP, 0, 120)
        toast_obj.show()
    }

    private fun DNSSearch(OKclicked: Boolean) {
        val txtAdress =   getView()?.findViewById(R.id.editAdresseDNS) as EditText
        val editResultDNS =   getView()?.findViewById(R.id.editTextResultDNS) as EditText

        var hostName: String = txtAdress.getText().toString()
        var strResult:String=""

        if (OKclicked==false){
            hostName=MyApplication.strAdrDNS.strName
        }

        val  hostInetAddress:InetAddress

        try {
            hostInetAddress=InetAddress.getByName(hostName)
            var strIPAdress:String = ""
            strIPAdress =hostInetAddress.hostAddress.toString()

            MyApplication.strIPAdr1.strAdr1=strIPAdress

            MyApplication.strAdrDNS.strName=hostName

            strResult=""

            strResult=strResult+  getString(R.string.canonique) +  hostInetAddress.canonicalHostName.toString()+ "\n"
            strResult=strResult+  getString(R.string.adresse_ip) + strIPAdress+ "\n"
            strResult=strResult+  "Loopback   : "+ hostInetAddress.isLoopbackAddress.toString() + "\n"
            strResult=strResult+  "Multicast   : "+ hostInetAddress.isMulticastAddress.toString() + "\n"

            editResultDNS.setText(strResult.toString())

            strDNSTexte.strTexte=strResult.toString()

            val task =DNSTask(this)
            task.execute(MyApplication.strIPAdr1.strAdr1)


        } catch (e: UnknownHostException) {
            editResultDNS.setText("\n "+getString(R.string.dns_invalide))

        }

    }

    private fun ButtonCopyClicked() {

        val editResultDNS =   getView()?.findViewById(R.id.editTextResultDNS) as EditText
        val editDNS =   getView()?.findViewById(R.id.editAdresseDNS) as EditText
        val myClipboard: ClipboardManager = activity!!.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val myClip: ClipData
        val strText:String
        val strTextDNS:String
        strTextDNS= editDNS.text.toString()
        strText=  strTextDNS + "\n"+editResultDNS.text.toString()
        myClip = ClipData.newPlainText("textDNS", strText);
        myClipboard.setPrimaryClip(myClip);

    }

    private fun ButtonOkClicked() {
        DNSSearch(true)

    }

    internal inner class ButtonScanIPClick : View.OnClickListener {

        override fun onClick(v: View) {

            ButtonScanIPClicked()
        }
    }

    internal inner class ButtonCopyText : View.OnClickListener {

        override fun onClick(v: View) {


            ButtonCopyClicked()
        }
    }

    internal inner class ButtonOkClick : View.OnClickListener {

        override fun onClick(v: View) {

            ButtonOkClicked()
        }
    }
}
