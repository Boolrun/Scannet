package com.boolrun.scannet

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class ObjectBDSetting (context: Context, name: String?,
                       factory: SQLiteDatabase.CursorFactory?, version: Int) :
    SQLiteOpenHelper(context, DATABASE_NAME,
        factory, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        val CREATE_SETTING_TABLE = ("CREATE TABLE " +
                TABLE_SETTING  + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY," +
                COLUMN_LABEL + " TEXT," +
                COLUMN_VALUE + " TEXT" +
                               ")")
        db.execSQL(CREATE_SETTING_TABLE)

    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int,
                           newVersion: Int) {

    }

    companion object {

        private val DATABASE_VERSION = 1
        private val DATABASE_NAME = "settingDBLite.db"

        val TABLE_SETTING = "setting_data"
        val COLUMN_ID = "_id"
        val COLUMN_LABEL = "setting_label"
        val COLUMN_VALUE = "setting_value"

    }

    fun addSetting(strSettingLabel:String,strSettingValue:String) {

        val values = ContentValues()
        values.put(COLUMN_LABEL, strSettingLabel)
        values.put(COLUMN_VALUE,  strSettingValue)

        val db = this.writableDatabase

        db.insert(TABLE_SETTING, null, values)
        db.close()


    }

    fun getSettingValue(setting_label:String): String {

        val query =
            "SELECT * FROM $TABLE_SETTING  WHERE $COLUMN_LABEL ='$setting_label'"

        val db = this.writableDatabase

        val cursor = db.rawQuery(query, null)

        if (cursor.count==0){
            return "0"
        }else{
            cursor.moveToFirst()
            val str_value = cursor.getString(2)

            return  str_value

        }

    }

    fun updateSettingValue(setting_label:String,setting_value:String) {

        val values = ContentValues()
        values.put(COLUMN_VALUE, setting_value)

        val db = this.writableDatabase

        db.update(TABLE_SETTING, values, "$COLUMN_LABEL ='$setting_label'",null)
        db.close()

    }

    fun resetSetting() {
        val query =
            "DELETE FROM $TABLE_SETTING  WHERE $COLUMN_ID >0"
        val db = this.writableDatabase
        db.execSQL(query)
        db.close()
    }

}