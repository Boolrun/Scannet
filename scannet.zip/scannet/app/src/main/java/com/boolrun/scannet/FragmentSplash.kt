package com.boolrun.scannet

import android.Manifest
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.security.NetworkSecurityPolicy
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.lang.ref.WeakReference
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.*
import kotlin.concurrent.thread


class strResultJSON {
    var strTexte: String = ""


        get() = field


        set(value) {
            field = value
        }
}

class FragmentSplash : AppCompatActivity() {

    private val SPLASH_TIME_OUT:Long = 3000 // 1 sec
    private lateinit var viewModel: MViewModel








    companion object {

        private fun generateSHA256(stringtoHash:String): String {
            return hashString(stringtoHash, "SHA-256")
        }

        private fun hashString(input: String, algorithm: String): String {
            return MessageDigest
                .getInstance(algorithm)
                .digest(input.toByteArray())
                .fold("", { str, it -> str + "%02x".format(it) })
        }

        val strResultJSON=strResultJSON()
        class SplashTask internal constructor(context:FragmentSplash) : AsyncTask<String, String, String?>() {
            private val activityReference: WeakReference<FragmentSplash> = WeakReference(context)
            override fun doInBackground(vararg adrIP: String): String {
                return try {
                    var result = ""
                    val url = URL("https://www.boolrun.com/hash_256.php")
                    val httpURLConnection = url.openConnection() as HttpURLConnection


                    httpURLConnection.readTimeout = 8000
                    httpURLConnection.connectTimeout = 8000
                    httpURLConnection.doOutput = true
                    httpURLConnection.requestMethod="GET"

                    httpURLConnection.connect()
                    val responseCode: Int = httpURLConnection.responseCode

                    if (responseCode == 200) {
                        val inStream: InputStream = httpURLConnection.inputStream
                        val isReader = InputStreamReader(inStream)
                        val bReader = BufferedReader(isReader)
                        var tempStr: String?
                        try {
                            while (true) {
                                tempStr = bReader.readLine()
                                if (tempStr == null) {
                                    break
                                }
                                result += tempStr
                            }
                        } catch (Ex: Exception) {
                            Log.e("Erreur conn", "Error in convertToString " + Ex.printStackTrace())
                        }
                    }


                    return result
                }
                catch (e: IOException) {

                    e.message.toString()
                }
            }

            override fun onCancelled(result: String?) {

            }

            override fun onPostExecute(result: String?) {

                val activity =  activityReference.get()
                if (activity == null) {return }

             /*   var strHash:String=""
                val jArray: JSONArray
                jArray=JSONArray(result)

                if (jArray.length()  >0) {
                    val fooHASH = Response(jArray.getString(0))
                    strHash=fooHASH.getString("id")
                }

                strResultJSON.strTexte= strHash
                strHash=generateSHA256("boolrun avec quelques epices special")
                Log.d("SHA256", strHash+" "+ strResultJSON.strTexte)

                if(strHash!=strResultJSON.strTexte){
                    ActivityCompat.finishAffinity(activity)
                    System.exit(0)
                }*/

            }

        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

       var rootView = this.layoutInflater.inflate(R.layout.activity_splash, container, false)
        if (ActivityCompat.checkSelfPermission( rootView.context, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED
            || (ActivityCompat.checkSelfPermission(rootView.context,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(rootView.context, Manifest.permission.ACCESS_COARSE_LOCATION ) != PackageManager.PERMISSION_GRANTED )
            || ActivityCompat.checkSelfPermission(rootView.context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED

        ) {

            val permission1:String = "android.permission.WRITE_EXTERNAL_STORAGE"
            val permission2:String = "android.permission.ACCESS_COARSE_LOCATION"
            val permission3:String = "android.permission.ACCESS_FINE_LOCATION"
            val permission4:String = "android.permission.READ_PHONE_STATE"
            val permission_array = arrayOf(permission1,permission2,permission3,permission4)
            ActivityCompat.requestPermissions( this, permission_array, 0)

            Thread.sleep(10000)
        }


        val task =SplashTask(this)
        task.execute("")





      /*  val objURLConn:String

        objURLConn=RequestHandler.sendGet("https://www.boolrun.com/hash_256.php")

        Log.d("SHA256", objURLConn)*/

         val dbHandler = ObjectBDSetting(rootView.context, null, null, 1)

         val setting_value_test= dbHandler.getSettingValue("iptime")

        var browserIntentPrivacy: Intent ?= null
        var browserIntentTerms: Intent ?= null
        var strLanguage:String= Locale.getDefault().getDisplayLanguage()


       if(setting_value_test=="0"){
            dbHandler.addSetting("iptime","155")
            dbHandler.addSetting("maxaccu","20")
            dbHandler.addSetting("autowifisave","1")
            dbHandler.addSetting("displaymode","bn")
            dbHandler.addSetting("wifitime","15")
            dbHandler.addSetting("legal","No")
           dbHandler.addSetting("tcpfavori","21:23:25:53:80:443:8080")
           dbHandler.addSetting("udpfavori","53:123:161:5353:1900")

      }else{
            val setting_iptime= dbHandler.getSettingValue("iptime")
            val setting_wifitime= dbHandler.getSettingValue("wifitime")
            val setting_maxaccu= dbHandler.getSettingValue("maxaccu")
            val setting_autowifisave= dbHandler.getSettingValue("autowifisave")
            val setting_displaymode= dbHandler.getSettingValue("displaymode")
           val setting_tcpfav= dbHandler.getSettingValue("tcpfavori")
           val setting_udpfav= dbHandler.getSettingValue("udpfavori")

           MyApplication.strUDPFavoris.strValue=setting_udpfav
           MyApplication.strTCPFavoris.strValue=setting_tcpfav




           if(setting_udpfav.isNullOrEmpty() || setting_udpfav=="0"){
             //  Log.d("setting_udpfav",setting_udpfav.toString())
               dbHandler.addSetting("tcpfavori","21:23:25:53:80:443:8080")
               dbHandler.updateSettingValue("tcpfavori","21:23:25:53:80:443:8080")
           }

           if(setting_tcpfav.isNullOrEmpty()|| setting_tcpfav=="0"){
               //Log.d("setting_tcpfav",setting_tcpfav.toString())
               dbHandler.addSetting("udpfavori","53:123:161:5353:1900")
               dbHandler.updateSettingValue("udpfavori","53:123:161:5353:1900")
           }

            MyApplication.strTempsDefaut.strValue= setting_iptime
            MyApplication.strMaxPrecision.strValue=setting_maxaccu
            MyApplication.strAutoScan.strValue= setting_autowifisave
            MyApplication.strDisplayMode.strValue= setting_displaymode
            MyApplication.strTempsDefautWiFi.strValue=setting_wifitime

        }

        setContentView(R.layout.activity_splash)
        val versionCode = BuildConfig.VERSION_CODE
        val versionName = BuildConfig.VERSION_NAME

        val txtVersion = this.findViewById(R.id.textversion) as TextView

        txtVersion.setText("Version " + versionName)
        Handler().postDelayed({



            startActivity(Intent(this,MainActivity::class.java))


                    finish()
        }, SPLASH_TIME_OUT)

    }

}

