package com.boolrun.scannet;

import android.widget.TextView;

public class ScanPortResultUpdateTask implements Runnable{
    private String message;
    private String backgroundMsg;

    public ScanPortResultUpdateTask(String msg){
        message = msg;
    }
    public void setBackgroundMsg(String bmsg){
        backgroundMsg = bmsg;
    }
    @Override
    public void run() {
        message=backgroundMsg;
    }
}
