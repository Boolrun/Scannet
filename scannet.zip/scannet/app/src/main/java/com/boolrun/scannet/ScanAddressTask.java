package com.boolrun.scannet;

import android.util.Log;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;


public class ScanAddressTask implements Runnable{

    ScanPortResultUpdateTask resultUpdateTask;

    public ScanAddressTask(ScanPortResultUpdateTask drUpdateTask){

        resultUpdateTask = drUpdateTask;
    }

    @Override
    public void run() {
        String msg;
        msg="";

       if(ScanAddress()){

            msg = "OK";
        }else{
            msg = "Fail";
        }

        MyApplication.Companion.getStrResultSocketMessage().setStrTextMessage(msg);

      //  Log.d("ScanAddress()",   msg );

        resultUpdateTask.setBackgroundMsg(msg);
        ScanPortManager.getScanPortManager().getMainThreadExecutor()
                .execute(resultUpdateTask);
    }

    private boolean ScanAddress(){
       try{

           InetAddress address = InetAddress.getByName(MyApplication.Companion.getStrCurrentAdressIP().getStrAdresse());

           MyApplication.Companion.getStrResultDNS().setStrAddress("");
           boolean isCo;

           isCo=address.isReachable(3/*MyApplication.Companion.getNumTempsReponse().getNumMilliseconde().intValue()*/);
           if(!isCo){
               isCo=address.isReachable(MyApplication.Companion.getNumTempsReponse().getNumMilliseconde().intValue());
           }
           return isCo;



        }catch (UnknownHostException e){


           e.printStackTrace();

            return false;}  catch (IOException e1) {

        e1.printStackTrace();
           return false;
    }

    }
}
