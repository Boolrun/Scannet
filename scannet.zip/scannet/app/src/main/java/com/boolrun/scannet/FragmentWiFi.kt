package com.boolrun.scannet

import java.math.BigDecimal
import java.math.RoundingMode
import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pManager

import android.os.AsyncTask
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.activity_wifi.*
import java.io.IOException
import java.lang.ref.WeakReference
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import android.content.IntentFilter
import android.util.Log
import androidx.core.graphics.drawable.toDrawable

class mContext {
    var objContext: Context ?=null
}

class mActivity {
    var objActivity: Activity?=null
}

class mFragment {
    var objFragment: Fragment?=null
}

class FragmentWiFi : Fragment() {

    private val intentFilter = IntentFilter()
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var manager: WifiP2pManager

    class strStatus {
        var strValue: String = "0"
    }

    class intSecond {
        var intValue: Int = 0
    }

    class intCompteScanWifi {
        var intValue: Int = 0
    }

    class boolPremier {
        var boolValue: Boolean=false
    }

    companion object {


        private lateinit var viewModel: MViewModel
        private val mListView: ListView? = null
        val strStatus= strStatus()
        val intSecond= intSecond()
        val boolPremier= boolPremier()
        val intCompteScanWifi=intCompteScanWifi()
        val mContext= mContext()
        val mActivity= mActivity()
        val mFragment=mFragment()
        lateinit var locationManager:LocationManager
        private var hasGPS=false
        private var hasNetwork=false
        private  var locationGPS:Location ?=null
        private  var locationNetwork:Location?=null
        private  var locationBest:Location ?=null
        private  var strMethode:String ?=""
        private  var strPrecision:String ?=""
        private var idWifi: Int = 0
        private var strSSID: String? = null
        private var strBSSID: String? = null
        private var strFrequence: String? = null
        private var strLevel: String? = null
        private var strSecurite: String? = null
        private var strCanal: String? = null
        private var strDistance: String? = null
        private var dateScanWifi: String?=null





        class WifiLogicTask internal constructor(context: FragmentWiFi) : AsyncTask<String, String, String?>() {
            private val activityReference: WeakReference<FragmentWiFi> = WeakReference(context)
            override fun doInBackground(vararg statutBouton: String): String {
                return try {

                        if(strStatus.strValue=="Stop") {

                            cancel(true)
                            return ""
                        }

                        var lSecond:Long


                        lSecond= intSecond.intValue.toLong()*1200

                        if (!boolPremier.boolValue){
                            Thread.sleep(lSecond)
                        }else
                        {
                            Thread.sleep(100)
                        }
                        strStatus.strValue

                } catch (e: IOException) {


                    e.message.toString()
                }
            }

            override fun onCancelled(result: String?) {

            }

            fun showMessage(strMessage: String) {
                val toast_obj= Toast.makeText(mActivity.objActivity,strMessage, Toast.LENGTH_SHORT)
                toast_obj.setGravity(Gravity.CENTER, 0, 225)
                toast_obj.show()
            }

            override fun onPostExecute(result: String?) {

                val activity =  mActivity.objActivity
                if (activity == null) {

                    return
                }

                var strResult:String=""

                if (   mContext.objContext == null) {

                    return
                }else{

                }

                try {

                    val wifiManager =   mContext.objContext!!.applicationContext?.getSystemService(Context.WIFI_SERVICE) as WifiManager

                    if(strStatus.strValue=="Stop") {
                        wifiManager.disconnect()

                        cancel(true)
                        return
                    }

                    if (isCancelled) return

                    var floatFrequency:Float

                    var iCompte:Int

                    wifiManager.isWifiEnabled = true

                    wifiManager.startScan()
                    wifiManager.reconnect()

                    val results = wifiManager.scanResults

                    getLocationCompanion(mContext.objContext!!)

                    val resultWiFiScan = Array(results.size+1) {""}

                    for (x in 0..results.size)
                    {
                        resultWiFiScan.set( x, " ")

                    }

                    val adapter = ArrayAdapter<String>( mContext.objContext, R.layout.list_item,R.id.text1, resultWiFiScan)
                    var exp:Double
                    var iCount:Int=0

                    for (x in 0..results.size-1){

                        floatFrequency=results.get(x).frequency.toFloat()
                        floatFrequency=floatFrequency/1000
                        exp = (27.55 - (20 * Math.log10(floatFrequency.toDouble())) + Math.abs(results.get(x).level.toDouble())) / 20.0
                        strResult="SSID: " +results.get(x).SSID.toString() +  "\n"

                        strResult=strResult+"BSSID: "+results.get(x).BSSID.toString() + "  "+ mActivity.objActivity!!.getString(R.string.wifi_frequence)+": "+ floatFrequency.toString() +" Ghz  " +mActivity.objActivity!!.getString(R.string.wifi_canal)+" "+ results.get(x).channelWidth.toString() +"\n"

                        strResult=strResult+mActivity.objActivity!!.getString(R.string.wifi_niveau)+": "+results.get(x).level.toString() + "  "+ mActivity.objActivity!!.getString(R.string.wifi_securite)+": "+results.get(x).capabilities.toString()// +"\n"

                        strSSID=results.get(x).SSID.toString()
                        strBSSID=results.get(x).BSSID.toString()
                        strFrequence=floatFrequency.toString()
                        strLevel=results.get(x).level.toString()
                        strSecurite=results.get(x).capabilities.toString()
                        strCanal=results.get(x).channelWidth.toString()
                        strDistance=Math.round(exp).toString()

                        insertWifiRouter()

                        resultWiFiScan.set( x, strResult)
                        iCount=iCount+1
                    }

                    MyApplication.intPreviousWiFiCount.intCount=iCount

                    MyApplication.resultPreviousWiFi = Array(iCount) {""}
                    MyApplication.resultPreviousWiFi= resultWiFiScan

                    if(locationBest!=null){
                        val longdecimal = BigDecimal(locationBest!!.longitude).setScale(4, RoundingMode.HALF_EVEN)

                        val latdecimal = BigDecimal(locationBest!!.latitude).setScale(4, RoundingMode.HALF_EVEN)

                        MyApplication.strPreviousPosition.strPosition=longdecimal.toString() +" "+latdecimal.toString()
                    }




                    if (results!=null){
                        resultWiFiScan.sort(0,results.size)
                    }

                    iCompte= intCompteScanWifi.intValue+1

                    val txtCompte:TextView = mActivity.objActivity!!.txtCompteWifi

                    if (!boolPremier.boolValue){
                        txtCompte.text = mActivity.objActivity!!.getString(R.string.wifi_compteur)+" "+ iCompte.toString()
                    }

                    intCompteScanWifi.intValue=iCompte

                    val adapter3 = ArrayAdapter<String>(mContext.objContext,
                        R.layout.list_item,R.id.text1, resultWiFiScan)

                    val listView:ListView = mActivity.objActivity!!.listViewResultWiFi as ListView
                    listView.adapter = adapter3

                    var posBSSID:Int
                    var strBSSID:String
                    listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->

                        if(MyApplication.asyncRunning.bValue==true){
                            showMessage(mActivity.objActivity!!.getString(R.string.info_scan_actif))
                            return@OnItemClickListener
                        }

                        if (parent.getItemAtPosition(position).toString().length>1){
                            strBSSID=parent.getItemAtPosition(position).toString()
                            posBSSID=strBSSID.indexOf("BSSID",0)
                            strBSSID=strBSSID.substring(posBSSID+7,posBSSID+24)

                            MyApplication.strBSSIDforMap.strValue= strBSSID

                            val frgMap=FragmentMaps()

                            val fragmentManager =mFragment.objFragment!!.fragmentManager
                            val fragmentTransaction=  fragmentManager!!.beginTransaction()
                            if (viewModel.lastActiveFragmentTag != null) {
                                val lastFragment = fragmentManager.findFragmentByTag(viewModel.lastActiveFragmentTag)
                                if (lastFragment != null)
                                    fragmentTransaction.hide(lastFragment)
                            }

                            fragmentTransaction.replace(R.id.fragmentContainer,frgMap)
                            fragmentTransaction.disallowAddToBackStack()

                            fragmentTransaction.commit()

                        }

                    }

                    val txt_longitude =mActivity.objActivity!!.lblLongitude as TextView
                    val txt_latitude = mActivity.objActivity!!.lblLatitude as TextView
                    val txt_methode = mActivity.objActivity!!.lblMethod as TextView
                    val txt_precision = mActivity.objActivity!!.lblPrecision as TextView
                    var Context:Context= mContext.objContext!!
                    val locationManager =   mContext.objContext!!.applicationContext?.getSystemService(  android.content.Context.LOCATION_SERVICE) as  LocationManager

                    var xPos:Int=0

                    var strLat:String=""
                    var strLong:String=""

                    if (locationBest==null){
                        return
                    }

                    if(locationBest!=null){
                        val longLong = BigDecimal(locationBest!!.longitude).setScale(4, RoundingMode.HALF_EVEN)
                        val longLat = BigDecimal(locationBest!!.latitude).setScale(4, RoundingMode.HALF_EVEN)

                        strLong= longLong.toString()
                        strLat= longLat.toString()
                    }



                    if (!strLong.isNullOrEmpty()){

                        val longdecimal = BigDecimal(locationBest!!.longitude).setScale(4, RoundingMode.HALF_EVEN)
                        locationBest!!.longitude=longdecimal.toDouble()
                    }

                    if (!strLat.isNullOrEmpty()){

                        val latdecimal = BigDecimal(locationBest!!.latitude).setScale(4, RoundingMode.HALF_EVEN)
                        locationBest!!.latitude=latdecimal.toDouble()
                    }


                    if (strMethode=="GPS"){
                        txt_methode.setText(activity!!.getString(R.string.pos_method)+" "+ activity!!.getString(R.string.pos_gps))
                    }else{
                        txt_methode.setText(activity!!.getString(R.string.pos_method)+" "+ activity!!.getString(R.string.pos_reseau))
                    }

                        activity!!.getString(R.string.pos_longitude)+" "+

                   txt_longitude.setText(activity!!.getString(R.string.pos_longitude)+" "+strLong)
                   txt_latitude.setText(activity!!.getString(R.string.pos_latitude)+" "+strLat)
                   txt_precision.setText(activity!!.getString(R.string.pos_precision)+" "+strPrecision)

                } catch (e: UnknownHostException) {

                }
        }

    }

        private fun getLocationCompanion(ctx: Context){
            var locationManager: LocationManager =ctx!!.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var hasGPS=locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
            var hasNetwork=locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

            if (ActivityCompat.checkSelfPermission(
                    ctx,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    ctx,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                val permission2:String = "android.permission.ACCESS_COARSE_LOCATION"
                val permission:String = "android.permission.ACCESS_FINE_LOCATION"
                val permission_array = arrayOf( permission,permission2)
                ActivityCompat.requestPermissions(mActivity.objActivity!!, permission_array, 0)

            }

            if( hasGPS || hasNetwork){

                if (hasGPS){

                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000, 0F,  object:LocationListener{

                        @Override
                        override fun onLocationChanged(location: Location?) {
                            if(location !=null){
                                locationGPS=location
                            }
                        }

                        @Override
                        override fun onStatusChanged( provider: String?,  status: Int,  extras: Bundle?) {

                        }

                        @Override
                        override fun onProviderEnabled( provider:String?) {

                        }

                        @Override
                        override  fun onProviderDisabled( provider:String?) {

                        }

                    })


                    val localGPSLocation=  locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    if (localGPSLocation!=null)locationGPS=localGPSLocation

                }


                if (hasNetwork){

                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,5000, 0F,
                        object:LocationListener{

                            @Override
                            override fun onLocationChanged(location: Location?) {
                                if(location !=null){
                                    locationNetwork=location
                                }
                            }

                            @Override
                            override fun onStatusChanged( provider: String?,  status: Int,  extras: Bundle?) {

                            }

                            @Override
                            override fun onProviderEnabled( provider:String?) {

                            }

                            @Override
                            override  fun onProviderDisabled( provider:String?) {

                            }

                        })


                    val localNetworkLocation=  locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    if (localNetworkLocation!=null)locationNetwork=localNetworkLocation

                }

                if (locationGPS !=null && locationNetwork!=null ){
                    if(locationGPS!!.accuracy<locationNetwork!!.accuracy)
                    {
                        strPrecision=locationGPS!!.accuracy.roundToInt().toString()+" m"
                        strMethode=mActivity.objActivity!!.getString(R.string.pos_gps)

                        locationBest=locationGPS

                    }else{
                        strPrecision=locationNetwork!!.accuracy.roundToInt().toString()+" m"
                        strMethode=mActivity.objActivity!!.getString(R.string.pos_reseau)

                        locationBest=locationNetwork
                    }
                }

            }else
            {
                ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            }

        }

        public fun insertWifiRouter(){


            if ( MyApplication.strAutoScan.strValue=="0" || strPrecision.isNullOrEmpty()){
                return
            }

            val strcurrentPrecision :String=strPrecision!!.substring(0,strPrecision!!.length-2)
            val currPrecision:Int=strcurrentPrecision.toInt()

            val settingPrecision:Int= MyApplication.strMaxPrecision.strValue.toInt()

            if (currPrecision>settingPrecision){
                return
            }

            val dbHandler = ObjectBD( mContext.objContext!!, null, null, 3)

            val pattern = "yyyy-MM-dd hh:mm:ss"
            val simpleDateFormat = SimpleDateFormat(pattern)
            val date = simpleDateFormat.format(Date())

            var xPos:Int=0

            var strLat:String=""
            var strLong:String=""

            strLong=locationBest!!.longitude.toString()
            strLat=locationBest!!.latitude.toString()

            if (!strLong.isNullOrEmpty()){
                val longdecimal = BigDecimal(locationBest!!.longitude).setScale(4, RoundingMode.HALF_EVEN)
                locationBest!!.longitude=longdecimal.toDouble()
            }

            if (!strLat.isNullOrEmpty()){
                val latdecimal = BigDecimal(locationBest!!.latitude).setScale(4, RoundingMode.HALF_EVEN)
                locationBest!!.latitude=latdecimal.toDouble()
            }

            val strPosition=locationBest!!.longitude.toString()+ " " +locationBest!!.latitude.toString()
            var checkRouter:String
            if (strPosition!=  MyApplication.strPreviousPosition.strPosition){
                for (x in 0..MyApplication.intPreviousWiFiCount.intCount){
                    checkRouter=MyApplication.resultPreviousWiFi.get(x).toString()

                    if (checkRouter.indexOf(strLevel!!.toString(),0)>0 && checkRouter.indexOf(strBSSID!!.toString(),0)>0){
                      //  Log.d("resultPreviousWiFi", strPosition +" "+  MyApplication.strPreviousPosition.strPosition +"\n"+strBSSID!!+"\n"+ checkRouter+" "+ strLevel!!.toString())
                        return
                    }
                }
            }





            val posResult:ObjectPosition ?= dbHandler.findPosition(locationBest!!.latitude.toString(), locationBest!!.longitude.toString())
            val idPosition:Int




            if (posResult!=null) {

                idPosition=posResult.id
                val wifiResult:ObjectWifi ?= dbHandler.findWifiRouter(idPosition, strBSSID!! )

                if (wifiResult != null){

                }else{
                    val wifiObj =ObjectWifi(strSSID!!,strBSSID!!, strFrequence!!, strLevel!!, strSecurite!!, strCanal!!,  strDistance!!,date,idPosition)
                    dbHandler.addWifiRouter(wifiObj)
                }


            }else {
                val pos = ObjectPosition(locationBest!!.latitude.toString(), locationBest!!.longitude.toString(),date,strMethode!!,strPrecision!! )
                dbHandler.addPosition(pos)

                val posResultIfNew:ObjectPosition ?= dbHandler.findPosition(locationBest!!.latitude.toString(), locationBest!!.longitude.toString())

                if (posResultIfNew!=null){
                    idPosition=posResultIfNew!!.id

                    val wifiResult:ObjectWifi ?= dbHandler.findWifiRouter(idPosition, strBSSID!! )

                    if (wifiResult !=null){

                    }else{
                        val wifiObj =ObjectWifi(strSSID!!,strBSSID!!, strFrequence!!, strLevel!!, strSecurite!!, strCanal!!,  strDistance!!,date,idPosition)
                        dbHandler.addWifiRouter(wifiObj)
                    }
                }
            }


        }



    @JvmStatic
        fun newInstance() =
            FragmentWiFi().apply {
                arguments = Bundle().apply {

                }
            }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        viewModel= MViewModel()


        intentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        /*  var locationManager: LocationManager =context!!.getSystemService(Context.LOCATION_SERVICE) as LocationManager
          var hasGPS=locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
          var hasNetwork=locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

          if( hasGPS==false){
             Log.d("Localisation GPS","en a pas")
          }
          if(  hasNetwork==false){
              Log.d("Localisation Network","en a pas")
          }*/

        val view: View = inflater.inflate(R.layout.activity_wifi, container, false)
        val btn_click_me = view.findViewById(R.id.cmdOKSearchWiFi) as Button
        val btn_click_stop = view.findViewById(R.id.cmdStopSearchWiFi) as Button
        val editTempsWiFi= view.findViewById(R.id.editRefreshWifi) as EditText

        mContext.objContext=this.context
        mActivity.objActivity=this.activity
        mFragment.objFragment=this

        getLocation(mContext.objContext)
        editTempsWiFi.setText(MyApplication.strTempsDefautWiFi.strValue)

        btn_click_me.setOnClickListener(ButtonOkClick())
        btn_click_stop.setOnClickListener(ButtonStopClick())

        boolPremier.boolValue=true
        val task =WifiLogicTask(this)
        task.execute("Scan" )

        val chkShowAll =   view?.findViewById(R.id.chkShowAll) as CheckBox

        chkShowAll.setOnClickListener(chkShowAllClick())

        val txt_longitude = view.findViewById(R.id.lblLongitude) as TextView
        val txt_latitude = view.findViewById(R.id.lblLatitude) as TextView
        val txt_methode = view.findViewById(R.id.lblMethod) as TextView
        val txt_precision = view.findViewById(R.id.lblPrecision) as TextView

        if ( strMethode=="GPS"){
            txt_methode.setText(activity!!.getString(R.string.pos_method)+" "+ activity!!.getString(R.string.pos_gps))

        }else{
            txt_methode.setText(activity!!.getString(R.string.pos_method)+" "+ activity!!.getString(R.string.pos_reseau))
        }

        var xPos:Int=0
        var strLat:String=""
        var strLong:String=""


if(locationBest==null){

}else{


        if (!locationBest!!.longitude.toString().isNullOrEmpty()){

            val longdecimal = BigDecimal(locationBest!!.longitude).setScale(4, RoundingMode.HALF_EVEN)
            locationBest!!.longitude=longdecimal.toDouble()
            txt_longitude.setText( activity!!.getString(R.string.pos_longitude)+" "+locationBest!!.longitude.toString())
        }

        if (!locationBest!!.latitude.toString().isNullOrEmpty()){

            val latdecimal = BigDecimal(locationBest!!.latitude).setScale(4, RoundingMode.HALF_EVEN)
            locationBest!!.latitude=latdecimal.toDouble()
            txt_latitude.setText(activity!!.getString(R.string.pos_latitude)+" "+ locationBest!!.latitude.toString())
        }
}
        txt_precision.setText(activity!!.getString(R.string.pos_precision)+" "+ strPrecision)

        val imgViewCopyButton = view.findViewById<ImageButton>(R.id.imageCopyPosition)

        val imgViewButtonMap = view.findViewById<ImageButton>(R.id.imageMapWifi)



        imgViewButtonMap?.setOnClickListener() {
            ButtonMapClicked()

        }

        imgViewCopyButton?.setOnClickListener() {
            ButtonCopyClicked()

        }

        return view





    }

    internal inner class chkShowAllClick : View.OnClickListener {

        override fun onClick(v: View) {

            chkShowAllClicked()
        }
    }


    private fun chkShowAllClicked() {

        val chkShowAll =   view?.findViewById(R.id.chkShowAll) as CheckBox
        chkShowAll.isClickable=false

        val dbHandler = ObjectBD( mContext.objContext!!, null, null, 3)

        val cursor = dbHandler.findAllWifiRouter()

        var strResult:String=""

        var resultWiFiScan = Array(cursor.count) {""}

        if (cursor.count>1) {


            for(y in 0..cursor.count-1 ){

                cursor.moveToPosition(y)
                val ssid = cursor.getString(0)
                val strbssid = cursor.getString(1)
                var frequence = cursor.getString(2)
                var securite = cursor.getString(3)
                var canal = cursor.getString(4)

                strResult="SSID: " +ssid +  "\n"
                strResult=strResult+"BSSID: "+strbssid + "  "+ mActivity.objActivity!!.getString(R.string.wifi_frequence)+": "+ frequence+" Ghz  " +mActivity.objActivity!!.getString(R.string.wifi_canal)+" "+ canal+"\n"
                strResult=strResult+ mActivity.objActivity!!.getString(R.string.wifi_securite)+": "+securite// +"\n"

                resultWiFiScan.set( y, strResult)




            }

            val txtTotal =   view?.findViewById(R.id.txtCompteWifi) as TextView

            txtTotal.setText(mActivity.objActivity!!.getString(R.string.label_total_BSSID)+" "+cursor.count.toString())

        }
        cursor.close()
        dbHandler.close()

            val adapter = ArrayAdapter<String>( mContext.objContext, R.layout.list_item,R.id.text1, resultWiFiScan)
            val listView:ListView = mActivity.objActivity!!.listViewResultWiFi as ListView
            listView.adapter = adapter

            var posBSSID:Int
            var strBSSID:String
            listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->


                if(MyApplication.asyncRunning.bValue==true){
                    showMessage(mActivity.objActivity!!.getString(R.string.info_scan_actif))
                    return@OnItemClickListener
                }

                if (parent.getItemAtPosition(position).toString().length>1){
                    strBSSID=parent.getItemAtPosition(position).toString()
                    posBSSID=strBSSID.indexOf("BSSID",0)
                    strBSSID=strBSSID.substring(posBSSID+7,posBSSID+24)

                    MyApplication.strBSSIDforMap.strValue= strBSSID

                    val frgMap=FragmentMaps()

                    val fragmentManager =mFragment.objFragment!!.fragmentManager
                    val fragmentTransaction=  fragmentManager!!.beginTransaction()
                    if (viewModel.lastActiveFragmentTag != null) {
                        val lastFragment = fragmentManager.findFragmentByTag(viewModel.lastActiveFragmentTag)
                        if (lastFragment != null)
                            fragmentTransaction.hide(lastFragment)
                    }

                    fragmentTransaction.replace(R.id.fragmentContainer,frgMap)
                    fragmentTransaction.disallowAddToBackStack()

                    fragmentTransaction.commit()

                }

            }

    }

    private fun  ButtonMapClicked() {

        val imgViewButtonMap = view!!.findViewById<ImageButton>(R.id.imageMapWifi)

      //  imgViewButtonMap.setImageDrawable(R.drawable.planet.toDrawable())
      //  imgViewButtonMap.setBackgroundResource(R.drawable.border_style_status)


        if  (MyApplication.asyncRunning.bValue==true){
            showMessage(getString(R.string.info_scan_actif))
            return
        }

        MyApplication.strBSSIDforMap.strValue= ""
        val frgMap=FragmentMaps()

        val fragmentManager = activity!!.supportFragmentManager

        val fragmentTransaction=  fragmentManager.beginTransaction()
        if (viewModel.lastActiveFragmentTag != null) {
            val lastFragment = fragmentManager.findFragmentByTag(viewModel.lastActiveFragmentTag)
            if (lastFragment != null)
                fragmentTransaction.hide(lastFragment)
        }

        fragmentTransaction.replace(R.id.fragmentContainer,frgMap)
        fragmentTransaction.disallowAddToBackStack()

        fragmentTransaction.commit()

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        super.getActivity()
        activity?.title = ""

    }

    private fun onPeersAvailable() {

    }

    private fun ButtonStopClicked() {

        intCompteScanWifi.intValue=0

        val progressBar = activity!!.findViewById<View>(R.id.progressBarWifi)

        if (progressBar != null) {
            progressBar.visibility = View.INVISIBLE
            MyApplication.asyncRunning.bValue=false
        }

        strStatus.strValue="Stop"
        val btnStop:Button = view?.findViewById(R.id.cmdStopSearchWiFi) as Button
        btnStop.isClickable=false
        btnStop.isEnabled=false
        val btnStart:Button = view?.findViewById(R.id.cmdOKSearchWiFi) as Button
        btnStart.isClickable=true

        val chkShowAll =   view?.findViewById(R.id.chkShowAll) as CheckBox
        val labelShowAll =   view?.findViewById(R.id.labelShowAll) as TextView

        chkShowAll.isChecked=false
        chkShowAll.isClickable=true

        chkShowAll.visibility = View.VISIBLE
        labelShowAll.visibility = View.VISIBLE

    }

    private fun ButtonOkClicked() {

        intCompteScanWifi.intValue=0

        val progressBar = activity!!.findViewById<View>(R.id.progressBarWifi)

        val btnStop:Button = view?.findViewById(R.id.cmdStopSearchWiFi) as Button

        val btnStart:Button = view?.findViewById(R.id.cmdOKSearchWiFi) as Button
        val txtAdress1 =   view?.findViewById(R.id.editRefreshWifi) as EditText

        val chkShowAll =   view?.findViewById(R.id.chkShowAll) as CheckBox
        val labelShowAll =   view?.findViewById(R.id.labelShowAll) as TextView
        val txtTotal =   view?.findViewById(R.id.txtCompteWifi) as TextView

        txtTotal.setText("")

        chkShowAll.visibility = View.INVISIBLE
        labelShowAll.visibility = View.INVISIBLE

        var strResult:String=""

        var sSecond:String
        var iSecond:Int

        if (txtAdress1.text.isNullOrEmpty())
        {
            showMessage(getString(R.string.erreur_second_valeur))
            return
        }

        sSecond=txtAdress1.text.toString()

        iSecond=sSecond.toInt()

        if (!isNumeric(sSecond)){
            showMessage(getString(R.string.erreur_second_numerique))
            return
            }

        if (iSecond<1){
            showMessage(getString(R.string.erreur_second_trop_petit))
            return
        }

        if (progressBar != null) {
            progressBar.visibility = View.VISIBLE
            progressBar.animate()
            MyApplication.asyncRunning.bValue=true
        }
        MyApplication.asyncRunning.bValue=true
        strStatus.strValue="Start"

        btnStop.isClickable=true
        btnStop.isEnabled=true
        btnStart.isClickable=false

        val task =WifiLogicTask(this)
        task.execute("Scan" )

        intSecond.intValue=iSecond

        for (x in 0..1000)
        {
            boolPremier.boolValue = x==0

            if(strStatus.strValue=="Stop") {
                strStatus.strValue="break"
                break
            }

            val task =WifiLogicTask(this)
            task.execute("Scan" )

        }

    }

    fun showMessage(strMessage: String) {
        val toast_obj= Toast.makeText(this.activity,strMessage, Toast.LENGTH_SHORT)
        toast_obj.setGravity(Gravity.TOP, 0, 120)
        toast_obj.show()
    }

    internal inner class ButtonOkClick : View.OnClickListener {

        override fun onClick(v: View) {

            if (MyApplication.asyncRunning.bValue==true){
                showMessage(getString(R.string.info_scan_actif))
                return
            }

            ButtonOkClicked()
        }
    }

    internal inner class ButtonStopClick : View.OnClickListener {

        override fun onClick(v: View) {

            ButtonStopClicked()
        }
    }

    private fun isLocationEnabled(ctx: Context): Boolean {
        var locationManager: LocationManager = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER
        )
    }

 public fun getLocation(ctx: Context?){
     var locationManager: LocationManager =ctx!!.getSystemService(Context.LOCATION_SERVICE) as LocationManager
     var hasGPS=locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
     var hasNetwork=locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

     if (ActivityCompat.checkSelfPermission(
             ctx,
             Manifest.permission.ACCESS_FINE_LOCATION
         ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
             ctx,
             Manifest.permission.ACCESS_COARSE_LOCATION
         ) != PackageManager.PERMISSION_GRANTED
     ) {
         val permission2:String = "android.permission.ACCESS_COARSE_LOCATION"
         val permission:String = "android.permission.ACCESS_FINE_LOCATION"
         val permission_array = arrayOf( permission,permission2)
         ActivityCompat.requestPermissions(activity!!, permission_array, 0)

     }



     if( hasGPS || hasNetwork){

         if (hasGPS){

             locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000, 1F,  object:LocationListener{

                     @Override
                     override fun onLocationChanged(location: Location?) {
                        if(location !=null){
                            locationGPS=location
                        }
                     }

                     @Override
                     override fun onStatusChanged( provider: String?,  status: Int,  extras: Bundle?) {

                     }

                     @Override
                     override fun onProviderEnabled( provider:String?) {

                     }

                     @Override
                     override  fun onProviderDisabled( provider:String?) {

                     }

                 })

           val localGPSLocation=  locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
             if (localGPSLocation!=null){
                 locationGPS=localGPSLocation
                 locationBest=locationGPS
                 strMethode="GPS"
             }
         }

         if (hasNetwork){

             locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,5000, 1F,
             object:LocationListener{


                 @Override
                 override fun onLocationChanged(location: Location?) {
                     if(location !=null){
                         locationNetwork=location
                     }
                 }

                 @Override
                 override fun onStatusChanged( provider: String?,  status: Int,  extras: Bundle?) {

                 }

                 @Override
                 override fun onProviderEnabled( provider:String?) {

                 }

                 @Override
                 override  fun onProviderDisabled( provider:String?) {

                 }

             })

             val localNetworkLocation=  locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
             if (localNetworkLocation!=null){
                 locationNetwork=localNetworkLocation
                 locationBest=locationNetwork
                 strMethode="Réseau"
             }

         }

         if (locationGPS !=null && locationNetwork!=null ){
             if(locationGPS!!.accuracy<locationNetwork!!.accuracy)
             {
                 strPrecision=locationGPS!!.accuracy.roundToInt().toString()+" m"
                 strMethode="GPS"
                 locationBest=locationGPS

             }else{
                 strPrecision=locationNetwork!!.accuracy.roundToInt().toString()+" m"
                 strMethode="Réseau"
                 locationBest=locationNetwork
             }

         }

     }else
     {
         startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
     }

 }

    private fun ButtonCopyClicked() {

        val myClipboard: ClipboardManager = activity!!.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val myClip: ClipData
        val strText=locationBest!!.latitude.toString() +" " +locationBest!!.longitude.toString()

        myClip = ClipData.newPlainText("textPosition", strText)
        myClipboard.setPrimaryClip(myClip)

    }

}


