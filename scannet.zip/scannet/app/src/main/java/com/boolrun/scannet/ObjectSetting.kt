package com.boolrun.scannet

class ObjectSetting {

    var id: Int = 0
    var strSettingLabel: String? = null
    var strSettingValue: String? = null


    constructor(id: Int, setting_label: String, setting_value: String) {
        this.id = id
        this.strSettingLabel=setting_label
        this.strSettingValue=setting_value


    }

    constructor(setting_label: String, setting_value: String) {
        this.strSettingLabel=setting_label
        this.strSettingValue=setting_value
    }


}